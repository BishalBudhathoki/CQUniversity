/*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
 */
package HomelessInfoDataMain;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public class DataFile {

    //input scanner to read file
    private static Scanner scaninput;
    // create risky person arraylist
    private ArrayList<RiskyPersons> riskyPersons = new ArrayList<RiskyPersons>();
    //create locatoin arraylist to store locations
    private ArrayList<Location> locations = new ArrayList<Location>();
    //filename path and file name to read
    private final String fileName = "src\\futureDemand.csv";

    public ArrayList<RiskyPersons> getRiskyPersons() {
        //get method for risky person
        return riskyPersons;
        // return to risky person arraylist
    }

    public ArrayList<Location> getLocations() {
        //getmethod for location
        return locations;
        //returns location arraylist
    }

    public void addLocation(Location location)
    {
        locations.add(location);
        //add location values to arraylist
    }

    public void initilizeDataFile() {
        //this class opens, reads and closes a file
        openFile();
        readFile();
        closeFile();
    }

    public void openFile() {
        //open file
        try {
            scaninput = new Scanner(Paths.get(fileName));

        } catch (IOException ioException) {
            //IO exception if file could not be opened or file does not exist
            System.err.println("Error Opening File. Please check the file");
            System.exit(1);

        }
    }

    public void readFile() {
        // read file
        String lineRead;
        String[] entryValues = new String[19];
        String[] genderValues = new String[19];
        String[] ageGroups = new String[19];
        String[] employeeSources = new String[19];

        try {
            lineRead = scaninput.nextLine();
            genderValues = lineRead.split(",");

            lineRead = scaninput.nextLine();
            ageGroups = lineRead.split(",");

            lineRead = scaninput.nextLine();
            employeeSources = lineRead.split(",");

            while (scaninput.hasNext()) {
                lineRead = scaninput.nextLine();
                entryValues = lineRead.split(",");

                Location location = createLocation(entryValues[0],
                        entryValues[1]);
                addLocation(location);

                WEEKLY_INCOME incomeCategory = WEEKLY_INCOME.
                        getWeeklyIncome(entryValues[2]);

                for (int i = 3; i < 19; i++) {
                    try {
                        GENDER gender = GENDER.getGender(genderValues[i]);
                        AGE age = AGE.getAge(ageGroups[i]);
                        String income_Source = employeeSources[i];
                        int numberOfPerson = Integer.parseInt(entryValues[i]);
                        SA3TenantCategory sa3TenantCategory
                                = new SA3TenantCategory(location,
                                        incomeCategory, income_Source,
                                        age, gender);

                        RiskyPersons riskyPerson = new RiskyPersons
                                (numberOfPerson, sa3TenantCategory);
                        riskyPersons.add(riskyPerson);

                    } catch (Exception e) { //catch normal exceptions
                        System.err.println(e);
                    }

                }

            }

        } catch (IllegalStateException stateException) {
            //if failed to read file
            System.err.println("Error reading from the file. Closing");
        }

    }

    // close file and terminate application when called
    public static void closeFile() {
        if (scaninput != null) {
            scaninput.close();
        }
    }
    //store location details
    public Location createLocation(String sa3Code, String address) {
        Location loc = new Location();
        loc.setSa3Code(sa3Code);
        loc.setAddress(address);
        //get location details
        loc.getSa3Code();
        loc.getAddress();
        return loc;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public class RiskyPersons {

    private int numberOfPerson;
    SA3TenantCategory sa3TenantCategory;

    public RiskyPersons() {//default constructor
    }

    public RiskyPersons(int numberOfPerson, SA3TenantCategory sa3TenantCategory) {
//parameterized constructor
        this.numberOfPerson = numberOfPerson;
        this.sa3TenantCategory = sa3TenantCategory;

    }
//getter setter methods

    public SA3TenantCategory getSA3TenantData() {
        return sa3TenantCategory;
    }

    public void setSa3TenantCategory(SA3TenantCategory sa3TenantCategory) {
        this.sa3TenantCategory = sa3TenantCategory;
    }

    public void setNumberOfPerson(int n) {
        this.numberOfPerson = n;
    }

    public int getNumberOfPerson() {
        return numberOfPerson;
    }

    @Override
    public String toString() {

//        return sa3TenantCategory.toString() + "Number of person:" + numberOfPerson;
        return String.format("%-15s %-15d\n ", this.sa3TenantCategory.toString(), this.numberOfPerson);

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public class HomelessInfoMain extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().
                getResource("HomelessInfo.fxml"));//call HomelessInfo fxml file

        Scene scene = new Scene(root);
        stage.setTitle("Homeless Information System");//set title of the tab
        scene.getStylesheets().add(getClass().
                getResource("style.css").toExternalForm()); //set css for design of tabs
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}

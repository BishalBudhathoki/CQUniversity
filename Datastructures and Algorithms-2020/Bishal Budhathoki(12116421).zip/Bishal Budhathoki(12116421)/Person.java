/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public abstract class Person { //abstract class

    AGE age; //Age enum
    GENDER gender; //Gender enum

    public Person() { //default constructor
    }

    //parameterised constructor
    public Person(AGE age, GENDER gender) {
        this.age = age;
        this.gender = gender;

    }

    //accessors and mutators
    //set get methods
    public AGE getAge() {
        return age;
    }

    public void setAge(AGE age) {
        this.age = age;
    }

    public GENDER getGender() {
        return gender;
    }

    public void setGender(GENDER gender) {
        this.gender = gender;
    }

    //override inbuilt method
    @Override
    public String toString() {
        return String.format("%-20s %-15s ", this.getAge(), this.getGender());
    }
}

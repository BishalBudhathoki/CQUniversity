package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public enum GENDER {
    MALE("Male"), FEMALE("Female"); //enum initialize

    private String genderValue;
    //set gender

    private GENDER(String value) {
        this.genderValue = value;
    }
    //get gender details

    public static GENDER getGender(String gender) {
        switch (gender) {
            default:
            case "Male":
                return GENDER.MALE;
            case "Female":
                return GENDER.FEMALE;
        }
    }

}

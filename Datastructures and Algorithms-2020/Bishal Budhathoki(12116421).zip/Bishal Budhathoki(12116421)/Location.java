/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public class Location { //handles location details

    private String sa3Code, address;

    public Location() { //default constructor

    }
    //parameterised constructor
    public Location(String sa3Code, String address) {
        this.address = address;
        this.sa3Code = sa3Code;
    }
// get set methods
    public String getSa3Code() { //get method for SA3Code
        return sa3Code;
    }

    public void setSa3Code(String Sa3Code) { //set method for SA3Code
        this.sa3Code = Sa3Code;
    }

    public String getAddress() { //get method for Location
        return address;
    }

    public void setAddress(String address) { //set method for location
        this.address = address;
    }

    public String displayLocation() {
        return sa3Code; //return to display location in combo box
    }
//override inbuilt method
    @Override
    public String toString() {
        return String.format("%-1s  %-38s ", this.getSa3Code(),
                this.getAddress());
    }
}

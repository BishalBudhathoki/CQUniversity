package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public enum AGE { //enum Age
    FiftyToFifyFour("50-54"),
    FiftyToFifyNine("55-59"),
    SixtyToSixtyFour("60-64"),
    SixtyFiveOver("over 65");
    private String ageVal;

    private AGE(String value) { //constructor
        ageVal = value;
    }

    //get enum
    public String getStringValue() {
        return this.ageVal;
    }

    //set age enum
    public static AGE getAge(String age) throws IllegalArgumentException {
        age = age.trim();
        for (AGE ageEnum : AGE.values()) {
            if (ageEnum.getStringValue().equals(age)) {
                return ageEnum;
            }
        }
        //throws illegal exception
        throw new IllegalArgumentException("Age" + age + "is not found in the list");
    }
}

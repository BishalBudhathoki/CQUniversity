/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public enum WEEKLY_INCOME { //enum WEEKLY_INCOME
    //weekly income enum options
    NILINCOME("Negative/Nil income"),
    BELOW$400("$1-$399"),
    BELOW$600("$400-$599"),
    BELOW$1000("$600-$999");
    private String incomeValue;

    private WEEKLY_INCOME(String value) {
        //constructor
        incomeValue = value;
    }

    public String getStringValue() {
            //get enum value
            return this.incomeValue;
    }

    //set enum value
    public static WEEKLY_INCOME getWeeklyIncome(String income) {
        income = income.trim();
        for (WEEKLY_INCOME weekenum : WEEKLY_INCOME.values()) {
            if (weekenum.getStringValue().equals(income)) {
            //if selected option is equal to enum value
                return weekenum;
            }
        }
        // throw I illegal argument
        throw new IllegalArgumentException("WEEKLY_Income" + income + "is not found in list");

    }
}

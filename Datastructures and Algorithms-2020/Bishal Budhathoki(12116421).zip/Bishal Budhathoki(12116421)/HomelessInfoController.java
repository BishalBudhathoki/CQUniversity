/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Region;
/**
 *
 * @author Bishal Budhathoki
 * 12116421
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 1
 *
 */
public class HomelessInfoController implements Initializable {

    //fxml components declaration
    @FXML
    private TabPane tabPaneModel, tabPaneOneModel;

    @FXML
    private Label label, enterLocLabel;

    @FXML
    private ComboBox incomeRange, age, incomeSource,
            displayComboBox, SA3comboBox,
            locationDisplayComboBox, genderComboBox;

    private String income_source = "",
            ages = "", income_range = "",
            display_Data = "", genders = "";

    @FXML
    private Button nextTab, nextTabOne, addLocationBtn,
            addTenantDataBtn, showReportBtn;

    @FXML
    private TextField location, SA3Code;

    @FXML
    private TextArea displayBox;

    private String selectedOption;

    //string declaration to check condition and print data
    String incomeSourceCheck = "";
    String genderCheck = "";
    String incomeRangeCheck = "";

    //Risky person arraylist to store details
    ArrayList<RiskyPersons> riskyPersonsList = new ArrayList<>();
    //Location arraylist to store location details
    ArrayList<Location> locationList = new ArrayList<>();
    ArrayList<Location> newLocationList = new ArrayList<>();

    private String SA3CodeSelection = "", locationSelect = "", ageSelect = "",
            incomeSelect = "", incomeRangeSelect = "", genderSelect = "",
            incomeSourceSelect = "";
//in built method called
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Dropdown menu initialized

        //Dropdown list for income range
        this.incomeRange.getItems().addAll("Negative/Nil income",
                "$1-$399", "$400-$599", "$600-$999");
        //Dropdown list for income source group
        this.incomeSource.getItems().addAll("Employed", "Other");
        //Dropdown list for age group
        this.age.getItems().addAll("50-54", "55-59", "60-64", "over 65");
        //Dropdown list for gender group
        this.genderComboBox.getItems().addAll("Male", "Female");

        //Dropdown list to display required report
        this.displayComboBox.getItems().addAll(
                "All males at the risk of homelessness",
                "All people in a chosen location at the risk of homelessness",
                "All females at the risk of homelessness",
                "All at the risk of homelessness");

        location.setText(""); //set text field empty
        displayBox.setText(""); // set display box empty
        SA3comboBox.getSelectionModel().clearSelection();
        //function to clear selection box/ combo box

        //Datafile initialization
        DataFile df = new DataFile();
        df.initilizeDataFile();
        riskyPersonsList = df.getRiskyPersons();
        //get risky person arraylist
        locationList = df.getLocations();
        //get location arraylist
        System.out.println(riskyPersonsList);

        // remove duplication of location while showing in combo box
        String sa = "";//temporary variable
        for (Location locate : locationList) {
            locate.getSa3Code();
            if (locate.getSa3Code().equals(sa)) {//check if SA3code gets repeat
            } else {
                newLocationList.add(locate);
            }
            sa = locate.getSa3Code();

        }

        for (int i = 0; i < newLocationList.size(); i++) {
            //loading location in sa3combobox of Location tab
            SA3comboBox.getItems().add(i,
                    newLocationList.get(i).displayLocation());
            //loading location details in location combo box of Reports tab
            locationDisplayComboBox.getItems().add(i,
                    newLocationList.get(i).displayLocation());

        }
        // end of loading adding

        //select default tab and navigate tab method
        tabPaneModel.getSelectionModel().selectedIndexProperty()
                .addListener(new ChangeListener<Number>() {
                    // in built method
                    @Override
                    public void changed(ObservableValue<? extends Number> ov,
                                        Number oldValue, Number newValue) {
                        if ((oldValue.intValue() == 1
                                || oldValue.intValue() == 2
                                || oldValue.intValue() == 3)
                                && newValue.intValue() == 0) {
                            location.setText("");
                            SA3Code.setText("");
                        }
                    }
                });
    }

    @FXML
    private void incomeSourceMethod(ActionEvent event) {
        income_source = (String) this.incomeSource.getValue();
    }

    @FXML
    private void incomeRangeMethod(ActionEvent event) {
        income_range = (String) this.incomeRange.getValue();
    }

    @FXML
    private void ageMethod(ActionEvent event) {
        ages = (String) this.age.getValue();
    }

    @FXML
    private void genderMethod(ActionEvent event) {
        genders = (String) this.genderComboBox.getValue();
    }

    @FXML
    private void displayDataMethod(ActionEvent event) {
        display_Data = (String) this.displayComboBox.getValue();
    }

    @FXML
    private void NextTabMethod(ActionEvent event) {
        this.tabPaneModel.getSelectionModel().selectNext();
        clearLocationTab();
    }

    @FXML
    private void NextTabOneMethod(ActionEvent event) {
        this.tabPaneModel.getSelectionModel().selectNext();
        clearFields();
    }

    //add location method
    @FXML
    private void addLocationMethod(ActionEvent event) {

        try {
            //variable declarations and initialisation
            String SA3Codes, locationName, verifyScode, verifyLocation;
            SA3Codes = SA3Code.getText().trim();
            locationName = location.getText().trim();
            verifyScode = SA3Codes;
            verifyLocation = locationName;

            //Scode and Location validation
            //Scode validation
            String scodePattern = "^5\\d{4}$";

            String input = verifyScode;
            if (input == null) {
                System.out.println("Scode Null");
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Please Enter SA3Code");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.show();
            }

            if (input.matches(scodePattern)) {
                System.out.println("Valid Data!");
                //Location validation
                String locationPattern = "\b[A-Za-z]+[ ]+[-]+[ ][A-Za-z]+$\b";
                if (verifyLocation.contains(" - ")
                        || verifyLocation.matches(locationPattern)
                        || verifyLocation.matches("(\\w+)\\s")) {

                    System.out.println("matched");
                    String sa = "";
                    Location locateObj = new Location();
                    locateObj.setSa3Code(SA3Codes);
                    locateObj.setAddress(locationName);

                    if (locateObj.getAddress().equals(sa)) {
                    } else {
                        newLocationList.add(locateObj);
                    }
                    sa = locateObj.getAddress();

                    this.SA3comboBox.getItems().clear();
                    this.locationDisplayComboBox.getItems().clear();
                    for (int i = 0; i < newLocationList.size(); i++) {

                        this.SA3comboBox.getItems().add(i, newLocationList
                                .get(i).displayLocation());
                        this.locationDisplayComboBox.
                                getItems().add(i,
                                newLocationList.get(i).
                                        displayLocation());

                    }
                    //alert box
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Data Added successful");
                    alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                } else {
                    System.out.println("Data Not matched");
                    //alert box
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Location should be in this format: "
                                    + "'Location - Location' "
                                    + "where ' - ' must be as delimiter"
                                    + " or a single Location word");
                    alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                }
                //validation ends

            } else {
                System.out.println("Wrong digits");
                //alert box
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "SA3code starts with '5' and can only have 5 digits");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.show();
            }
            // end of SA3Code validation

        } catch (Exception e) {
            //catch general exceptions
            System.out.println("e");
        }

    }

    //Add tenant details
    @FXML
    private void addTenantDataMethod(ActionEvent event) {
        //Variable declaration
        String addressValue = "";

        //verification of selected value
        AGE ageEnum;
        String ageValue = (String) age.getValue();

        if (ageValue == "50-54") {
            ageEnum = AGE.FiftyToFifyFour;
        } else if (ageValue == "55-59") {
            ageEnum = AGE.FiftyToFifyNine;
        } else if (ageValue == "60-64") {
            ageEnum = AGE.SixtyToSixtyFour;
        } else {
            ageEnum = AGE.SixtyFiveOver;
        }
        System.out.println(ageValue);
        System.out.println(ageEnum);
        if (ageValue == null) {
            System.out.println("Age value is not selected");
            //alert box
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Please select age group");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();

        }

        WEEKLY_INCOME incomeRangeEnum;
        String incomeRangeValue = (String) incomeRange.getValue();
        if (incomeRangeValue == "Negative/Nil income") {
            incomeRangeEnum = WEEKLY_INCOME.NILINCOME;
        } else if (incomeRangeValue == "$1-$399") {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$400;
        } else if (incomeRangeValue == "$400-$599") {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$600;
        } else {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$1000;
        }
        System.out.println(incomeRangeValue);
        System.out.println(incomeRangeEnum);
        if (incomeRangeValue == null) {
            System.out.println("Income range is not selected");
            //alert box
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select income range");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        String SA3ComboBoxValue = (String) SA3comboBox.getValue();
        System.out.println(SA3ComboBoxValue);
        if (SA3ComboBoxValue == null) {
            System.out.println("SA3code is not selected");
            //alert box
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select SA3Code");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        String incomeSourceValue = (String) incomeSource.getValue();
        System.out.println(incomeSourceValue);
        if (incomeSourceValue == null) {
            System.out.println("Income Source is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select income source");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        int loopcount = 0; //to get the last value

        String genderValue = (String) genderComboBox.getValue();
        System.out.println(genderValue);
        GENDER genderEnum;
        if (genderValue == "Male") {
            genderEnum = GENDER.MALE;
        } else {
            genderEnum = GENDER.FEMALE;
        }

        System.out.printf("Gender enum : %s ", genderEnum);
        if (genderValue == null) {
            System.out.println("Gender is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select gender");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }
        //to get location details
        for (Location count : newLocationList) {
            if (count.getSa3Code().equals(SA3ComboBoxValue)) {
                addressValue = count.getAddress();
                System.out.println(addressValue);

            }

        }

        for (RiskyPersons counter : riskyPersonsList) {
            if (counter.getSA3TenantData().getIncomeSource().
                    equals(incomeSourceValue)
                    && counter.getSA3TenantData().getGender().
                    equals(genderEnum)
                    && counter.getSA3TenantData().getIncomeRange().
                    equals(incomeRangeEnum)
                    && counter.getSA3TenantData().getlocation().
                    getSa3Code().equals(SA3ComboBoxValue)
                    && counter.getSA3TenantData().getAge().equals(ageEnum)
                    && counter.getSA3TenantData().getlocation().getAddress().
                    equals(addressValue)) {
                //update number of person counter by +1
                // if data is already in the arraylist
                int number = counter.getNumberOfPerson();
                number++;
                counter.setNumberOfPerson(number);
                System.out.println("Data matched");
                //alert box
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Data Updated successful");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.show();
                break;
            } else {
                System.out.println("Data didn't matched");
            }
            loopcount++; //loop count incremented
        }
        // add new details to arraylist if required
        if (riskyPersonsList.size() == loopcount) {
            Location loc = new Location(SA3ComboBoxValue, addressValue);
            SA3TenantCategory sa = new SA3TenantCategory(loc, incomeRangeEnum, income_source, ageEnum, genderEnum);
            RiskyPersons newRP = new RiskyPersons(1, sa);
            riskyPersonsList.add(newRP);
            System.out.println(riskyPersonsList.size());
            // alert box
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Data Added successful");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        System.out.printf("Risky person array size: %d", riskyPersonsList.size());
        System.out.printf("Loop count: %d", loopcount);

    }
//display details
    @FXML
    public void displayAction(ActionEvent event) {

        selectedOption = displayComboBox.getSelectionModel().
                getSelectedItem().toString();
        System.out.println(selectedOption);

        if (selectedOption.equals("All people in a chosen location "
                + "at the risk of homelessness")) {

            System.out.println("Second option pressed");
            enterLocLabel.setOpacity(1);
            locationDisplayComboBox.setOpacity(1);
            locationDisplayComboBox.setDisable(false);

        } else {
            enterLocLabel.setOpacity(0);
            locationDisplayComboBox.setOpacity(0);
            locationDisplayComboBox.setDisable(true);
        }
        ;

    }

    //Display Report
    @FXML
    public void reportBtn(ActionEvent event
    ) {

        System.out.println("Report Button Pressed");
        displayBox.setText("");

        if (selectedOption == null) {
            System.out.println("Option not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select option to display statistical reports");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        } else { //first option
            if (selectedOption.equals("All males at the risk of"
                    + " homelessness")) {
                System.out.println("first option pressed");
                incomeSourceCheck = "Other";
                GENDER male = GENDER.MALE;
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                incomeRangeCheck = "Negative/Nil income";
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");

                System.out.println();
                for (RiskyPersons count : riskyPersonsList) {
                    if (count.getSA3TenantData().getIncomeSource().
                            equals("Other") && count.getSA3TenantData().
                            getGender().equals(male)
                            && (count.getNumberOfPerson() >= 1)
                            && (count.getSA3TenantData().getIncomeRange().
                            equals(nilIncome)
                            || count.getSA3TenantData().getIncomeRange().
                            equals(below$400))) {
                        displayBox.appendText(count.toString());
                    }
                }

            }
            //second option
            else if (selectedOption.equals("All people in a chosen "
                    + "location at the risk of homelessness")) {

                System.out.println("Second option pressed");
                String locationToDisplay = (String) locationDisplayComboBox
                        .getValue();
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                System.out.println(locationToDisplay);
                if (locationToDisplay == null) {
                    System.out.println("Location is not selected");
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Please select a location.");
                    alert.getDialogPane().
                            setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                } else {
                    displayBox.setStyle("-fx-font-family: monospace");
                    displayBox.setText("SA3code \tName \t\t\t\t"
                            + "Income Category  Income Source\t\t "
                            + "Age Group \t Gender    Number of People \n ");
                    for (RiskyPersons count : riskyPersonsList) {
                        if (count.getSA3TenantData().getlocation().getSa3Code().
                                equals(locationToDisplay)
                                && count.getSA3TenantData().getIncomeSource().
                                equals("Other") && (count.
                                getNumberOfPerson() >= 1)
                                && (count.getSA3TenantData().getIncomeRange().
                                equals(nilIncome)
                                || count.getSA3TenantData().getIncomeRange().
                                equals(below$400))) {
                            {

                                displayBox.appendText(count.toString());

                            }
                        }
                    }
                }

            }//third option
            else if (selectedOption.equals("All females at "
                    + "the risk of homelessness")) {
                System.out.println("Third option pressed");
                incomeSourceCheck = "Other";
                GENDER female = GENDER.FEMALE;
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");

                for (RiskyPersons count : riskyPersonsList) {
                    if (count.getSA3TenantData().getIncomeSource().
                            equals("Other") && count.getSA3TenantData().
                            getGender().equals(female)
                            && (count.getNumberOfPerson() >= 1)
                            && (count.getSA3TenantData().getIncomeRange().
                            equals(nilIncome)
                            || count.getSA3TenantData().getIncomeRange().
                            equals(below$400))) {
                        {
                            System.out.println(count.toString());
                            displayBox.appendText(count.toString());

                        }

                    }
                }

            }
            //fourth option
            else if (selectedOption.equals("All at the risk of "
                    + "homelessness")) {
                System.out.println("Fourth option pressed");
                incomeSourceCheck = "Other";
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");
                for (RiskyPersons count : riskyPersonsList) {
                    if (count.getSA3TenantData().getIncomeSource().
                            equals("Other") && (count.getNumberOfPerson() >= 1)
                            && (count.getSA3TenantData().getIncomeRange().
                            equals(nilIncome)
                            || count.getSA3TenantData().getIncomeRange().
                            equals(below$400))) {
                        System.out.println(count.toString());
                        displayBox.appendText(count.toString());

                    }

                }

            }
        }
    }

    RiskyPersons c = new RiskyPersons();

    //to clear selected options field while going next tab forward
    public void clearFields() {
        //to clear the entered/selected value in tenant tab
        SA3comboBox.getSelectionModel().clearSelection();
        incomeRange.getSelectionModel().clearSelection();
        age.getSelectionModel().clearSelection();
        displayComboBox.getSelectionModel().clearSelection();
        locationDisplayComboBox.getSelectionModel().clearSelection();
        incomeSource.getSelectionModel().clearSelection();

    }

    public void clearLocationTab() {
        //to clear the entered details in location tab
        location.setText(null);
        SA3Code.setText(null);
    }

}

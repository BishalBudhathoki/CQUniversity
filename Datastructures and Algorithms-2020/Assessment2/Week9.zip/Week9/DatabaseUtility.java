import java.sql.*;

/**
 *
 * @author Bishal Budhathoki
 * 12116421
 */
public class DatabaseUtility {

    private final String MYSQL_URL = "jdbc:mysql://localhost:3306";
    private final String DATABASE_URL = MYSQL_URL + "/ContactsDB";
    private final String USERNAME = "Bishal";
    private final String PASSWORD = "576228";

    private Connection sqlConnection;
    private Connection dbConnection;
    private Statement statement;
    private final String dbCreateSQL;
    private final String TABLE_CONTACTS_QRY;
    private boolean dbExists = false;
    private String databaseName = "";

    public DatabaseUtility() {
        statement = null;
        dbCreateSQL = "CREATE DATABASE ContactsDB";
        TABLE_CONTACTS_QRY = " CREATE  TABLE IF NOT EXISTS CONTACTS"
                + "(ContactID INTEGER not NULL AUTO_INCREMENT,"
                + "firstName VARCHAR(64), lastName VARCHAR(64), "
                + "PRIMARY KEY (ContactID)))";
        try {
            sqlConnection = DriverManager.getConnection(MYSQL_URL, USERNAME, PASSWORD);
            statement = sqlConnection.createStatement();
        } catch (SQLException ex) {
            System.out.println("Connection Failed");
            ex.printStackTrace();

        }
        try {
            ResultSet dbData = sqlConnection.getMetaData().getCatalogs();
            while (dbData.next()) {
                databaseName = dbData.getString(1);
                if (databaseName.equalsIgnoreCase("ContactsDB")) {
                    dbExists = true;
                }

            }
            if (!dbExists) {
                statement.executeUpdate(dbCreateSQL);
            }
            if (sqlConnection != null) {
                sqlConnection.close();
            }

            dbConnection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            statement = sqlConnection.createStatement();
            statement.executeUpdate(TABLE_CONTACTS_QRY);
        } catch (SQLException e) {
            System.out.println("COnnection Failed! Check output console");
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            e.printStackTrace();
        }
    }

    public Connection open() {
        try {
            dbConnection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);

        } catch (Exception e) {
            System.out.println("Error opening connection");
            e.printStackTrace();
        }
        return dbConnection;
    }

    public void close(Connection connection) {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error closing connection");
            e.printStackTrace();
        }
    }

}
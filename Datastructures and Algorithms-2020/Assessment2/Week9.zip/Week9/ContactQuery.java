import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Bishal Budhathoki
 * 12116421
 */
public class ContactQuery {

  private DatabaseUtility databaseUtility = new DatabaseUtility();
  private Connection connection;
  private PreparedStatement selectallContacts;
  private PreparedStatement insertContact;
  private PreparedStatement deleteContact;

  private final String SELECT_QUERY = "SELECT * FROM CONTACTS";
  private final String INSERT_QUERY = "INSERT INTO CONTACTS"
          + "(firstName, lastName, email, phoneNum)"
          + "VALUES (?, ?, ?, ?)";

  private final String DELETE_QUERY = "DELETE FROM CONTACTS WHERE ContactID = ?";

  public ContactQuery() {
      try {
          connection = databaseUtility.open();
          insertContact = connection.prepareStatement(INSERT_QUERY);
          selectallContacts = connection.prepareStatement(SELECT_QUERY);
          deleteContact = connection.prepareStatement(DELETE_QUERY);
      } catch (SQLException sqlException) {
          sqlException.printStackTrace();
          System.exit(1);
      }

  }

  public List<Contact> getAllContacts() {
      try (ResultSet resultset = selectallContacts.executeQuery()) {
          List<Contact> results = new ArrayList<>();

          while(resultset.next()) {
              results.add(new Contact (
                      resultset.getInt("ContactID"),
                      resultset.getString("firstName"),
                      resultset.getString("lastName"),
                      resultset.getString("email"),
                      resultset.getString("phoneNum")));

          }
          return results;
      } catch (SQLException sqlException) {
          sqlException.printStackTrace();
      }
      return null;
  }

  public int addPerson(String firstName, String lastName,
                       String email, String phoneNumber) {
      try {
          insertContact.setString(1, firstName);
          insertContact.setString(2, lastName);
          insertContact.setString(3, email);
          insertContact.setString(4, phoneNumber);

          return insertContact.executeUpdate();
      } catch (SQLException sqlException) {
          sqlException.printStackTrace();
          return  0;
      }
  }

  public int deletePerson(int ContactID) {
      try{
          deleteContact.setInt(1, ContactID);

          return deleteContact.executeUpdate();
      } catch (SQLException sqlException) {
          sqlException.printStackTrace();
          return 0;
      }
  }

  public static void main(String[] args) {
      ContactQuery contactQuery = new ContactQuery();
      contactQuery.addPerson("Bishal", "Budhathoki", "bishalkc331@gmail.com", "0450076228");
      contactQuery.addPerson("Bishal", "Budhathoki", "bishalkc331@gmail.com", "0450076228");
      contactQuery.addPerson("Bishal", "Budhathoki", "bishalkc331@gmail.com", "0450076228");
      contactQuery.addPerson("Bishal", "Budhathoki", "bishalkc331@gmail.com", "0450076228");

      List<Contact> contactList = contactQuery.getAllContacts();
      contactList.forEach((obj) -> {
          System.out.println(obj.toString());
      });

      contactQuery.deletePerson(3);

      contactList = contactQuery.getAllContacts();
      System.out.println();
      contactList.forEach((obj) -> {
          System.out.println(obj.toString());
      });
  }

}

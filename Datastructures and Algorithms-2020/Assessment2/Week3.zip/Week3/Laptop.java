/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Computer;

/**
 *
 * @author 12116421
 */
public class Laptop extends Computer{
    private float weight;
    private String battery;
    private int batteryLife;
 
    public Laptop(String Name, String Model, String Make, int memory, 
            int storage, String processor, float weight,String battery,int  batteryLife)
    {
        super(Name, Model, Make, memory, storage, processor);
        this.battery = battery;
        this.weight = weight;
        this.batteryLife = batteryLife;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getBattery() {
        return battery;
    }

    public void setBattery(String battery) {
        this.battery = battery;
    }

    public int getBatteryLife() {
        return batteryLife;
    }

    public void setBatteryLife(int batteryLife) {
        this.batteryLife = batteryLife;
    }
    
    @Override
    public String toString(){
        return String.format("%.2f weight %s battery %d batterylife",super.toString(), 
                this.getBattery(),this.getBatteryLife(),this.getWeight());
    }
    
    public double price(){
        double price=0;
        int years= 2020-2015;

       if(years>3) //check year
           years=3;
       price= 500+(0.1*years); //check price according to year
      
        return price;
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Computer;

/**
 *
 * @author 12116421
 */
public abstract class Device {
   private String Name,Model,Make;


     public Device(String Name, String Make, String Model) {
        this.Name = Name;
        this.Make = Make;
        this.Model = Model;
    }
   
     public Device (){
         this.Name = "undefined";
         this.Model = "undefiend";
     }
     
     public Device (Device another){
         this(another.Name, another.Model, another.Make);
     }
     
     public String toString(){
         return String.format ("Name: %s Model: %s Make: %s", this.getName(), this.getModel(), 
                 this.getMake());
     }
     
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String Make) {
        this.Make = Make;
    }
    
    public abstract double price();
}

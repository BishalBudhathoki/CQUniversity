/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Computer;

/**
 *
 * @author 12116421
 */
public abstract class Computer extends Device {

    private int memory,storage;

    private String processor;

  public Computer(){
      this.Name = "undefined";
      this.Model = "undefiend";
  }
    
    public Computer(String Name, String Model, String Make, int memory,  int storage,
            String processor){
        super(Make, Model,Name);
        this.memory = memory;
        this.processor = processor;
        this.storage = storage;
    }
   
    public Computer(Computer another){
        this(another.getName(),another.getMake(),another.getModel(), another.memory,another.storage,another.processor);
    }
    
    public int getMemory() {
        return memory;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public int getStorage() {
        return storage;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }
    
    public String toString(){
        return String.format("%d Memory %d storage %s procesor", super.toString(),this.getStorage(),this.getProcessor(),this.getMemory());
        }
    public abstract double price();
       
  
    
}

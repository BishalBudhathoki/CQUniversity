package Computer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Computer;

/**
 *
 * @author 12116421
 */

public class Driver{
    public static void main(String[] args){
        Desktop d1=>new Desktop("HP","multimediaXP","Optical","i5",2);
        System.out.println("the total price is " +d1.price);
    }
}
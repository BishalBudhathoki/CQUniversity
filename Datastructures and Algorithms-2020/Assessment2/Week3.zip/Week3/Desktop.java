/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Computer;

/**
 *
 * @author 12116421
 */
public class Desktop extends Computer{

    private String Graphics,Keyboard,Mouse,Chipset;

    
    public Desktop(){
        this.Name = "undefined";
        this.Model = "undefiend";
      }
        
    public Desktop(String Graphics,String Keyboard,String Mouse,String Chipset) {
        this.Chipset=Chipset;
        this.Graphics=Graphics;
        this.Keyboard=Keyboard;
        this.Chipset=Chipset;
    }
    
    
    public String getGraphics(){
        return Graphics;
    }

    public void setGraphics(String Graphics) {
        this.Graphics = Graphics;
    }

    public String getKeyboard() {
        return Keyboard;
    }

    public void setKeyboard(String Keyboard) {
        this.Keyboard = Keyboard;
    }

    public String getMouse() {
        return Mouse;
    }

    public void setMouse(String Mouse) {
        this.Mouse = Mouse;
    }

    public String getChipset() {
        return Chipset;
    }

    public void setChipset(String Chipset) {
        this.Chipset = Chipset;
    }
    
    public String toString(){
        return String.format("%s Chipset %s Graphics %s Keyboard %s Mouse", super.toString(),this.getChipset(),this.getGraphics(),this.getKeyboard(),this.getMouse());
        }
    
    public double price(){
       double price=0;
       int storage= getMemory();
       if(storage>3) //check storage for price
           storage=3;
       price= 500+ ( 200 * storage ); //price calculation
       return price;  
    }
}

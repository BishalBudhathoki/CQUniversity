
package payrollsystem;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author 12116421
 * Bishal Budhathoki
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private ComboBox combo_employee_select;
    @FXML
    private Label weekly_salary;
    @FXML
    private TextField name1;
    @FXML
    private TextField SSN;
    @FXML
    private TextField weekday_salary;
    @FXML
    private Label per_hour_wage;
    @FXML
    private Label per_hour_worked;
    @FXML
    private TextField hourly_wage;
    @FXML
    private TextField txt_hour_worked;
    @FXML
    private Label Gross_Sales;
    @FXML
    private Label Commisiion_Rate;
    @FXML
    private TextField Gross_Sale_Text;
    @FXML
    private TextField Commission_rate_text;
    @FXML
    private Label Base_Salary;
    @FXML
    private TextField Base_Salary_Text;
    @FXML
    private Label Final_Result;

    @FXML
    private void  handleCalculateButtonAction(ActionEvent event){
        System.out.println("Calculate");
        String selectedEmployeeType = (String) combo_employee_select.getValue();
        if(selectedEmployeeType == "Salary Employee")
        {
String names = name1.getText();
String SSNs = SSN.getText();
            double weeklySalary = Double.parseDouble(weekday_salary.getText());
            SalariedEmployee salaryEmp = new SalariedEmployee(names, "", SSNs, weeklySalary );
            System.out.println(salaryEmp.toString());
            Final_Result.setText(Double.toString(salaryEmp.earnings()));
        }
        else if(selectedEmployeeType == "Hourly Employee")
        {
            double hourlyWage = Double.parseDouble(hourly_wage.getText());
            double hoursWorked = Double.parseDouble(txt_hour_worked.getText());
            HourlyEmployee hourlyEmp = new  HourlyEmployee("Bishal", "Budhathoki", "12116421", hourlyWage, hoursWorked);
            System.out.println(hourlyEmp.toString());
            Final_Result.setText(Double.toString(hourlyEmp.earnings()));
        }
        else if(selectedEmployeeType == "Commission Employee")
        {

            double grossSales = Double.parseDouble(Gross_Sale_Text.getText());
            double commissionRate = Double.parseDouble(Commission_rate_text.getText());
            CommissionEmployee commissionEmp = new CommissionEmployee("Bishal", "Budhathoki", "12116421", grossSales, commissionRate);
            System.out.println(commissionEmp.toString());
            Final_Result.setText(Double.toString(commissionEmp.earnings()));
        }
        else if(selectedEmployeeType == "Base Salary Commission Employee")
        {
            double grossSales = Double.parseDouble(Gross_Sale_Text.getText());
            double commissionRate = Double.parseDouble(Commission_rate_text.getText());
            double baseSalary = Double.parseDouble(Base_Salary_Text.getText());
            BasePlusCommissionEmployee baseEmp = new BasePlusCommissionEmployee("Bishal", "Budhathoki", "12116421", grossSales, commissionRate, baseSalary);
            System.out.println(baseEmp.toString());
            Final_Result.setText(Double.toString(baseEmp.earnings()));
        }


    }

    @FXML
    private void handleEmployeeTypeSelectionAction(ActionEvent event) {
        String selectedEmployeeType = (String) combo_employee_select.getValue();
        if(selectedEmployeeType == "Salary Employee")
        {
            showSalariedEmployedSection();
            hideHourlyEmployedSection();
            hideCommissionEmployeeSection();
            hideBaseSalariedSection();
        }
        else if(selectedEmployeeType == "Commission Employee")
        {
            showCommissionEmployeeSection();
            hideHourlyEmployedSection();
            hideSalariedEmployeeSection();
            hideBaseSalariedSection();
        }
        else if(selectedEmployeeType == "Hourly Employee")
        {
            showHourlyEmployedSection();
            hideSalariedEmployeeSection();
            hideCommissionEmployeeSection();
            hideBaseSalariedSection();
        }

        else if(selectedEmployeeType == "Base Salary Commission Employee")
        {
            showCommissionEmployeeSection();
            showBaseSalariedSection();
            hideHourlyEmployedSection();
            hideSalariedEmployeeSection();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        hideSalariedEmployeeSection();
        hideHourlyEmployedSection();
        hideCommissionEmployeeSection();
        hideBaseSalariedSection();
        initializeEmployeeSelectCombobox();// Adding Options for combobox SelectOptions
    }

    //Method to initialize Employee Select Combobox
    private void initializeEmployeeSelectCombobox()
    {
        combo_employee_select.getItems().removeAll(combo_employee_select.getItems());
        combo_employee_select.getItems().addAll("Salary Employee", "Hourly Employee", "Commission Employee","Base Salary Commission Employee");
//        combobox_employee_select.getSelectionModel().select("Option B");
    }


    private void hideSalariedEmployeeSection() {
        weekly_salary.setVisible(false);
        weekday_salary.setVisible(false);
    }

    private void showSalariedEmployedSection() {
        weekly_salary.setVisible(true);
        weekday_salary.setVisible(true);
    }

    private void showHourlyEmployedSection() {
        per_hour_worked.setVisible(true);
        per_hour_wage.setVisible(true);
        txt_hour_worked.setVisible(true);
        hourly_wage.setVisible(true);
    }

    private void hideHourlyEmployedSection() {
        per_hour_worked.setVisible(false);
        per_hour_wage.setVisible(false);
        txt_hour_worked.setVisible(false);
        hourly_wage.setVisible(false);
    }

    private void showCommissionEmployeeSection() {
        Gross_Sales.setVisible(true);
        Commisiion_Rate.setVisible(true);
        Commission_rate_text.setVisible(true);
        Gross_Sale_Text.setVisible(true);
    }

    private void hideCommissionEmployeeSection() {
        Gross_Sales.setVisible(false);
        Commisiion_Rate.setVisible(false);
        Commission_rate_text.setVisible(false);
        Gross_Sale_Text.setVisible(false);
    }

    private void showBaseSalariedSection() {
        Base_Salary.setVisible(true);
        Base_Salary_Text.setVisible(true);
    }

    private void hideBaseSalariedSection() {
        Base_Salary.setVisible(false);
        Base_Salary_Text.setVisible(false);
    }
    
    public void clearform()
    {
        
    }
    
}

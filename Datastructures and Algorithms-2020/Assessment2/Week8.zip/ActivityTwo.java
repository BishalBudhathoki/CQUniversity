/*
*Bishal Budhathoki
*12116421
*/
import java.util.Arrays;
import java.util.stream.Collectors;

public class ActivityTwo {

    public static void main(String[] args) {
        String[] names = {"bob", "Mary", "Andrew", "Tomy", "Michael", "Kathy", "lily", "Frances"};

        //Display original string values in the array
        System.out.printf("Original Strings: %s%n", Arrays.asList(names));

        //Display the string values converted to uppercase
        System.out.printf("Names to uppercase: %s%n"
        , Arrays.stream(names)
        .map(String::toUpperCase)
        .collect(Collectors.toList()));

        //Display the string values in ascending order
        //after filtering the values starting with g or less
        System.out.printf("Names in ascending order: %s%n", Arrays.stream(names)
        .filter(s -> s.compareToIgnoreCase("g") < 0)
        .sorted(String.CASE_INSENSITIVE_ORDER)
        .collect(Collectors.toList()));

        //Display the string values in descending order
        //after filtering the values starting with g or less
        System.out.printf("Names in descending order: %s%n", Arrays.stream(names)
                .filter(s -> s.compareToIgnoreCase("g") < 0)
                .sorted(String.CASE_INSENSITIVE_ORDER.reversed())
                .collect(Collectors.toList()));


    }
}
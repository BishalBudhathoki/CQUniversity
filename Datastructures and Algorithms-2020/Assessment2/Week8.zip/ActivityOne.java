/*
*Bishal Budhathoki
*12116421
*/

import java.security.SecureRandom;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ActivityOne {
 public static void main(String[] args) {
     //object to generate random numbers
     SecureRandom randomNumbers = new SecureRandom();
     //collect 25 integer values in a list with range 0 - 100
     List<Integer> values = randomNumbers.ints(20, 0, 101)
             .distinct()
             .boxed() //convert int to Integer
             .collect(Collectors.toList());

     System.out.println("Random numbers: " + values);

     //sort the numbers
     values.sort(Comparator.naturalOrder());
     System.out.println("Sorted natural order: " + values);

     //convert to int and sum the values
     System.out.printf("Sum of values: %s\n"
             , values.stream()
             .mapToInt(Integer::intValue)
             .sum());

     //Average of values
     System.out.printf("Average of values: %s\n"
            ,values.stream()
            .mapToDouble(Integer::intValue)
            .average()
            .getAsDouble());

     //values greater than 50
     System.out.printf("Values greater than 50: %s\n"
     , values.stream()
     .filter(value -> value > 50)
     .sorted()
     .collect(Collectors.toList()));
 }
}

/**
 *
 * Bishal Budhathoki
 * 12116421
 */
public class InvalidSubscriptionException<T> { //invalid subscription exception class
    public <T> int printArray(Object[] inputArray, int low, int high){
        int count=0;
        try{
            Object L=inputArray[low];
            Object H=inputArray[high];
            for (int i = low; i < high; i++) {
                System.out.printf("%s ", inputArray[i]);
                count++;
            }
            System.out.println("");
        } catch(NullPointerException np){
            System.out.println("Invalid Subscript Exception");
        } catch (IndexOutOfBoundsException ib) {
            System.out.println("Invalid Subscript Exception");
        }
        return count;
    }

}

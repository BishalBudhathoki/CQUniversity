/**
 *
 * Bishal Budhathoki
 * 12116421
 */
public class GenericMethodTest { //generic method class
    public static void main(String[] args) {
        Integer[] integerArray = {1,2,3,4,5,6};
        Double[] doubleArray = {1.1,2.2,3.3,4.4,5.5,6.6,7.7};
        Character[] characterArray = {'H','E','L','L','O'};

        System.out.printf("Testing generic method printArray %n");
        System.out.printf("Array integerArray contains %n");
        printArray(integerArray); //print integer array
        System.out.printf("Array Double array contains %n");
        printArray(doubleArray); //print double array
        System.out.printf("Array Character array contains %n");
        printArray(characterArray); //print character array

        System.out.println("");
        int returnValue = 0;
        System.out.printf("Testing for invalid subscript exception %n");

        InvalidSubscriptionException test1 = new InvalidSubscriptionException();

        System.out.printf("Test One ");
        returnValue = test1.printArray(integerArray, 2, 5); //pass integer value
        System.out.printf("Test one: Array integer array printed %d characters: %n",returnValue);

        System.out.printf("Test Two ");
        returnValue = test1.printArray(doubleArray, 0, 10); //pass double value
        System.out.printf("Test two: Array double array printed %d characters: %n",returnValue);

        System.out.printf("Test Three ");
        returnValue = test1.printArray(characterArray, 0, 4); //pass character value
        System.out.printf("Test three: Array character array printed %d characters: %n",returnValue);
    }

    public static <T> void printArray(T[] inputArray)
    {
        for(T element : inputArray)
            System.out.printf("%s ",element);

        System.out.println();
    }

}

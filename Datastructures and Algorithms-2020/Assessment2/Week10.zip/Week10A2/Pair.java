/**
 *
 * Bishal Budhathoki
 * 12116421
 */
public class Pair<F,S> {
    private Object F;
    private Object S;

    public Object getF(){
        return F;
    }

    public void setF(Object F){
        this.F = F;
    }

    public Object getS(){
        return S;
    }

    public void setS(Object S){
        this.S = S;
    }

    public boolean isPair(F f1, S s1){
        if(f1==s1){
            return true;
        }
        else
        {
            return false;
        }
    }

}
/**
 *
 * Bishal Budhathoki
 * 12116421
 */
public class PairTest { //pair test class
    public static void main(String[] args) {
        Pair<String,String> pair1 = new Pair<>();
        pair1.setS("Test");
        pair1.setF("Two");

        System.out.println("Test 1: " + pair1.isPair("one", "one"));
        System.out.println("Test 2: " + pair1.isPair("one", "two"));

        Pair<Integer,Integer> pair2 = new Pair<>();
        System.out.println("Test 3: " + pair2.isPair(1, 1));
    }
}
package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import sample.Contact;
import sample.CreateSequentialFile;
import sample.ReadSequentialFile;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
/**
 *
 * @author Bishal Budhathoki 12116421
 */
public class ContactsController {

    //open file
    CreateSequentialFile openf = new CreateSequentialFile();
    ReadSequentialFile read = new ReadSequentialFile();

    /**
     * Initializes the controller class.
     */
    @FXML
    private Label tipPercentageLabel;

    @FXML
    private TextField txtFirstName,
            txtLastName,
            txtEmail,
            txtPhoneNumber;
    @FXML
    private ComboBox cmbChooseName;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnModify;
    @FXML
    private Button btnDelete,
            btnExit;
    @FXML
    private AnchorPane rootWindow;
    private ArrayList<Contact> contactsList;
    private String nameChosen = "";
    private int modifiedIndex = 0;

    public void initialize() {
        /**
         * Once you set prompt text in .fxml file this line is not required -->
         * cmbChooseName = new ComboBox();
         *
         * R
         */
        //cmbChooseName.getItems().addAll("Choose a name");
        contactsList = new ArrayList<>();
        System.out.println("start");
        // TODO

        ReadSequentialFile.openFile();
        ReadSequentialFile.readRecords();

    }

    @FXML
    public void addButtonPressed(ActionEvent add) {
        String fname = "",
                lname = "",
                email = "",
                phone = "";
        Contact con = new Contact();
        try {
            if (txtFirstName.getText() != null) {
                fname = txtFirstName.getText();
                con.setFirstName(fname);
            }
            if (txtLastName.getText() != null) {
                lname = txtLastName.getText();
                con.setLastName(lname);
            }
            if (txtEmail.getText() != null) {
                email = txtEmail.getText();
            }
            if (txtPhoneNumber.getText() != null) {
                phone = txtPhoneNumber.getText();
                con.setPhoneNumber(phone);
            }

            contactsList.add(new Contact(fname, lname, email, phone));
           // System.out.println(contactsList );
            cmbChooseName.getItems().addAll(contactsList.get(contactsList.size()-1).getFirstName());
            CreateSequentialFile.openFile();
            CreateSequentialFile.addRecords(contactsList);
            CreateSequentialFile.closeFile();

        } catch (InputMismatchException inputmismatch) {
            System.out.println(inputmismatch.getMessage());
        }

        System.out.println(contactsList);

    }

    @FXML
    public void setOnAction(ActionEvent event) {

        //String fname ="";
        nameChosen = cmbChooseName.getSelectionModel().getSelectedItem().toString();
        System.out.println(nameChosen);

    }

    @FXML
    public void displayButtonPressed(ActionEvent mod) {
        Contact display = new Contact();
        // System.out.println("modify");
        for (int i = 0; i < contactsList.size(); i++) {
            if (contactsList.get(i).getFirstName().equalsIgnoreCase(nameChosen)) {
                //  System.out.println(nameChosen);
                display = contactsList.get(i);

                System.out.println(display);
            }
        }
        txtFirstName.setText(display.getFirstName());
        txtLastName.setText(display.getLastName());
        txtEmail.setText(display.getEmail());
        txtPhoneNumber.setText(display.getPhoneNumber());
    }

    @FXML
    public void deleteButtonPressed(ActionEvent del) {
        // System.out.println("dlete");
        Contact removed = new Contact();
        // int deleted =0;
        for (int i = 0; i < contactsList.size(); i++) {
            if (contactsList.get(i).getFirstName().equalsIgnoreCase(nameChosen)) {
                // System.out.println(nameChosen);
                removed = contactsList.get(i);
                break;
            }
        }
        contactsList.remove(removed);
        //cmbChooseName.getSelectionModel().clearSelection();
        cmbChooseName.getSelectionModel().selectFirst();
        cmbChooseName.getItems().remove(removed.getFirstName());

    }

    @FXML
    public void exitButtonPressed(ActionEvent ex) {
        System.out.println("exit");
        System.exit(0);
//        rootWindow.setDisable(true);
    }


}

package sample;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;

/**
 *
 * @author Bishal Budhathoki 12116421
 */
public class ContactsMain extends Application {
    
   
    
     @Override
    public void start(Stage primaryStage) throws Exception {
     //Use the created fxml file to load the Graphics components
         URL url = new File("src/sample/ContactsFXML.fxml").toURI().toURL();
         Parent root = FXMLLoader.load(url);
     //   Parent root = FXMLLoader.load(getClass().getResource("ContactsFXML.fxml"));
        Scene scene = new Scene(root);
        
        // modify the Window's title to Tip Calculator 
        primaryStage.setTitle("Contacts");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

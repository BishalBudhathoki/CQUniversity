package sample;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.Serializable;
import java.util.InputMismatchException;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bishal Budhathoki 12116421
 */
public class Contact implements Serializable {
    String firstName;
    String lastName;
    String email;
    String phoneNumber;
    private final String pattern="[A-Z][a-z]*";


    public Contact(String firstName, String lastName, String email, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Contact() {
        this.firstName = "not set in default";
    }
    public Contact (Contact another){
        this.firstName = another.firstName;
        this.lastName = another.lastName;
        this.email = another.email;
        this.phoneNumber = another.phoneNumber;
    }
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) throws InputMismatchException{
        if(firstName.matches(pattern))
            this.firstName = firstName;
        else
            throw new InputMismatchException("Firstname should have be starting with Caps and contain only alphabets");
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if(firstName.matches(pattern))
            this.lastName = lastName;
        else
            throw new InputMismatchException("Lastname should have be starting with Caps and contain only alphabets");
        
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber)throws InputMismatchException {
        /**
         * Validation works for these format phone number
         1234567890
         123-456-7890
         123-456-7890 x1234
         123-456-7890 ext1234
         (123)-456-7890
         123.456.7890
         123 456 7890
        **/
        if (phoneNumber.matches("\\d{10}")) this.phoneNumber = phoneNumber;
            //validating phone number with -, . or spaces
        else if(phoneNumber.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}")) this.phoneNumber = phoneNumber;
            //validating phone number with extension length from 3 to 5
        else if(phoneNumber.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}"))this.phoneNumber = phoneNumber;
            //validating phone number where area code is in braces ()
        else if(phoneNumber.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}")) this.phoneNumber = phoneNumber;
        else {
            throw new InputMismatchException("Phone number should be 10 digits");
            

        }
        }
      //  String phonePattern = " { \\d{4}\\s\\d{3}\\s\\d{3} }";
   //     if(phoneNumber.matches(phonePattern))
      //     this.phoneNumber = phoneNumber;
     //   else
      //     throw new InputMismatchException("Phone number should be 10 digits");

   
    @Override
    public String toString(){
        return String.format("\nName: %-10s %s   email: %-12s phone: %10s\n", this.getFirstName(),this.getLastName(),this.getEmail(),this.getPhoneNumber());
    }
    
}

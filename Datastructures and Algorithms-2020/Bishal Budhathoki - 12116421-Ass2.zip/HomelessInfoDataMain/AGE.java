package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public enum AGE {
    FiftyToFifyFour("50-54"),
    FiftyToFifyNine("55-59"),
    SixtyToSixtyFour("60-64"),
    SixtyFiveOver("over 65");
    private String ageVal;

    private AGE(String value) {
        ageVal = value;
    }

    //get enum
    public String getStringValue() {
        return this.ageVal;
    }

    //set age enum
    public static AGE getAge(String age) throws IllegalArgumentException {
        age = age.trim();
        for (AGE ageEnum : AGE.values()) {
            if (ageEnum.getStringValue().equals(age)) {
                return ageEnum;
            }
        }
        throw new IllegalArgumentException("Age" + age + "is not found");
    }
}
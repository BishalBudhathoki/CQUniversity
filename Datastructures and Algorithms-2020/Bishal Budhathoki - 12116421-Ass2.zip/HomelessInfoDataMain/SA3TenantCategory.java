/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public class SA3TenantCategory extends Person {

    WEEKLY_INCOME incomeRange;
    String incomeSource;
    Location location;

    public SA3TenantCategory() { //default constructor
        super();
    }

    public SA3TenantCategory(String incomeSource) {
        this.incomeSource = incomeSource;

    }

    public SA3TenantCategory(Location location, WEEKLY_INCOME incomeCategory, String incomeSource, AGE age, GENDER gender) {
        //parameterised constructor
        super(age, gender);
        this.incomeRange = incomeCategory;
        this.incomeSource = incomeSource;
        this.location = location;
    }

    // accessors and mutators
    public WEEKLY_INCOME getIncomeRange() {

        return incomeRange;
    }

    public void setIncomeRange(WEEKLY_INCOME incomeRange) {

        this.incomeRange = incomeRange;

    }

    public String getIncomeSource() {

        return incomeSource;

    }

    public void setIncomeSource(String incomeSource) {

        this.incomeSource = incomeSource;
    }

    public Location getlocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {

        return String.format("%s %-20s %-15s %s", this.location.toString(), this.incomeRange, this.incomeSource, super.toString());
    }
}

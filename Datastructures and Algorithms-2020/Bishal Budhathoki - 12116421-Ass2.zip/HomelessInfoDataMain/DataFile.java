/*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
 */
package HomelessInfoDataMain;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public class DataFile {

    //input scanner to read file
    private static Scanner scaninput;
    // create riskyperson arraylist
    private ArrayList<RiskyPersons> riskyPersons
            = new ArrayList<RiskyPersons>();
    LinkedList<RiskyPersons> riskyPersonss = new LinkedList<>();
    //create locatoin arraylist to store locations
    private ArrayList<Location> locations = new ArrayList<Location>();
    LinkedList<Location> locationss = new LinkedList<>();

    //filename path and file name read
    private final String fileName = "src\\futureDemand.csv";

    public LinkedList<RiskyPersons> getRiskyPersons() {

        return riskyPersonss; // return riskyperson arraylist
    }

    public LinkedList<Location> getLocations() {

        return locationss; //return location arraylist
    }

    public void addLocation(Location location) {
        locationss.add(location); //add location to linked list
    }

    public void initilizeDataFile() {
        //this class opens, reads and closes a file
        openFile();
        readFile();
        closeFile();
    }

    public void openFile() {
//code to open file
        try {
            scaninput = new Scanner(Paths.get(fileName));

        } catch (IOException ioException) {
            System.err.println("Error Opening File. Please check the file");
            System.exit(1);

        }
    }

    public void readFile() {
        //codes to readfile
        String lineRead;
        String[] entryValues = new String[19];
        String[] genderValues = new String[19];
        String[] ageGroups = new String[19];
        String[] employeeSources = new String[19];

        try {
            lineRead = scaninput.nextLine();
            genderValues = lineRead.split(",");

            lineRead = scaninput.nextLine();
            ageGroups = lineRead.split(",");

            lineRead = scaninput.nextLine();
            employeeSources = lineRead.split(",");

            while (scaninput.hasNext()) {
                lineRead = scaninput.nextLine();
                entryValues = lineRead.split(",");

                Location location = createLocation(entryValues[0],
                        entryValues[1]);
                addLocation(location);

                WEEKLY_INCOME incomeCategory = WEEKLY_INCOME.
                        getWeeklyIncome(entryValues[2]);

                for (int i = 3; i < 19; i++) {
                    try {
                        GENDER gender = GENDER.getGender(genderValues[i]);
                        AGE age = AGE.getAge(ageGroups[i]);
                        String incomeSource = employeeSources[i];
                        int numberOfPerson = Integer.parseInt(entryValues[i]);
                        SA3TenantCategory sa3TenantCategory
                                = new SA3TenantCategory(location,
                                incomeCategory, incomeSource,
                                age, gender);

                        RiskyPersons riskyPerson = new RiskyPersons(
                                numberOfPerson, sa3TenantCategory);
                        riskyPersonss.add(riskyPerson);
                        ;
                    } catch (Exception e) {
                        System.err.println(e.getMessage());
                    }
                }
            }
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from the file. Closing");
        }

    }

    // close file and terminate application
    public static void closeFile() {
        if (scaninput != null) {
            scaninput.close();
        }
    }

    public Location createLocation(String sa3Code, String address) {
        Location locate = new Location();
        locate.setSa3Code(sa3Code);
        locate.setAddress(address);

        locate.getSa3Code();
        locate.getAddress();

        return locate;

    }

}

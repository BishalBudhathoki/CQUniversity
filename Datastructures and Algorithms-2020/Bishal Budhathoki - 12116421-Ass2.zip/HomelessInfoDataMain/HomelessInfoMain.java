/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.File;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public class HomelessInfoMain extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("./HomelessInfo.fxml"));
        Parent content = loader.load();
        Scene scene = new Scene(content);
        stage.setTitle("Homeless Information System");//set title of the tab
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}

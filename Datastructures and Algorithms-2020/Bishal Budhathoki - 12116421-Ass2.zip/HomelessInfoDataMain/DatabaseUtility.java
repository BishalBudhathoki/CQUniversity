/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public class DatabaseUtility {

    private final String MySQL_URL;
    final String DB_URL;
    private Connection sqlConnection, dbConnection;
    private Statement statement;
    private final String dbCreateSQL;
    private final String username;
    private final String password;
    private DatabaseMetaData dbmd;
    private PreparedStatement createTableLocations;
    private PreparedStatement createTableRiskyPersons;
    private PreparedStatement insertLocation;
    private PreparedStatement createTableWeeklyIncome;
    private PreparedStatement createTableAge;
    private PreparedStatement createTableGender;

    private PreparedStatement createTableSA3TenantCategories;
    private PreparedStatement insertRiskyPersonData;
    private PreparedStatement insertWeeklyIncome;
    private PreparedStatement insertGender;

    private PreparedStatement insertAge;

    private PreparedStatement insertSa3TenantCategory;

    //linkedlist creation
    LinkedList<RiskyPersons> riskyPersonsList = new LinkedList<>();
    LinkedList<SA3TenantCategory> sa3TenantCategory = new LinkedList<>();
    LinkedList<Location> locationsList = new LinkedList<>();
    LinkedList<Location> newLocationList = new LinkedList<>();

    public DatabaseUtility() {
        MySQL_URL = "jdbc:mysql://localhost:3306";
        DB_URL = MySQL_URL + "/HomelessInfo";
        username = "Bishal";
        password = "576228";

        statement = null;

        //SQL Query to create Database
        dbCreateSQL = "CREATE DATABASE HomelessInfo";
        boolean dbExists = false;
        boolean dbcreated = false;
        String DatabaseName = "";

        //Registering MYSQL database driver
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("MYSQL JDBC Driver not found");
            e.printStackTrace();
            return;
        }
        System.out.println("MYSQL JDBC driver is registered.");

        //Connect to MYSQL
        try {
            sqlConnection = DriverManager.getConnection(MySQL_URL, username, password);
            statement = sqlConnection.createStatement();
            System.out.println("MySQL connected");
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;// false;
        }

        //Check if database exists or not.
        try {
            //get the list of databases
            ResultSet dbData = sqlConnection.getMetaData().getCatalogs();
            while (dbData.next()) {
                // Get the database name, which is at position 1
                DatabaseName = dbData.getString(1);
                // Test print of database names, can be removed
                System.out.printf("%s ", DatabaseName);
                if (DatabaseName.equalsIgnoreCase("HomelessInfo")) {
                    dbExists = true;
                }
            }
            if (dbExists == true) {
                System.out.println("Database already exists");
            }
            if (!dbExists) //if database doesn't exist create database executing the query.
            {
                System.out.println("Database not found: Creating Database");
                statement.executeUpdate(dbCreateSQL);
            }
            if (sqlConnection != null) {
                sqlConnection.close();  //close the existing connection to connect to MySql
            }
            //Connect to HomelessInfo database
            dbConnection = DriverManager.getConnection(DB_URL, username, password);
            statement = dbConnection.createStatement();
            QueriesMethods();
            createTables();
            storerecords();
            locationLoadingMethod();

        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            e.printStackTrace();
        }
    }

    // prepare string queries
    public void QueriesMethods() throws SQLException {
        createTableLocations = dbConnection.prepareStatement("CREATE TABLE IF"
                + " NOT EXISTS "
                + "LOCATIONS(L_ID INTEGER(10) not NULL AUTO_INCREMENT, "
                + "SA3Code INTEGER not NULL,Name LONGTEXT not NULL,"
                + "CONSTRAINT L_PK PRIMARY KEY (L_ID))");

        createTableRiskyPersons = dbConnection.prepareStatement("CREATE TABLE"
                + " IF NOT EXISTS "
                + "RISKYPERSONS(R_ID INTEGER(10) not NULL AUTO_INCREMENT,"
                + "S_ID INTEGER(10) not NULL,"
                + "numberOfPerson INTEGER(10) not NULL,"
                + "CONSTRAINT R_PK PRIMARY KEY (R_ID))");
//        System.out.println("Tables created ");
        createTableWeeklyIncome = dbConnection.prepareStatement("CREATE TABLE"
                + " IF NOT EXISTS WEEKLY_INCOME(W_ID INTEGER(10) not NULL"
                + " AUTO_INCREMENT,incomeCategory ENUM"
                + "('Negative/Nil income','$1-$399','$400-$599','$600-$999')"
                + " not NULL,CONSTRAINT W_PK PRIMARY KEY (W_ID))");

        createTableGender = dbConnection.prepareStatement("CREATE TABLE "
                + "IF NOT EXISTS GENDER(G_ID INTEGER(10) not NULL"
                + " AUTO_INCREMENT,gender ENUM('Male','Female') not NULL,"
                + "CONSTRAINT G_PK PRIMARY KEY (G_ID))");

        createTableSA3TenantCategories = dbConnection.prepareStatement("CREATE "
                + "TABLE IF NOT EXISTS "
                + "SA3TenantCategory(S_ID INTEGER(10) not NULL AUTO_INCREMENT,"
                + "L_ID INTEGER not NULL,"
                + "W_ID INTEGER not NULL,"
                + "A_ID INTEGER not NULL,"
                + "G_id Integer not Null,"
                + "incomeSource VARCHAR(30) not NULL,"
                + "CONSTRAINT S_PK PRIMARY KEY (S_ID))");

        createTableAge = dbConnection.prepareStatement("CREATE TABLE"
                + " IF NOT EXISTS AGE(A_ID INTEGER(10) not NULL AUTO_INCREMENT,"
                + "ageGroup ENUM('50-54','55-59','60-64','over 65') not NULL,"
                + "CONSTRAINT A_PK PRIMARY KEY (A_ID))");

        //execute queries
        //insert sql
        insertLocation = dbConnection.prepareStatement("INSERT INTO " +
                "LOCATIONS (SA3Code, Name) VALUES (?,?)");
        insertRiskyPersonData = dbConnection.prepareStatement("INSERT INTO " +
                "RISKYPERSONS(S_ID,numberOfPerson) VALUES (?,?)");
        insertSa3TenantCategory = dbConnection.prepareStatement("INSERT INTO " +
                "SA3TenantCategory (L_ID,W_ID,A_ID,G_ID,incomeSource) VALUES (?,?,?,?,?)"
                , Statement.RETURN_GENERATED_KEYS);

    }

    //execute queries to create tables
    public void createTables() throws SQLException {
        createTableLocations.executeUpdate();
        createTableRiskyPersons.executeUpdate();
        createTableWeeklyIncome.executeUpdate();
        createTableGender.executeUpdate();
        createTableAge.executeUpdate();
        createTableSA3TenantCategories.executeUpdate();

    }

    public void storerecords() throws SQLException {
        //call data file to store records
        DataFile df = new DataFile();
        df.initilizeDataFile();
        riskyPersonsList = df.getRiskyPersons();//get riskyperson arraylist
        locationsList = df.getLocations();

        //Store Location Details
        PreparedStatement check = dbConnection.prepareStatement("SELECT * FROM LOCATIONS");
        ResultSet trs = check.executeQuery();
        if (trs.next()) {
            System.out.println("location table is not empty");
        } else {
            System.out.println("location table is empty");
            //insert data in location table
            //first check if location repeats
            String sa = "";//temporary variable
            for (Location locate : locationsList) {
                locate.getSa3Code();
                if (locate.getSa3Code().equals(sa)) {
                    //check if SA3code gets repeat
                } else {
                    newLocationList.add(locate);
                }
                sa = locate.getSa3Code();

            }

            for (Location l : newLocationList) {
                try {
                    addNewLocation(l.getSa3Code(), l.getAddress());
                } catch (SQLException ex) {
                    Logger.getLogger(HomelessInfoController.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        //Store Age details
        check = dbConnection.prepareStatement("SELECT * FROM AGE");
        ResultSet ars = check.executeQuery();
        if (ars.next()) {
            System.out.println("Age table is not empty");
        } else {
            System.out.println("Age table is empty");
            //insert data in age table
            insertAge = dbConnection.prepareStatement("INSERT " +
                    "INTO AGE (ageGroup) VALUES('50-54'),('55-59'),('60-64'),('over 65')");
            insertAge.executeUpdate();
        }

        //Store Weekly_Income details
        check = dbConnection.prepareStatement("SELECT * FROM WEEKLY_INCOME");
        ResultSet wrs = check.executeQuery();
        if (wrs.next()) {
            System.out.println("Weekly_Income table table is not empty");
        } else {
            System.out.println("Weekly_Income table is empty");
            //insert data in Weekly_Income table
            insertWeeklyIncome = dbConnection.prepareStatement("INSERT " +
                    "INTO WEEKLY_INCOME (incomeCategory) VALUES ('Negative/Nil income')," +
                    "('$1-$399'),('$400-$599'),('$600-$999')");
            insertWeeklyIncome.executeUpdate();
        }

        //Store Gender details
        check = dbConnection.prepareStatement("SELECT * FROM GENDER");
        ResultSet grs = check.executeQuery();
        if (grs.next()) {
            System.out.println("GENDER table is not empty");
        } else {
            System.out.println("GENDER table is empty");
            //insert data in GENDER table
            insertGender = dbConnection.prepareStatement("INSERT " +
                    "INTO GENDER (gender) VALUES('Male'),('Female')");
            insertGender.executeUpdate();
        }

        //Store SA3TENANT Details
        check = dbConnection.prepareStatement("SELECT * FROM SA3TENANTCATEGORY");
        ResultSet srs = check.executeQuery();
        if (srs.next()) {
            System.out.println("SA3TENANTCATEGORY table is not empty");
        } else {
            System.out.println("SA3TENANTCATEGORY table is empty");
            //insert data in SA3TENANTCATEGORY table
            for (RiskyPersons rp : riskyPersonsList) {

                //Compare weekly_income
                WEEKLY_INCOME ic = rp.sa3TenantCategory.getIncomeRange();
                int w_Id;
                if (ic.getStringValue() == "Negative/Nil income") {
                    w_Id = 1;
                } else if (ic.getStringValue() == "$1-$399") {
                    w_Id = 2;

                } else if (ic.getStringValue() == "$400-$599") {
                    w_Id = 3;

                } else {
                    w_Id = 4;

                }

                //compare gender
                GENDER g = rp.sa3TenantCategory.getGender();

                int g_Id;
                if (g.toString() == "MALE") {
                    g_Id = 1;
                } else {
                    g_Id = 2;
                }

                AGE a = rp.sa3TenantCategory.getAge();
                int a_Id;

                if (a.getStringValue() == "50-54") {
                    a_Id = 1;
                } else if (a.getStringValue() == "55-59") {
                    a_Id = 2;

                } else if (a.getStringValue() == "60-64") {
                    a_Id = 3;

                } else {
                    a_Id = 4;
                }

                String sa3c = rp.sa3TenantCategory.location.getSa3Code();
                String LID = "";

                String locationIDquery = String.format("Select L_ID FROM Locations WHERE SA3Code = %s", sa3c);
                PreparedStatement stmt = dbConnection.prepareStatement(locationIDquery);

                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    LID = rs.getString(1);
                }
                int newlid = Integer.parseInt(LID);
                addSA3TenanatCategory(newlid, w_Id, a_Id, g_Id,
                        rp.sa3TenantCategory.getIncomeSource());

            }
        }
        //Store RISKYPERSON Details
        check = dbConnection.prepareStatement("SELECT * FROM RISKYPERSONS");
        ResultSet rrs = check.executeQuery();
        if (rrs.next()) {
            System.out.println("RISKYPERSONS table is not empty");
        } else {
            System.out.println("RISKYPERSONS table is empty");
            //insert data in RISKYPERSONS table
            int i = 1;
            for (RiskyPersons rp : riskyPersonsList) {

                addriskyPerson(i, rp.getNumberOfPerson());
                i++;
            }
        }

    }

    // return tenant id
    public int getSA3TenantId(int locationId, int incomeCateogryId, int ageGroupId,
                              int genderId, String incomeSource) throws SQLException {
        PreparedStatement stmt = dbConnection.prepareStatement("SELECT * " +
                "FROM SA3TENANTCATEGORY WHERE L_ID = ? AND W_ID=? AND A_ID=? AND G_ID=? AND incomeSource=?");
        stmt.setInt(1, locationId);
        stmt.setInt(2, incomeCateogryId);
        stmt.setInt(3, ageGroupId);
        stmt.setInt(4, genderId);
        stmt.setString(5, incomeSource);

        ResultSet result = stmt.executeQuery();

        if (result.next()) {
            return result.getInt("S_ID");
        } else {
            return 0;
        }
    }

    //increment riskiy person number
    public void incrementRiskyPersonCount(int SA3TenantId) throws SQLException {
        System.out.println(SA3TenantId);
        PreparedStatement stmt = dbConnection.prepareStatement("UPDATE RISKYPERSONS " +
                "SET numberOfPerson=numberOfPerson + 1 WHERE S_ID=?");

        stmt.setInt(1, SA3TenantId);

        stmt.executeUpdate();
    }

    //add new location
    public void addNewLocation(String SA3Code, String Name) throws SQLException {
        insertLocation.setString(1, SA3Code);
        insertLocation.setString(2, Name);
        insertLocation.executeUpdate();
    }

    // add new tenant category in database
    public int addSA3TenanatCategory(int l_Id, int w_Id, int a_Id, int g_Id, String incomeSource) throws SQLException {
        insertSa3TenantCategory.setInt(1, l_Id);
        insertSa3TenantCategory.setInt(2, w_Id);
        insertSa3TenantCategory.setInt(3, a_Id);
        insertSa3TenantCategory.setInt(4, g_Id);
        insertSa3TenantCategory.setString(5, incomeSource);
        insertSa3TenantCategory.executeUpdate();

        ResultSet result = insertSa3TenantCategory.getGeneratedKeys();

        if (result.next()) {
            return result.getInt(1);
        } else {
            return 0;
        }
    }

    // add risky persons in database
    public void addriskyPerson(int S_Id, int numberOfPerson) throws SQLException {
        insertRiskyPersonData.setInt(1, S_Id);
        insertRiskyPersonData.setInt(2, numberOfPerson);
        insertRiskyPersonData.executeUpdate();
    }

    public LinkedList<Location> locationLoadingMethod() throws SQLException {
        String query = "SELECT * FROM LOCATIONS";
        PreparedStatement stmt = dbConnection.prepareStatement(query);
        ResultSet result = stmt.executeQuery();
        LinkedList<Location> LocationDisplayList = new LinkedList<>();
        while (result.next()) {
            LocationDisplayList.add(new Location(
                    result.getString(2),
                    result.getString(3)));

        }
        System.out.println(LocationDisplayList);
        return LocationDisplayList;
    }

    public LinkedList<RiskyPersons> optionOne() throws SQLException {
        String optionOneQuery = "SELECT * FROM RISKYPERSONS WHERE G_ID = 1";
        return getRiskyPersons(optionOneQuery);
    }

    public int getLocationId(int sa3Code) throws SQLException {
        PreparedStatement locationIdQuery = dbConnection.prepareStatement("SELECT * " +
                "FROM LOCATIONS WHERE SA3Code = ?");
        locationIdQuery.setInt(1, sa3Code);
        ResultSet result = locationIdQuery.executeQuery();

        if (result.next()) {
            System.out.println(result.getInt("L_ID"));
            return result.getInt("L_ID");
        }

        return 0;
    }

    public int getAgeId(String ageGroup) throws SQLException {
        PreparedStatement locationIdQuery = dbConnection.prepareStatement("SELECT * " +
                "FROM AGE WHERE ageGroup = ?");
        locationIdQuery.setString(1, ageGroup);
        ResultSet result = locationIdQuery.executeQuery();

        if (result.next()) {
            System.out.println(result.getInt("A_ID"));
            return result.getInt("A_ID");
        }

        return 0;
    }

    public int getGenderId(String gender) throws SQLException {
        PreparedStatement locationIdQuery = dbConnection.prepareStatement("SELECT * " +
                "FROM GENDER WHERE gender = ?");
        locationIdQuery.setString(1, gender);
        ResultSet result = locationIdQuery.executeQuery();

        if (result.next()) {
            System.out.println(result.getInt("G_ID"));
            return result.getInt("G_ID");
        }

        return 0;
    }

    public int getWeeklyIncomeId(String income) throws SQLException {
        PreparedStatement locationIdQuery = dbConnection.prepareStatement("SELECT * " +
                "FROM WEEKLY_INCOME WHERE incomeCategory = ?");
        locationIdQuery.setString(1, income);
        ResultSet result = locationIdQuery.executeQuery();

        if (result.next()) {
            System.out.println(result.getInt("W_ID"));
            return result.getInt("W_ID");
        }

        return 0;
    }

    public LinkedList<RiskyPersons> RiskyloadingMethod() throws SQLException {
        String query = "SELECT * FROM RISKYPERSONS INNER JOIN SA3TENANTCATEGORY " +
                "ON RISKYPERSONS.S_ID = SA3TENANTCATEGORY.S_ID ";
        return getRiskyPersons(query);
    }

    // return risky person list from database
    private LinkedList<RiskyPersons> getRiskyPersons(String optionOneQuery) throws SQLException {
        PreparedStatement stmt1 = dbConnection.prepareStatement(optionOneQuery);
        PreparedStatement location = dbConnection.prepareStatement("SELECT * FROM lOCATIONS WHERE L_ID=?");
        PreparedStatement weeklyIncome = dbConnection.prepareStatement("SELECT * FROM Weekly_income WHERE W_ID=?");
        PreparedStatement ageGroup = dbConnection.prepareStatement("SELECT * FROM AGE WHERE A_ID=?");
        PreparedStatement gender = dbConnection.prepareStatement("SELECT * FROM GENDER WHERE G_ID=?");

        ResultSet result = stmt1.executeQuery();
        System.out.println(result);
        LinkedList<RiskyPersons> RiskyPersonOptionOneDisplayList = new LinkedList<>();
        while (result.next()) {
            int numofpeep = result.getInt("numberOfPerson");
            int sid = result.getInt("S_ID");
            int lid = result.getInt("L_ID");
            int wid = result.getInt("W_ID");
            int aid = result.getInt("A_ID");
            int gid = result.getInt("G_ID");
            String incomeSource = result.getString("incomeSource");

            int SA3Code = 0;
            String locationName = "";
            String incomeCategory = "";
            String ageGroupValue = "";
            String genderValue = "";

            location.setInt(1, lid);
            weeklyIncome.setInt(1, wid);
            ageGroup.setInt(1, aid);
            gender.setInt(1, gid);

            ResultSet locationResult = location.executeQuery();
            ResultSet weeklyIncomeResult = weeklyIncome.executeQuery();
            ResultSet agegroupResult = ageGroup.executeQuery();
            ResultSet genderResult = gender.executeQuery();

            if (locationResult.next()) {
                locationName = locationResult.getString("Name");
                SA3Code = locationResult.getInt("SA3Code");
            }

            if (weeklyIncomeResult.next()) {
                incomeCategory = weeklyIncomeResult.getString("incomeCategory");

            }

            if (agegroupResult.next()) {
                ageGroupValue = agegroupResult.getString("ageGroup");
            }

            if (genderResult.next()) {
                genderValue = genderResult.getString("gender");

            }

            Location loc = new Location(Integer.toString(SA3Code), locationName);
            SA3TenantCategory SA3TenantCategory = new SA3TenantCategory(loc,
                    WEEKLY_INCOME.getWeeklyIncome(incomeCategory), incomeSource,
                    AGE.getAge(ageGroupValue), GENDER.getGender(genderValue));
            RiskyPersons riskyPerson = new RiskyPersons(numofpeep, SA3TenantCategory);

            RiskyPersonOptionOneDisplayList.add(riskyPerson);
        }

        return RiskyPersonOptionOneDisplayList;
    }

}

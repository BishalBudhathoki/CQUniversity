/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomelessInfoDataMain;

import java.net.URL;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public class HomelessInfoController implements Initializable {

    //fxml components declaration
    @FXML
    private TabPane tabPaneModel, tabPaneOneModel;

    @FXML
    private Label label, enterLocLabel;

    @FXML
    private ComboBox incomeRange, age, incomeSource,
            displayComboBox, SA3comboBox,
            locationDisplayComboBox, genderComboBox;

    private String income_source = "",
            ages = "", income_range = "",
            display_Data = "", genders = "";

    @FXML
    private Button nextTab, nextTabOne, addLocationBtn,
            addTenantDataBtn, showReportBtn;

    @FXML
    private TextField location, SA3Code;

    @FXML
    private TextArea displayBox;

    private String selectedOption;

    DatabaseUtility databaseUtility = new DatabaseUtility();
    //string declaration to check condition and print data
    String incomeSourceCheck = "";
    String genderCheck = "";
    String incomeRangeCheck = "";
    //string end

    //Riskypersons arraylist to store data
    LinkedList<RiskyPersons> riskyPersonsList = new LinkedList<>();
    //Location arraylist to store location details
    LinkedList<Location> locationsList = new LinkedList<>();
    LinkedList<Location> newLocationList = new LinkedList<>();

    private String SA3CodeSelection = "", locationSelect = "", ageSelect = "",
            incomeSelect = "",
            incomeRangeSelect = "", genderSelect = "", incomeSourceSelect = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Dropdown menu initialization
        //Dropdown list for income range
        this.incomeRange.getItems().addAll("Negative/Nil income",
                "$1-$399", "$400-$599", "$600-$999");
        //Dropdown list for income source
        this.incomeSource.getItems().addAll("Employed", "Other");
        //Dropdown list for age group
        this.age.getItems().addAll("50-54", "55-59", "60-64", "over 65");
        //Dropdown list for gender
        this.genderComboBox.getItems().addAll("Male", "Female");

        //Dropdown list for displyaing report
        this.displayComboBox.getItems().addAll(
                "All males at the risk of homelessness",
                "All people in a chosen location at the risk of homelessness",
                "All females at the risk of homelessness",
                "All at the risk of homelessness");

        location.setText(""); //set textfield empty
        displayBox.setText(""); // set displaybox empty
        SA3comboBox.getSelectionModel().clearSelection();//funciton to clear selection box
        DataFile dataFile = new DataFile();
        dataFile.initilizeDataFile();
        riskyPersonsList = dataFile.getRiskyPersons();//get riskyperson arraylist

        //inserting location to database
        DatabaseUtility utility = new DatabaseUtility();
        try {
            locationsList = utility.locationLoadingMethod(); //database store in this linkedlist
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        for (int i = 0; i < locationsList.size(); i++) {
            //loading location in sa3combobox of Location tab
            SA3comboBox.getItems().add(i,
                    locationsList.get(i).displayLocation());
            //loading location details in location combo box of Reports tab
            locationDisplayComboBox.getItems().add(i,
                    locationsList.get(i).displayLocation());

        }
        // loading adding upto here
        tabPaneModel.getSelectionModel().selectedIndexProperty()
                .addListener(new ChangeListener<Number>() {
                    @Override
                    public void changed(ObservableValue<? extends Number> ov,
                                        Number oldValue, Number newValue) {
                        if ((oldValue.intValue() == 1
                                || oldValue.intValue() == 2
                                || oldValue.intValue() == 3)
                                && newValue.intValue() == 0) {
                            location.setText("");
                            SA3Code.setText("");
                        }
                    }
                });
    }

    @FXML
    private void incomeSourceMethod(ActionEvent event) {
        income_source = (String) this.incomeSource.getValue();
    }

    @FXML
    private void incomeRangeMethod(ActionEvent event) {
        income_range = (String) this.incomeRange.getValue();
    }

    @FXML
    private void ageMethod(ActionEvent event) {
        ages = (String) this.age.getValue();
    }

    @FXML
    private void genderMethod(ActionEvent event) {
        genders = (String) this.genderComboBox.getValue();
    }

    @FXML
    private void displayDataMethod(ActionEvent event) {
        display_Data = (String) this.displayComboBox.getValue();
    }

    @FXML
    private void NextTabMethod(ActionEvent event) throws SQLException {

        // load new locations from database
        locationsList = databaseUtility.locationLoadingMethod();
        this.tabPaneModel.getSelectionModel().selectNext();
        clearLocationTab();
    }

    @FXML
    private void NextTabOneMethod(ActionEvent event) throws SQLException {
        riskyPersonsList = databaseUtility.RiskyloadingMethod();
                this.tabPaneModel.getSelectionModel().selectNext();
        clearFields();
    }

    //Method to add location
    @FXML
    private void addLocationMethod(ActionEvent event) {

        try {
            //variable delarations
            String scode, locationName, verifyScode, verifyLocation;
            scode = SA3Code.getText().trim();
            locationName = location.getText().trim();
            verifyScode = scode;
            verifyLocation = locationName;

            String scodePattern = "^5\\d{4}$";

            String input = verifyScode;
            if (input == null) {
                System.out.println("SA3Code Null");
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Please Enter SA3Code");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.show();
            }

            if (input.matches(scodePattern)) {
                System.out.println("Valid Data!");
                //Location validation
                String locationPattern = "\b[A-Za-z]+[ ]+[-]+[ ][A-Za-z]+$\b";
                if (verifyLocation.contains(" - ")
                        || verifyLocation.matches(locationPattern)
                        || verifyLocation.matches("(\\w+)\\s")) {

                    System.out.println("matched");
                    String sa = "";
                    Location locateObj = new Location();
                    locateObj.setSa3Code(scode);
                    locateObj.setAddress(locationName);

                    if (locateObj.getAddress().equals(sa)) {
                    } else {

                        databaseUtility.addNewLocation(scode, locationName);
                    }

                    locationsList = databaseUtility.locationLoadingMethod();

                    sa = locateObj.getAddress();

                    this.locationDisplayComboBox.getItems().clear();

                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Data Added successful");
                    alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                } else {
                    System.out.println("Not matched");
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Location should be in this format: "
                                    + "'Location - Location' "
                                    + "where ' - ' must be as delimiter"
                                    + " or a single Location word");
                    alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                }
                //location validation upto here

            } else {
                System.out.println("Wrong digits");
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "SA3code starts with '5' and can only have 5 digits");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.show();
            }
            // scode validation ends

        } catch (Exception e) {
        }

    }

    //Add tenant data
    @FXML
    private void addTenantDataMethod(ActionEvent event) throws SQLException {
        //Variable declaration
        String addressValue = "";

        //verification
        AGE ageEnum;
        String ageValue = (String) age.getValue();

        if (ageValue == "50-54") {
            ageEnum = AGE.FiftyToFifyFour;//string to enum process
        } else if (ageValue == "55-59") {
            ageEnum = AGE.FiftyToFifyNine;
        } else if (ageValue == "60-64") {
            ageEnum = AGE.SixtyToSixtyFour;
        } else {
            ageEnum = AGE.SixtyFiveOver;
        }
        System.out.println(ageValue);
        System.out.println(ageEnum);
        if (ageValue == null) {
            System.out.println("Age value is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Please select age group");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();

        }

        WEEKLY_INCOME incomeRangeEnum;
        String incomeRangeValue = (String) incomeRange.getValue();
        if (incomeRangeValue == "Negative/Nil income") {
            incomeRangeEnum = WEEKLY_INCOME.NILINCOME;
        } else if (incomeRangeValue == "$1-$399") {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$400;
        } else if (incomeRangeValue == "$400-$599") {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$600;
        } else {
            incomeRangeEnum = WEEKLY_INCOME.BELOW$1000;
        }
        System.out.println(incomeRangeValue);
        System.out.println(incomeRangeEnum);
        if (incomeRangeValue == null) {
            System.out.println("Income range is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select income range");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        String SA3ComboBoxValue = (String) SA3comboBox.getValue();
        System.out.println(SA3ComboBoxValue);
        if (SA3ComboBoxValue == null) {
            System.out.println("SA3code is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select SA3Code");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        String incomeSourceValue = (String) incomeSource.getValue();
        System.out.println(incomeSourceValue);
        if (incomeSourceValue == null) {
            System.out.println("Income Source is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select income source");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }

        int loopcount = 0; //to get the last value

        String genderValue = (String) genderComboBox.getValue();
        System.out.println(genderValue);
        GENDER genderEnum;
        if (genderValue == "Male") {
            genderEnum = GENDER.MALE;
        } else {
            genderEnum = GENDER.FEMALE;
        }

        System.out.printf("Gender enum : %s ", genderEnum);
        if (genderValue == null) {
            System.out.println("Gender is not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select gender");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        }
        //to get location details
        for (Location count : newLocationList) {
            if (count.getSa3Code().equals(SA3ComboBoxValue)) {
                addressValue = count.getAddress();
                System.out.println(addressValue);

            }

        }

            int locationId = databaseUtility.getLocationId(Integer.parseInt(SA3ComboBoxValue));
            int incomeCateogryId = databaseUtility.getWeeklyIncomeId(incomeRangeEnum.getStringValue());
            int ageGroupId = databaseUtility.getAgeId(ageEnum.getStringValue());
            int genderId = databaseUtility.getGenderId(genderEnum.toString());
            int tenantId = databaseUtility.getSA3TenantId(locationId, incomeCateogryId, ageGroupId, genderId, income_source);



            if (tenantId != 0) {
                System.out.println("tenant not 0");
                databaseUtility.incrementRiskyPersonCount(tenantId);
            } else {
                int newSA3Id = databaseUtility.addSA3TenanatCategory(locationId,
                        incomeCateogryId, ageGroupId, genderId, income_source);
                //insert new riskyperson if tenant isn't already there in sa3tenancy
                databaseUtility.addriskyPerson(newSA3Id, 1);
            }

            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Data Added successful");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();


        System.out.printf("Riskypersonarraysize: %d",
                riskyPersonsList.size());
        System.out.printf("Loopcount: %d", loopcount);

    }

    @FXML
    public void displayAction(ActionEvent event) {

        selectedOption = displayComboBox.getSelectionModel().
                getSelectedItem().toString();
        System.out.println(selectedOption);

        if (selectedOption.equals("All people in a chosen location "
                + "at the risk of homelessness")) {

            System.out.println("Second option pressed");
            enterLocLabel.setOpacity(1);
            locationDisplayComboBox.setOpacity(1);
            locationDisplayComboBox.setDisable(false);

        } else {
            enterLocLabel.setOpacity(0);
            locationDisplayComboBox.setOpacity(0);
            locationDisplayComboBox.setDisable(true);
        }
    }

    //Displaying Report
    @FXML
    public void reportBtn(ActionEvent event
    ) throws SQLException {

        List<RiskyPersons> newList = riskyPersonsList.stream().filter(item -> {
            return (item.getSA3TenantData().getIncomeSource().equals("Other")
                    && (item.getSA3TenantData().incomeRange == WEEKLY_INCOME.NILINCOME
                    || item.getSA3TenantData().incomeRange == WEEKLY_INCOME.BELOW$400));
        }).collect(Collectors.toList());

        displayBox.setText("");
        if (selectedOption == null) {
            System.out.println("Option not selected");
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Select option to display statistical reports");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.show();
        } else { //first case
            if (selectedOption.equals("All males at the risk of"
                    + " homelessness")) {
                System.out.println("first option pressed");
                incomeSourceCheck = "Other";
                GENDER male = GENDER.MALE;
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                incomeRangeCheck = "Negative/Nil income";
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");
                List<RiskyPersons> riskyMaleList = newList.stream().filter(item -> {
                    GENDER gender = item.getSA3TenantData().getGender();

                    return (gender == GENDER.MALE);
                }).collect(Collectors.toList());

                List<RiskyPersons> nilIncomeList = riskyMaleList.stream().filter(item -> {
                    return item.sa3TenantCategory.incomeRange == WEEKLY_INCOME.NILINCOME;
                }).collect(Collectors.toList());

                List<RiskyPersons> below400List = riskyMaleList.stream().filter(item -> {
                    return item.sa3TenantCategory.incomeRange == WEEKLY_INCOME.BELOW$400;
                }).collect(Collectors.toList());

                nilIncomeList.forEach(item -> {
                    displayBox.appendText(item.toString());
                });

                below400List.forEach(item -> {
                    displayBox.appendText(item.toString());
                });
            } //second case
            else if (selectedOption.equals("All people in a chosen "
                    + "location at the risk of homelessness")) {

                System.out.println("Second option pressed");
                String locationToDisplay = (String) locationDisplayComboBox
                        .getValue();
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                System.out.println(locationToDisplay);
                if (locationToDisplay == null) {
                    System.out.println("Location is not selected");
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            "Please select a location.");
                    alert.getDialogPane().
                            setMinHeight(Region.USE_PREF_SIZE);
                    alert.show();
                } else {
                    displayBox.setStyle("-fx-font-family: monospace");
                    displayBox.setText("SA3code \tName \t\t\t\t"
                            + "Income Category  Income Source\t\t "
                            + "Age Group \t Gender    Number of People \n ");
                    for (RiskyPersons count : riskyPersonsList) {
                        if (count.getSA3TenantData().getlocation().getSa3Code().
                                equals(locationToDisplay)
                                && count.getSA3TenantData().getIncomeSource().
                                equals("Other") && (count.
                                getNumberOfPerson() >= 1)
                                && (count.getSA3TenantData().getIncomeRange().
                                equals(nilIncome)
                                || count.getSA3TenantData().getIncomeRange().
                                equals(below$400))) {
                            {

                                displayBox.appendText(count.toString());

                            }
                        }
                    }
                }

            }//third option
            else if (selectedOption.equals("All females at "
                    + "the risk of homelessness")) {
                System.out.println("Third option pressed");
                incomeSourceCheck = "Other";
                GENDER female = GENDER.FEMALE;
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");
                List<RiskyPersons> riskyFemaleList = newList.stream().filter(item -> {
                    GENDER gender = item.getSA3TenantData().getGender();

                    return (gender == GENDER.FEMALE);
                }).collect(Collectors.toList());

                List<RiskyPersons> updatedList = new LinkedList<>();

                List<RiskyPersons> fiftyToFiftyFour = riskyFemaleList.stream().filter(item -> {
                    return item.getSA3TenantData().getAge() == AGE.FiftyToFifyFour;
                }).collect(Collectors.toList());

                List<RiskyPersons> fiftyFiveToFiftyNine = riskyFemaleList.stream().filter(item -> {
                    return item.getSA3TenantData().getAge() == AGE.FiftyToFifyNine;
                }).collect(Collectors.toList());

                List<RiskyPersons> sixtyToSixtyFour = riskyFemaleList.stream().filter(item -> {
                    return item.getSA3TenantData().getAge() == AGE.SixtyToSixtyFour;
                }).collect(Collectors.toList());

                List<RiskyPersons> sixtyFiveOverr = riskyFemaleList.stream().filter(item -> {
                    return item.getSA3TenantData().getAge() == AGE.SixtyFiveOver;
                }).collect(Collectors.toList());
                updatedList.addAll(fiftyToFiftyFour);
                updatedList.addAll(fiftyFiveToFiftyNine);
                updatedList.addAll(sixtyToSixtyFour);
                updatedList.addAll(sixtyFiveOverr);

                updatedList.forEach(item -> {
                    displayBox.appendText(item.toString());
                });


            } //fourth option
            else if (selectedOption.equals("All at the risk of "
                    + "homelessness")) {
                System.out.println("Fourth option pressed");
                incomeSourceCheck = "Other";
                WEEKLY_INCOME nilIncome = WEEKLY_INCOME.NILINCOME;
                WEEKLY_INCOME below$400 = WEEKLY_INCOME.BELOW$400;
                displayBox.setStyle("-fx-font-family: monospace");
                displayBox.setText("SA3code \tName \t\t\t\t"
                        + "Income Category  Income Source\t\t "
                        + "Age Group \t Gender    Number of People \n ");
                for (RiskyPersons count : riskyPersonsList) {
                    if (count.getSA3TenantData().getIncomeSource().
                            equals("Other") && (count.getNumberOfPerson() >= 1)
                            && (count.getSA3TenantData().getIncomeRange().
                            equals(nilIncome)
                            || count.getSA3TenantData().getIncomeRange().
                            equals(below$400))) {
                        System.out.println(count.toString());
                        displayBox.appendText(count.toString());
                    }
                }
            }
        }
    }
    //to clear selected options when moving to next tab forward
    RiskyPersons c = new RiskyPersons();

    public void clearFields() {
        //to clear the value in tenant tab
        SA3comboBox.getSelectionModel().clearSelection();
        incomeRange.getSelectionModel().clearSelection();
        age.getSelectionModel().clearSelection();
        displayComboBox.getSelectionModel().clearSelection();
        locationDisplayComboBox.getSelectionModel().clearSelection();
        incomeSource.getSelectionModel().clearSelection();

    }

    public void clearLocationTab() {
        //to clear the value in location tab
        location.setText(null);
        SA3Code.setText(null);
    }

}

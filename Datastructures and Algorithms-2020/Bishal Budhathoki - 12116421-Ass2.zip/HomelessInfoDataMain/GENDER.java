package HomelessInfoDataMain;

/**
 *
 * @author Bishal Budhathoki - 12116421
 * @author Laxman Khanal - 12123129
 * COIT20256: Data Structures and Algorithms
 * Term 1, 2020 Assignment 2
 *
 */
public enum GENDER {
    MALE("Male"), FEMALE("Female"); //enum intialilze

    private String genVal;
//set gender

    private GENDER(String value) {
        this.genVal = value;
    }
//get gender

    public static GENDER getGender(String gender) {
        switch (gender) {
            default:
            case "Male":
                return GENDER.MALE;
            case "Female":
                return GENDER.FEMALE;
        }
    }

}

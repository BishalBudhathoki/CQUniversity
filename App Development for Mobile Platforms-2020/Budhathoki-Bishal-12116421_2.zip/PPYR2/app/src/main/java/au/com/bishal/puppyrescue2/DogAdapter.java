package au.com.bishal.puppyrescue2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DogAdapter extends RecyclerView.Adapter<DogAdapter.DogViewHolder> {
    private List<Dog> dogList;
    private DogAdapterInteraction dogAdapterInteraction;

    //constructor for passing the dog list to the DogAdapter
    public DogAdapter(List<Dog> dogList, DogAdapterInteraction dogAdapterInteraction) {
        this.dogList = dogList;
        this.dogAdapterInteraction = dogAdapterInteraction;
    } //end constructor

    // Dog View Holder for widgets of dog_list_layout layout
    public class DogViewHolder extends RecyclerView.ViewHolder {
        TextView mDogTitle, mDogAge;
        public DogViewHolder(@NonNull View itemView) {
            super(itemView);
            mDogTitle = itemView.findViewById(R.id.tv_dog);
            mDogAge = itemView.findViewById(R.id.tv_dog_age);
        }
    } //end DogViewHolder

    @NonNull
    @Override
    public DogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate the custom layout dog_list_layout in the view holder
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dog_list_layout, parent,
                false); //opens list
        return new DogViewHolder(view);
    } //end onCreateViewHolder

    @Override
    public void onBindViewHolder(@NonNull DogViewHolder holder, int position) {
        //get the dog info
        final Dog dog = dogList.get(position);
        //bind the data to the view
        holder.mDogTitle.setText(holder.mDogTitle.getContext().getString(R.string.dog_name_breed,
                dog.getDogName(), dog.getDogBreed()));
        holder.mDogAge.setText(holder.mDogAge.getContext().getString(R.string.dog_age_gender,
                dog.getDogAge(), dog.getDogGender()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dogAdapterInteraction.onDogClicked(dog);
            }
        });
    }

    @Override
    public int getItemCount() {
        //size of the list to be shown in the adapter, equivalent to the dogList size.
        return dogList.size();
    }

}//end DogAdapter


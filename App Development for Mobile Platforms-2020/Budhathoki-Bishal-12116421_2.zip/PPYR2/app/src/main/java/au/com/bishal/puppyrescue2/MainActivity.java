package au.com.bishal.puppyrescue2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import au.com.bishal.puppyrescue2.database.RescueCenter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DogAdapterInteraction {
    //objects used
    private DogAdapter dogAdapter;
    private RescueCenter rescueCenter;
    //array list used
    List<Dog> dogsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //database to open when MainActivity is executed
        rescueCenter = RescueCenter.get(MainActivity.this);
        RecyclerView recyclerView = findViewById(R.id.dog_recyclerview);
        //add dog to list from database
        dogsList.addAll(rescueCenter.getDogs());
        Dog dog=new Dog(); //dog object
        rescueCenter.getDog(dog.getDogId()); //get dog data using their DogId
        //send the dog data to the list
        dogAdapter = new DogAdapter(dogsList, this);
        //recyclerview vertical scroll when list is longer than screen size
        recyclerView.setLayoutManager(new LinearLayoutManager(
                this, RecyclerView.VERTICAL, false));
        recyclerView.setAdapter(dogAdapter);
    } //end onCreate

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 12 || requestCode == 24) {
            dogsList.clear(); //clear dog list
            dogsList.addAll(rescueCenter.getDogs()); //add data to dog list from database
            dogAdapter.notifyDataSetChanged();//notify dog adapter
        }
    } //end onActivityResult

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu); //open list when + icon is selected
        return true;
    } //onCreateOptionsMenu

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_add) {
            //open add dog activity, to add new dog in list/database
            Intent intent = new Intent(this, AddDogInList.class);
            startActivityForResult(intent, 24);
        }
        return super.onOptionsItemSelected(item);
    }

    //when dog is selected from the list
    @Override
    public void onDogClicked(Dog dog) {
        Intent detailIntent = new Intent(this, DogDetailPage.class);
        detailIntent.putExtra("dogDetails", dog);
        startActivityForResult(detailIntent, 12);
    }
}






package au.com.bishal.puppyrescue2;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class GoogleMapUseActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerDragListener {
    // Variable used
    public UUID id;
    private String name;
    public Double lat=0.0;
    public Double lon=0.0;
    private static final String ARG_DOG_INFO = "dogDetails";
    // making map marker draggable
    MarkerOptions markerOptions = new MarkerOptions().draggable(true);
    Dog dog = new Dog();
    private GoogleMap googleMap;
    private static final String TAG = "GoogleMapUseActivity";
    private Geocoder geocoder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.google_map_layout);
        //catching values send by DogDetailPage activity
        Bundle extras = getIntent().getExtras();
        if(extras == null) { ///if bundle has got no values from another activity
            lat= 0.0;
            lon=0.0;
        } else {
            lat=extras.getDouble("latitude");
            lon=extras.getDouble("longitude");
            dog = (Dog) getIntent().getSerializableExtra(ARG_DOG_INFO);
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.googleMap); //opens map using fragment
        mapFragment.getMapAsync(this);
        geocoder = new Geocoder(this);
    }

    //when map is opened and ready
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap; //load google map
        this.googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); // display normal type of google map
        this.googleMap.setOnMarkerDragListener(this);//drag listener to drag and drop the marker as per user
        name = dog.getDogName(); //to set marker title with dog name
        List<Address> addresses = null;
        try {
            //to open map in required latitude and longitude
            addresses = geocoder.getFromLocation(lat, lon, 1);
            //List<Address> addresses = geocoder.getFromLocationName("Sydney", 1);
        } catch (IOException e) { //exceptional handling
            e.printStackTrace();
        }
        if (addresses.size() > 0) { //if list is not empty
            Address address = addresses.get(0);
            LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
            //set marker with title and LatLng value and making it draggable to set the users location
            markerOptions.position(latLng).title(name).draggable(true);
            this.googleMap.addMarker(markerOptions); //add marker
            //set zoom value to 14 and making it movable
            this.googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14));
        }
    }

    //not used in this assignment
    @Override
    public void onMarkerDragStart(Marker marker) {
        Log.d(TAG, "onMarkerDragStart: ");
    }
    //not used in this assignment
    @Override
    public void onMarkerDrag(Marker marker) {
        Log.d(TAG, "onMarkerDrag: ");
    }
    // for drag pointer end
    @Override
    public void onMarkerDragEnd(Marker marker) {
        Log.d(TAG, "onMarkerDragEnd: ");
        LatLng latLng = marker.getPosition(); //get position of the marker
        List<Address> addresses;
        try {
            addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);

            if (addresses.size() > 0) {
                Address address = addresses.get(0);
                String streetAddress = address.getAddressLine(0);
                marker.setTitle(name); //marker title name with dog name
                lat = latLng.latitude;
                lon = latLng.longitude;
                //after drag and drop is done return to DogDetailPage
                Intent intent = new Intent(this, DogDetailPage.class);
                intent.putExtra("dragLatitude", latLng.latitude);
                intent.putExtra("dragLongitude", latLng.longitude);
                intent.putExtra("dogDetails", dog);
                startActivity(intent);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
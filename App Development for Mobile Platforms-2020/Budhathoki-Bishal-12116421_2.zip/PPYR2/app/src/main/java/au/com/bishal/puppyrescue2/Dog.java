package au.com.bishal.puppyrescue2;

import java.io.Serializable;
import java.util.UUID;

public class Dog implements Serializable {
    private UUID mDogId;
    private String mDogName;
    private String mDogBreed;
    private String mDogGender;
    private int mDogAge;

    private Double mLatitude;
    private Double mLongitude;

    public String getDogGender()
    {
        return mDogGender;
    }

    public void setDogGender(String mDogGender)
    {
        this.mDogGender = mDogGender;
    }

    public String getDogName()
    {
        return mDogName;
    }

    public void setDogName(String mDogName)
    {
        this.mDogName = mDogName;
    }

    public String getDogBreed()
    {
        return mDogBreed;
    }

    public void setDogBreed(String mDogBreed)
    {
        this.mDogBreed = mDogBreed;
    }

    public int getDogAge()
    {
        return mDogAge;
    }

    public void setDogAge(int mDogAge)
    {
        this.mDogAge = mDogAge;
    }

    public UUID getDogId()
    {
        return mDogId;
    }

    public Double getLatitude()
    {
        return mLatitude;
    }

    public void setLatitude(double mLatitude)
    {
        this.mLatitude = mLatitude;
    }

    public Double getLongitude()
    {
        return mLongitude;
    }

    public void setLongitude(double mLongitude)
    {
        this.mLongitude = mLongitude;
    }

    public Dog()
    {
        this(UUID.randomUUID());
    }

    public Dog(UUID mDogId)
    {
        this.mDogId = mDogId;
        this.mDogAge = 0;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "mDogId=" + mDogId +
                ", mDogName='" + mDogName + '\'' +
                ", mDogBreed='" + mDogBreed + '\'' +
                ", mDogGender='" + mDogGender + '\'' +
                ", mDogAge=" + mDogAge +
                ", mLatitude=" + mLatitude +
                ", mLongitude=" + mLongitude +
                '}';
    }
}

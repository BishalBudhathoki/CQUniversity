package au.com.bishal.puppyrescue2.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DbHelper extends SQLiteOpenHelper
{
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "DogDynasty.db";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DbSchema.DogTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                DbSchema.DogTable.Cols.UUID + ", " +
                DbSchema.DogTable.Cols.NAME + ", " +
                DbSchema.DogTable.Cols.BREED + ", " +
                DbSchema.DogTable.Cols.GENDER + ", "  +
                DbSchema.DogTable.Cols.AGE + ", "  +
                DbSchema.DogTable.Cols.LAT + ", "  +
                DbSchema.DogTable.Cols.LON +
                ")"
        );    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

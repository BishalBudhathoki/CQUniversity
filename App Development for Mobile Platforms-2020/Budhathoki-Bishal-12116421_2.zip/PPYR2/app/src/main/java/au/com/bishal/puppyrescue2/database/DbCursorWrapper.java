package au.com.bishal.puppyrescue2.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import au.com.bishal.puppyrescue2.Dog;
import au.com.bishal.puppyrescue2.database.DbSchema.DogTable;

import java.util.UUID;

public class DbCursorWrapper extends CursorWrapper
{
    public DbCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public Dog getDog()
    {
        String uuidString = getString(getColumnIndex(DogTable.Cols.UUID));
        String Name = getString(getColumnIndex(DogTable.Cols.NAME));
        String Breed = getString(getColumnIndex(DogTable.Cols.BREED));
        String Gender = getString(getColumnIndex(DogTable.Cols.GENDER));
        int Age = getInt(getColumnIndex(DogTable.Cols.AGE));
        long Lat = getInt(getColumnIndex(DogTable.Cols.LAT));
        long Lon = getInt(getColumnIndex(DogTable.Cols.LON));

        Dog dog = new Dog(UUID.fromString(uuidString));
        dog.setDogName(Name);
        dog.setDogBreed(Breed);
        dog.setDogGender(Gender);
        dog.setDogAge(Age);
        dog.setLatitude(Lat);
        dog.setLongitude(Lon);

        return dog;
    }
}

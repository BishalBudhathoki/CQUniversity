package au.com.bishal.puppyrescue2.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import au.com.bishal.puppyrescue2.Dog;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static au.com.bishal.puppyrescue2.database.DbSchema.DogTable.*;
import static au.com.bishal.puppyrescue2.database.DbSchema.DogTable.NAME;

public class RescueCenter
{
    private static RescueCenter sRescueCenter;

    private Context mContext;
    private SQLiteDatabase mDatabase;
    
    public static RescueCenter get(Context context)
    {
        if (sRescueCenter == null)
        {
            sRescueCenter = new RescueCenter(context);
        }
        return sRescueCenter;
    }
    
    private RescueCenter(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new DbHelper(mContext)
                .getWritableDatabase();
    }

    private static ContentValues getContentValues(Dog dog) {
        ContentValues values = new ContentValues();
        values.put(Cols.UUID, dog.getDogId().toString());
        values.put(Cols.NAME, dog.getDogName());
        values.put(Cols.BREED, dog.getDogBreed());
        values.put(Cols.GENDER, dog.getDogGender());
        values.put(Cols.AGE, dog.getDogAge());
        values.put(Cols.LAT, dog.getLatitude());
        values.put(Cols.LON, dog.getLongitude());

        return values;
    }

    private DbCursorWrapper queryDogs(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                NAME,
                null, // columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );

        return new DbCursorWrapper(cursor);
    }

    public void addDog(Dog c) {
        ContentValues values = getContentValues(c);

        mDatabase.insert(NAME, null, values);
    }

    public void updateDog(Dog dog) {
        String uuidString = dog.getDogId().toString();
        ContentValues values = getContentValues(dog);

        mDatabase.update(NAME, values,
                Cols.UUID + " = ?",
                new String[] { uuidString });
    }

    public void deleteDog(UUID uuid)
    {
        mDatabase.delete(NAME, Cols.UUID + " = ?",
                new String[] { uuid.toString() });
    }

    public List<Dog> getDogs() {
        List<Dog> dogs = new ArrayList<>();

        DbCursorWrapper cursor = queryDogs(null, null);

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                dogs.add(cursor.getDog());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return dogs;
    }

    public Dog getDog(UUID id) {
        DbCursorWrapper cursor = queryDogs(
                Cols.UUID + " = ?",
                new String[] { id.toString() }
        );

        try
        {
            if (cursor.getCount() == 0) {
                return null;
            }

            cursor.moveToFirst();
            return cursor.getDog();
        }
        finally
        {
            cursor.close();
        }
    }
}

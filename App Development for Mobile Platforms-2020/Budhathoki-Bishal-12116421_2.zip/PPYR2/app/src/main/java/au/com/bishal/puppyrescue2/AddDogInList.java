package au.com.bishal.puppyrescue2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import au.com.bishal.puppyrescue2.database.RescueCenter;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.concurrent.TimeUnit;

//this class is used to  add the dog details ont the list that is the first page of this app
public class AddDogInList extends AppCompatActivity {
    //variables declared/initialise to use
    private EditText mDogName, mDogBreed, mDogGender, mDogAge;
    private Button mBtnSave;
    private RescueCenter mRescueCenter;
    private Double mLat = -33.8696, mLon = 151.20695;
    String name, breed, gender, age;
    //objects declared
    Location currentLocation;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest = new LocationRequest();

    //this method runs when/after activity is created
    @Override
    protected void onStart() {
        super.onStart();
        //start the location update
        checkLocationGPS();
    }

    //when AddDogActivity is called onCreate creates the activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_dog_layout); //opens layout
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        //database  to store dog data entered by the user
        mRescueCenter = RescueCenter.get(AddDogInList.this);
        //connecting variable with the layout to take user input
        mDogName = findViewById(R.id.dog_name_input);
        mDogBreed = findViewById(R.id.dog_breed_input);
        mDogGender = findViewById(R.id.dog_gender_input);
        mDogAge = findViewById(R.id.dog_age_input);
        mBtnSave = findViewById(R.id.save_dog_button);
        //button to save data in the list and database
        mBtnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDogData();
            }
        });
        //method to obtain location
        setCurrentAddress();
    } //end onCreate

    // used to get current location
    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            if (locationResult == null) {
                return;
            }
            for (Location location : locationResult.getLocations()) {
                if (location != null) {
                    Toast.makeText(AddDogInList.this, String.valueOf(mLat),
                            Toast.LENGTH_SHORT).show();
                    //latitude and longitude value is initialised
                    mLat = location.getLatitude();
                    mLon = location.getLongitude();
                }
            }
        }
    }; // end LocationCallBack

    //permission verification
    private void startLocationUpdate() {
        //check if permission not granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //check if permission granted
            //fused location client provide last known location details
            fusedLocationClient.requestLocationUpdates(locationRequest, mLocationCallback, null);
        }
    } //end startLocationUpdate

    //check permission, if not requested, request permission if not granted toast a message
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            //check permission
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(this,
                                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    //request permission
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            1);
                }
                fusedLocationClient.requestLocationUpdates(locationRequest, mLocationCallback, null);
            } else { //if permission not granted
                Toast.makeText(this, "Permission not Granted!", Toast.LENGTH_SHORT).show();
            }
        }
    } // end onRequestPermissionsResult

    //set location method to set Interval, wait time and priority
    private void setCurrentAddress() {
        locationRequest.setInterval(TimeUnit.SECONDS.toMillis(10));
        locationRequest.setFastestInterval(TimeUnit.SECONDS.toMillis(5));
        locationRequest.setMaxWaitTime(TimeUnit.MINUTES.toMillis(2));
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    } //end setCurrentAddress

    //check location from GPS and update
    private void checkLocationGPS() {
        LocationSettingsRequest.Builder builder = new
                LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        builder.setAlwaysShow(true);
        Task<LocationSettingsResponse> locationSettingsResponseTask =
                LocationServices.getSettingsClient(this).checkLocationSettings(builder.build());
        locationSettingsResponseTask.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(@NonNull Task<LocationSettingsResponse> task) {
                try {
                    task.getResult(ApiException.class);
                    startLocationUpdate();
                } catch (ApiException e) { //exception handling
                    if (e.getStatusCode() == LocationSettingsStatusCodes.RESOLUTION_REQUIRED) {
                        try {
                            ((ResolvableApiException) e).startResolutionForResult(
                                    AddDogInList.this, 345);

                        } catch (IntentSender.SendIntentException ex) { //exception handling
                            ex.printStackTrace();
                        }
                    }
                }
            } //end onComplete
        }); // end addOnCompleteListener
    } //end checkLocationGPS

    // onActivityResult method
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 345) { //retrieve the same pending intent instance later
            if (resultCode == Activity.RESULT_OK) {
                //GPS Permission is granted
                startLocationUpdate();
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Toast.makeText(this, "GPS is not enabled!", Toast.LENGTH_SHORT).show();
            }
        }
    } //end onActivityResult

    //when save button is pressed this method is called
    private void saveDogData() {
        //check permission before accessing location
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Task<Location> task = fusedLocationClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            //get current location
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    mLat =  currentLocation.getLatitude();
                    mLon =  currentLocation.getLongitude();
                    Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + ""
                            + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    //use of fragment to open the google map
                    SupportMapFragment supportMapFragment = (SupportMapFragment)
                            getSupportFragmentManager().findFragmentById(R.id.googleMap);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync((OnMapReadyCallback) AddDogInList.this);
                }
            }
        });
        //variables initialised
        name = mDogName.getText().toString().trim();
        breed = mDogBreed.getText().toString().trim();
        gender = mDogGender.getText().toString().trim();
        age = mDogAge.getText().toString().trim();
        //fields empty validation
        if (name.isEmpty() && breed.isEmpty() && gender.isEmpty() && age.isEmpty()) {
            Toast.makeText(AddDogInList.this, R.string.fields_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isDigitsOnly(age)) {
            Dog dog = new Dog();
            dog.setDogName(name);
            dog.setDogBreed(breed);
            dog.setDogGender(gender);
            dog.setDogAge(Integer.parseInt(age));
            dog.setLatitude(mLat);
            dog.setLongitude(mLon);
            mRescueCenter.addDog(dog); //add dog in database
            Toast.makeText(AddDogInList.this, R.string.dog_add, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AddDogInList.this, R.string.age_empty, Toast.LENGTH_SHORT).show();
        }
    } //end save dog data
}
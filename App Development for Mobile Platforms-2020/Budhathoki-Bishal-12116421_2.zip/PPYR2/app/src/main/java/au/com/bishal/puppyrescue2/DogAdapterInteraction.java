package au.com.bishal.puppyrescue2;

interface DogAdapterInteraction {
    void onDogClicked(Dog dog); //when dog is selected on the list
}

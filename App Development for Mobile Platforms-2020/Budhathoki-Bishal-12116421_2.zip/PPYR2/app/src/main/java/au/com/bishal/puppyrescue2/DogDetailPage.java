package au.com.bishal.puppyrescue2;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import au.com.bishal.puppyrescue2.database.RescueCenter;


public class DogDetailPage extends AppCompatActivity implements View.OnClickListener {
    //variable declaration
    private static final String ARG_DOG_INFO = "dogDetails";
    public Double lati, longi, dragLatitude, dragLongitude;
    private EditText dogName, dogBreed, dogGender, dogAge;
    private Dog dog; //object Dog
    private RescueCenter rescueCenter; //object for database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dog_detail_page_layout);

        //ready database when DOg detail page is opened for dog detail
        rescueCenter = RescueCenter.get(this);
        //initialising buttons/widgets
        Button btnDeleteDog = findViewById(R.id.btn_delete);
        Button btnEmail = findViewById(R.id.btn_email);
        Button btnSetLocation = findViewById(R.id.btn_set_location);
        Button btnMap = findViewById(R.id.btn_map);
        if (getIntent().getExtras() != null) {
            dog = (Dog) getIntent().getSerializableExtra(ARG_DOG_INFO);
        }
        //initialise variable with user input
        dogName = findViewById(R.id.dog_name_input);
        dogBreed = findViewById(R.id.dog_breed_input);
        dogGender = findViewById(R.id.dog_gender_input);
        dogAge = findViewById(R.id.dog_age_input);

        //individual button listeners
        btnDeleteDog.setOnClickListener(this);
        btnEmail.setOnClickListener(this);
        btnSetLocation.setOnClickListener(this);
        btnMap.setOnClickListener(this);

        //set the dog data in textfield when the activity is created
        fillTextFieldDogData();
        //accept data from GoogleMapUseActivity
        Bundle extras = getIntent().getExtras();
        if(extras == null) { //if no values passed
            lati= null;
            longi=null;
        } else {
            lati=extras.getDouble("latitude");
            longi=extras.getDouble("longitude");
            //when dragEnd is done
            dragLatitude =extras.getDouble("dragLatitude");
            dragLongitude =extras.getDouble("dragLongitude");
        }
    } //end onCreate

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_delete:
                deleteDog();
                break;
            case R.id.btn_email:
                sendEmail();
                break;
            case R.id.btn_set_location:
                setLocationOfDog();

                break;
            case R.id.btn_map:
                initiateMap();

                break;
        }
    }
    RescueCenter mRescueCenter;
    //send email with a format
    private void sendEmail() {
        //obtaining the required data from the text field
        String name = dogName.getText().toString().trim();
        String breed = dogBreed.getText().toString().trim();
        String gender = dogGender.getText().toString().trim();
        String age = dogAge.getText().toString().trim();

        //validation to see if any text  field is empty or not
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.name_not_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        if (breed.isEmpty()) {
            Toast.makeText(this, R.string.breed_not_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        //if not empty, email send
        Intent emailSend = new Intent(Intent.ACTION_SEND);
        emailSend.setType("text/plain");
        emailSend.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
        emailSend.putExtra(Intent.EXTRA_TEXT, getString(R.string.email_text, name,
                Integer.parseInt(age), gender, breed));
        emailSend.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(emailSend, "Send email using?"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No Chooser Found!", Toast.LENGTH_SHORT).show();
        }
    }// end sendEmail

    private void setLocationOfDog() {
        GoogleMapUseActivity googleMapUseActivity = new GoogleMapUseActivity();
        //send data to another activity and also open another activity
        Intent intent = new Intent(this, GoogleMapUseActivity.class);
        intent.putExtra("longitude", dog.getLongitude());
        intent.putExtra("latitude", dog.getLatitude());
        intent.putExtra("dogDetails", dog);
        //to obtain dog id to display specific data of dog
        Bundle bundle = new Bundle();
        bundle.putSerializable("id",dog.getDogId());
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void initiateMap() {
        Toast.makeText(this, String.valueOf(dog.getLatitude()), Toast.LENGTH_SHORT).show();
        if (dog.getLatitude() == 0.0 && dog.getLongitude() == 0.0) {
            Toast.makeText(this, R.string.set_location, Toast.LENGTH_SHORT).show();
        } else {
            //GoogleMapUseActivity googleMapUseActivity = new GoogleMapUseActivity();
            Intent intent = new Intent(this, GoogleMapUseActivity.class);
            intent.putExtra("dogDetails", dog);
            intent.putExtra("longitude", dragLongitude);
            intent.putExtra("latitude", dragLatitude);
            startActivity(intent);
        }
    } //end initiateMap

    //delete dog from the list
    private void deleteDog() {
        rescueCenter.deleteDog(dog.getDogId());
        Toast.makeText(this, "Dog Data List Deleted Successfully", Toast.LENGTH_SHORT).show();
        finishDogActivity();
    } //end deleteDog

    //fill text field with dog details data
    private void fillTextFieldDogData() {
        dogName.setText(dog.getDogName());
        dogBreed.setText(dog.getDogBreed());
        dogGender.setText(dog.getDogGender());
        dogAge.setText(String.valueOf(dog.getDogAge()));
    }

    //finish the current dog detail activity
    private void finishDogActivity() {
        Intent resultIntent = new Intent();
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }


}

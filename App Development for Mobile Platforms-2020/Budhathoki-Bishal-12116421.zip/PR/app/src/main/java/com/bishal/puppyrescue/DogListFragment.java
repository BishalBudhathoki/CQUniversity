package com.bishal.puppyrescue;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogListFragment extends Fragment {

    private RecyclerView mDogRecyclerView;
    private DogAdapter mDogAdapter;

public View onCreateView(LayoutInflater inflater, ViewGroup container,
                         Bundle savedInstanceState) {

    View view = inflater.inflate(R.layout.fragment_dog_list, container, false);
    mDogRecyclerView = (RecyclerView) view
            .findViewById(R.id.dog_recycler_view);
    mDogRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    updateListUI();
    return view;
}
    @Override
    public void onResume() {
        super.onResume();
        updateListUI();
    }

    private void updateListUI() {
        DogDB dogDB = DogDB.get(getActivity());
        List<Dog> dogs = dogDB.getDogs();

        if (mDogAdapter == null) {
            mDogAdapter = new DogAdapter(dogs);
            mDogRecyclerView.setAdapter(mDogAdapter);
        } else{
                mDogAdapter.notifyDataSetChanged();
            }
    }

    private class DogHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mName_BreedView;
        private TextView mAge_GenderView;
        private Dog mDog;

        public DogHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_dog, parent, false));
            itemView.setOnClickListener(this);

            //to display in the list
            mName_BreedView = (TextView) itemView.findViewById(R.id.name_breed_detail);
            mName_BreedView.setTextColor(Color.parseColor("Black"));
            mAge_GenderView =(TextView) itemView.findViewById(R.id.age_gender_detail);
            mAge_GenderView.setTextColor(Color.parseColor("Grey"));
        }
        @Override
        public void onClick(View view) {
            Intent intent = DogPagerActivity.newIntent(getActivity(), mDog.getDogID());
            startActivity(intent);
        }

        //set list display format
        public void bind(Dog dog) {
            mDog = dog;
            mName_BreedView.setText(String.format("%s is a %s", mDog.getDogName(), mDog.getDogBreed()));
            mAge_GenderView.setText(String.format("%d year old %s", mDog.getDogAge(), mDog.getDogGender()));
        }
    }

    private class DogAdapter extends RecyclerView.Adapter<DogHolder> {

        private List<Dog> mDogs;
        public DogAdapter(List<Dog> dogs) {
            mDogs = dogs;
        }

        @Override
        public DogHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new DogHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(DogHolder holder, int position) { //dogs position on the list
            Dog dog = mDogs.get(position);
            holder.bind(dog);
        }

        @Override
        public int getItemCount() { //return dogs list size
            return mDogs.size();
        }
    }
}


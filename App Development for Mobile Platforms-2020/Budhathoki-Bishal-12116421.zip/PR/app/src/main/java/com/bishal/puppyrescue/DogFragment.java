package com.bishal.puppyrescue;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.UUID;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogFragment extends Fragment {

    private static final String ARG_DOG_ID = "dogId";

    private Dog mDog;
    private EditText mDogName;
    private EditText mDogBreed;
    private EditText mDogGender;
    private EditText mDogAge;
    private Button mNewDogBtn;
    private Button mSaveBtn;
    String addNameValue;
    String addBreedValue;
    String addGenderValue;
    int addAgeValue;
    String addAgeValues;

    public static DogFragment newInstance(UUID dogId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_DOG_ID, dogId);
        DogFragment fragment = new DogFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assert getArguments() != null; //if getSerializable gets null pointer
        UUID dogId = (UUID) getArguments().getSerializable(ARG_DOG_ID);
        mDog = DogDB.get(getActivity()).getDog(dogId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_dog, container, false);

        mDogName = (EditText) v.findViewById(R.id.name_field);
        mDogName.setText(mDog.getDogName());

        mDogBreed = v.findViewById(R.id.breed_field);
        mDogBreed.setText(mDog.getDogBreed());

        mDogGender = v.findViewById(R.id.gender_field);
        mDogGender.setText(mDog.getDogGender());

        mDogAge = v.findViewById(R.id.age_field);
        mDogAge.setText(String.valueOf(mDog.getDogAge()));

        mNewDogBtn = v.findViewById(R.id.new_dog_btn);
        mSaveBtn = v.findViewById(R.id.save_btn);
        mSaveBtn.setVisibility(View.GONE);

        //when New Dog button is selected, clear all text input detail and save button appears
        mNewDogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDogName.setText("");
                mDogBreed.setText("");
                mDogGender.setText("");
                mDogAge.setText("");
                mNewDogBtn.setVisibility(View.GONE);
                mSaveBtn.setVisibility(View.VISIBLE);
                Toast.makeText(getContext(), "New Dog Button Selected", Toast.LENGTH_SHORT).show();
            }
        });

        //validation and exceptional handling along with checking of input data entered
        mSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Save Button Selected", Toast.LENGTH_SHORT).show();
                try {
                    addNameValue = mDogName.getText().toString();
                    addBreedValue = mDogBreed.getText().toString();
                    addGenderValue = mDogGender.getText().toString();
                    addAgeValues = mDogAge.getText().toString();
                    addAgeValue = Integer.parseInt(addAgeValues);
                    if (addNameValue.isEmpty()) {
                        Toast.makeText(getActivity(), "Dog name is empty", Toast.LENGTH_SHORT).show();
                    }

                    if (addBreedValue.isEmpty()) {
                        Toast.makeText(getActivity(), "Dog Breed is empty", Toast.LENGTH_SHORT).show();
                    }

                    if (addAgeValues.isEmpty()) {
                        Toast.makeText(getActivity(), "Dog age is empty", Toast.LENGTH_SHORT).show();
                    }

                    if (addGenderValue.isEmpty()) {
                        Toast.makeText(getActivity(), "Dog gender is empty", Toast.LENGTH_SHORT).show();

                    } else if (!addGenderValue.equalsIgnoreCase("Male") || !addGenderValue.equalsIgnoreCase("female")) {
                        Toast.makeText(getActivity(), "Dog gender is not correct", Toast.LENGTH_SHORT).show();
                    }


                } catch (NumberFormatException e) {  //exceptional handling for age input
                    Toast.makeText(getActivity(), "Dog age is empty", Toast.LENGTH_SHORT).show();
                }

                DogDB dogDB = DogDB.get(getActivity());
                dogDB.newDog(addNameValue, addBreedValue, addGenderValue, addAgeValue);
                //after new dog data is added to the list, display list
                callingFunction(); //to open updated list of dog
            }

            public void callingFunction() {
                Intent intent = new Intent(getActivity(), DogListActivity.class);
                startActivity(intent);
            }

        });
        return v;
    }
}
package com.bishal.puppyrescue;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import java.util.UUID;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogActivity extends SingleFragmentActivity {

    private static final String EXTRA_DOG_ID =
            "com.bishal.puppyrescue.dogId";

    //overriding fragment to create a fragment method
    @Override
    protected Fragment createFragment() {

        UUID dogId = (UUID) getIntent()
                .getSerializableExtra(EXTRA_DOG_ID);
        return DogFragment.newInstance(dogId);

    }
}

package com.bishal.puppyrescue;

import androidx.fragment.app.FragmentActivity;

import java.util.UUID;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class Dog {

    //initialisation of variables
    private UUID mDogID;
    private String mDogName;
    private String mDogBreed;
    private String mDogGender;
    private int mDogAge;

    //setter and getter method required
    public UUID getDogID() {
        return mDogID;
    }

    public String getDogName() {
        return mDogName;
    }

    public void setDogName(String dogName) {
        this.mDogName = dogName;
    }

    public String getDogBreed() {
        return mDogBreed;
    }

    public void setDogBreed(String dogBreed) {
        this.mDogBreed = dogBreed;
    }

    public String getDogGender() {
        return mDogGender;
    }

    public void setDogGender(String dogGender) {
        this.mDogGender = dogGender;
    }

    public int getDogAge() {
        return mDogAge;
    }

    public void setDogAge(int dogAge) {
        this.mDogAge = dogAge;
    }

    //Generates UUID every time the Dog() method is called so that every dog is unique in the list
    public Dog(){
        mDogID = UUID.randomUUID();
    }

}
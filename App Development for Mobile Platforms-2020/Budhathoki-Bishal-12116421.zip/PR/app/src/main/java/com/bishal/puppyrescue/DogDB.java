package com.bishal.puppyrescue;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogDB {

    private static DogDB sDogDB;
    private List<Dog> mDogList = new ArrayList<>();


    public static DogDB get(Context context) {
        if (sDogDB == null) {
            sDogDB = new DogDB(context);
        }
        return sDogDB;
    }

    //List of 4 Dogs that is required to display
    public DogDB(Context context) {

        //initialising dog object and manually setting 4 Dog details
        Dog dog = new Dog();
        dog.setDogName("Molly");
        dog.setDogBreed("Labrador");
        dog.setDogGender("Female");
        dog.setDogAge(6);
        mDogList.add(dog);

        Dog dog1=new Dog();
        dog1.setDogName("Butch");
        dog1.setDogBreed("German Shepherd");
        dog1.setDogGender("Male");
        dog1.setDogAge(3);
        mDogList.add(dog1);

        Dog dog2=new Dog();
        dog2.setDogName("Milo");
        dog2.setDogBreed("Kelpie");
        dog2.setDogGender("Female");
        dog2.setDogAge(8);
        mDogList.add(dog2);

        Dog dog3=new Dog();
        dog3.setDogName("Odie");
        dog3.setDogBreed("Poodle");
        dog3.setDogGender("Male");
        dog3.setDogAge(1);
        mDogList.add(dog3);

    }

    //for new dog to add in the list
    public void newDog(String name,String breed, String gender, int age){
        Dog dog=new Dog();
        dog.setDogName(name);
        dog.setDogBreed(breed);
        dog.setDogGender(gender);
        dog.setDogAge(age);
        mDogList.add(dog);
    }

    //returns dog list when called for the list
    public List<Dog> getDogs() {
        return mDogList;
    }

    //retrieve dog from the list based on their ID
    public Dog getDog(UUID dogId) {
        for (Dog dog : mDogList) {
            if (dog.getDogID().equals(dogId)) {
                return dog;
            }
        }
        return null;
    }
}

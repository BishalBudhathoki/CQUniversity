package com.bishal.puppyrescue;

import androidx.fragment.app.Fragment;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogListActivity extends SingleFragmentActivity {
    @Override
    protected Fragment createFragment() {
        return new DogListFragment();
    }
}

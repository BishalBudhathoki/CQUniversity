package com.bishal.puppyrescue;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.List;
import java.util.UUID;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20270
 * Assignment 1, Term 2,2020
 */

public class DogPagerActivity extends AppCompatActivity {

    private static final String EXTRA_DOG_ID =
            "com.bishal.puppyrescue.dog_id";
    private ViewPager mViewPager;
    private List<Dog> mDogs;

    public static Intent newIntent(Context packageContext, UUID dogId) {
        Intent intent = new Intent(packageContext, DogPagerActivity.class);
        intent.putExtra(EXTRA_DOG_ID, dogId);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dog_page);

        UUID dogId = (UUID) getIntent()
                .getSerializableExtra(EXTRA_DOG_ID);
        mViewPager = (ViewPager) findViewById(R.id.dog_view_pager);
        mDogs = DogDB.get(this).getDogs();
        FragmentManager fragmentManager = getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {

            @NonNull
            @Override
            public Fragment getItem(int position) {
                Dog dog = mDogs.get(position);
                return DogFragment.newInstance(dog.getDogID());
            }

            @Override
            public int getCount() {
                return mDogs.size();
            }
        });

        //set dog in the list according to the ID
        for (int i = 0; i < mDogs.size(); i++) {
            if (mDogs.get(i).getDogID().equals(dogId)) {
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }
}

export const routes = {
  login: "/login",
  signup: "/signup"
}
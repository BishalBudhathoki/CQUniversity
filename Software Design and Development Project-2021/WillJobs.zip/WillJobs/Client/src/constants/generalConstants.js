export const routes ={
  login: "/",
  register: "/register",
  dashboard: "/dashboard"
}

export const userTypes = {
  jobSeeker: "Job Seeker",
  employer: "Employeer" ,
  admin: "Admin" 
}
exports.mongoConfig   = {
    username: 'laxman',
    password: '12345',
    databaseName:'WillsJobs',
    userCollection:'user',    
    uri:"mongodb+srv://laxman:12345@cluster0.p7gos.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
}

exports.max_stream_size = 100
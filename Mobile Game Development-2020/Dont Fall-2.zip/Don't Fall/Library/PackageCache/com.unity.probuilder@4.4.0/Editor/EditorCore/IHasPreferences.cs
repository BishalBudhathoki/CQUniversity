namespace UnityEditor.ProBuilder
{
    interface IHasPreferences
    {
        void ReloadPreferences();
    }
}

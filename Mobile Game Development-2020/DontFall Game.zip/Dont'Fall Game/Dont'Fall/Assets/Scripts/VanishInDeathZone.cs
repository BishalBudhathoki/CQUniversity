﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class VanishInDeathZone   : MonoBehaviour
{

    [SerializeField]
    string sphereType;

    [SerializeField]
    bool destroySelfBall = false;

    [SerializeField]
    bool destroyOtherBall = false;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == sphereType)
        {
            if (destroySelfBall)
                Destroy(this.gameObject);
            if (destroyOtherBall)
                Destroy(collision.gameObject);
        }
    }

}

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20269
 * Assignment 2, Term 2,2020
 */

document.addEventListener('deviceready', onDeviceReady, false);
jQuery.support.cors = true; // force cross-site scripting
jQuery.support.allowCrossDomainPcontracts = true; // force cross-site scripting

//for mobile, touch support for the list
document.ontouchmove = function(e){ e.preventDefault(); }
var Day1_items = [];
var Day2_items = [];
var Day3_items = [];
var Day4_items = [];
var Day5_items = [];
var saveon = false;

//var initialisation;
var drone_no=0;
var daysList = ["Day1", "Day2", "Day3", "Day4", "Day5"];
var optionsCategory = ["", "civil", "government", "military"]
var latitude = 0.0
var longitude = 0.0
var watchGeo=null // for geolocation
var opt = {timeout: 10000, enableHighAccuracy: true}
var saveLog = $('#saveData')
var date_field = $('#date')
var ipAddressLocal = "http://192.168.43.178:3000"

//this function is executed first
function onDeviceReady() {
    // Cordova is now initialized. Have fun!
    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    $('#Day1').on("click",function (){
        getID(0);
    });
    $('#Day2').on("click",function (){
        getID(1);
    });
    $('#Day3').on("click",function (){
        getID(2);
    });
    $('#Day4').on("click",function (){
        getID(3);
    });
    $('#Day5').on("click",function (){
        getID(4);
    });
    $('#clearButton').on("click",function (){
        clearAll();
    });
    $('#showLogsButton').on("click",function (){
        showData();
    });
    $('#nextButton').on("click",function (){
        next();
    });
    $('#previousButton').on("click",function (){
        prev();
    });
    $('#getLogsButton').on("click",function (){
        getLogsData();
    });
    $('#sendLogButton').on("click",function (){
        sendLogsData();
    });

} //end onDeviceReady

// delegate using Page lifecycle method
$(document).delegate("#secondPage", "pageinit", function() {
    var item = $('#droneNum');
    item.text(daysList[drone_no]);
    //on save data button clicked
    $('#saveData').tap(function(){
        var inerr=false
        getLocation(); //obtain longitude and latitude
        var id = new Date().getTime();
        var date = new Date();
        var dateString=date.getDate()+"/"+(date.getMonth()+1).toString()+"/"+date.getFullYear()+" "+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();
        var drone_id = $('#drone_id').val()
        var pilot = $('#pilot').val()
        var key = $('#key').val()
        var category = optionsCategory[$('#select-category').val()]
        var contract =  $('#contract').val()

        //input validation
        if (drone_id < 1000 || drone_id > 9999) {
            alert("Drone id code must be 4 numbers")
            inerr = true
            $('#drone_id').val("")
        }
        if ( pilot === "") {
            alert("Drone pilot must be a non empty name string")
            inerr = true
            $('#pilot').val("")
        }
        if (category === undefined ) {
            alert("Category is civil, government or military")
            inerr = true
            $('#select-category').val("").selectmenu("refresh")
        }
        if (contract < 0 || contract > 10000) {
            alert("Contract numbers are between 1 and 10000")
            inerr = true
            $('#contract').val("")
        }

        if (! inerr) {
            var itemdata={day:daysList[drone_no],id:id, date:dateString, latitude: latitude, longitude:longitude, drone_id:$('#drone_id').val(), pilot:$('#pilot').val(), key:$('#key').val(), contract:$('#contract').val(), category: optionsCategory[$('#select-category').val()] } ;
            clearAll();
            switch (drone_no) {
                case 0:
                    Day1_items.push(itemdata);
                    localStorage.Day1_items = JSON.stringify(Day1_items); //save data in JSON format locally
                    break;
                case 1:
                    Day2_items.push(itemdata);
                    localStorage.Day2_items = JSON.stringify(Day2_items); //save data in JSON format locally
                    break;
                case 2:
                    Day3_items.push(itemdata);
                    localStorage.Day3_items = JSON.stringify(Day3_items); //save data in JSON format locally
                    break;
                case 3:
                    Day4_items.push(itemdata);
                    localStorage.Day4_items = JSON.stringify(Day4_items); //save data in JSON format locally
                    break;
                case 4:
                    Day5_items.push(itemdata);
                    localStorage.Day5_items = JSON.stringify(Day5_items); //save data in JSON format locally
                    break;
            }
            alert("Log saved")
        }
        else {
            alert("Log not saved. Please Check the Input and Try Again.")
        }
    });
});

//display second page and set day id
$(document).on("pageshow", "#secondPage", function() {
    var item = $('#droneNum');
    item.text(daysList[drone_no]);
    clearAll(); //clear input fields
});

//show latest data
$(document).on("pageshow", "#showData", function() {
    $('#droneLog').listview('refresh')
});

//onSuccess var to obtain geolocation data
var onSuccess = function(position) {
    latitude = position.coords.latitude
    longitude = position.coords.longitude
};

//onError var to obtain the error
var onError = function(error) {
    var txt;
    switch(error.code) {
        case error.PERMISSION_DENIED:    txt = 'Location permission denied'; break;
        case error.POSITION_UNAVAILABLE: txt = 'Location position unavailable'; break;
        case error.TIMEOUT:              txt = 'Location position lookup timed out'; break;
        default: txt = 'Unknown position.'
    }
    alert(txt) //display error
}

$(document).ready(function(){
    Day1_items=JSON.parse(localStorage.Day1_items || '[]');
    Day2_items=JSON.parse(localStorage.Day2_items || '[]');
    Day3_items=JSON.parse(localStorage.Day3_items || '[]');
    Day4_items=JSON.parse(localStorage.Day4_items || '[]');
    Day5_items=JSON.parse(localStorage.Day5_items || '[]');
});

$(window).unload(function(){
    navigator.geolocation.clearWatch(watchGeo);
})

window.applicationCache.addEventListener('updateready',function(){
    window.applicationCache.swapCache();
    location.reload();
});

//for location
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}// end getLocation

//function to store latitude and longitude
function showPosition(position) {
    latitude= position.coords.latitude;
    longitude= position.coords.longitude;
} //end showPosition

//drone functions
//get current time
function getTime() {
    var date= new Date()
    $('#date').html("<br/>"+date.toString()).wrap("pre />");
} //end getTime

//show saved data on device
function showData() {
    $('#droneLog').empty();
    var item = $('#show_title');
    //switch to show data according to the day
    switch (drone_no) {
        case 0:
            item.text("Day1");
            for( var i = 0; i < Day1_items.length; i++ ) {
                addInputData(Day1_items[i],true,$('#droneLog'));
            };
            break
        case 1:
            item.text("Day2");
            for( var i = 0; i < Day2_items.length; i++ ) {
                addInputData(Day2_items[i],true,$('#droneLog'));
            };
            break
        case 2:
            item.text("Day3");
            for( var i = 0; i < Day3_items.length; i++ ) {
                addInputData(Day3_items[i],true,$('#droneLog'));
            };
            break
        case 3:
            item.text("Day4");
            for( var i = 0; i < Day4_items.length; i++ ) {
                addInputData(Day4_items[i],true,$('#droneLog'));
            };
            break
        case 4:
            item.text("Day5");
            for( var i = 0; i < Day5_items.length; i++ ) {
                addInputData(Day5_items[i],true,$('#droneLog'));
            };
            break
    }
    $.mobile.changePage("index.html#showData")
} //end showData

//clear all data in input fields and selector
function clearAll() {
    $('#drone_id').val("")
    $('#pilot').val("")
    $('#select-category').val("").selectmenu("refresh")
    $('#contract').val("")
    $('#key').val("")
} //end clearAll

//send logs data to mongodb
function sendLogsData(){
    switch (drone_no) {
        case 0:
            //send data in json format
            const data=localStorage.getItem("Day1_items");
            sendDataToMongo(data);

            while(Day1_items.length !==0) {
                Day1_items.pop();
            }
            localStorage.removeItem("Day1_items")
            break

        case 1:
            //send data in json format
            const data1=localStorage.getItem("Day2_items");
            sendDataToMongo(data1);
            while(Day2_items.length !==0) {
                Day2_items.pop();
            }
            localStorage.removeItem("Day2_items")
            break

        case 2:
            //send data in json format
            const data3=localStorage.getItem("Day3_items");
            sendDataToMongo(data3);
            while(Day3_items.length !==0) {
                Day3_items.pop();
            }
            localStorage.removeItem("Day3_items")
            break

        case 3:
            //send data in json format
            const data4=localStorage.getItem("Day4_items");
            sendDataToMongo(data4);
            while(Day4_items.length !==0) {
                Day4_items.pop();
            }
            localStorage.removeItem("Day4_items")
            break

        case 4:
            //send data in json format
            const data5=localStorage.getItem("Day5_items");
            sendDataToMongo(data5);
            while(Day5_items.length !==0) {
                Day5_items.pop();
            }
            localStorage.removeItem("Day5_items")
            break
    }
    $.mobile.changePage("index.html#secondPage")
    alert('Logs sent')
} //end sendLogsData

//get logs data from the mongo db
function getLogsData() {
    $('#cloudDBLog').empty();
    const url=ipAddressLocal+"/getDBData/"+daysList[drone_no];
    http_get(url);
    $.mobile.changePage("index.html#getLogsMainPage")
} //end getLogsData

//move to next day higher
function next(){
    if (drone_no === 4) {
        drone_no=0
    }
    else {
        drone_no= drone_no+1
    }
    var item = $('#droneNum');
    item.text(daysList[drone_no]);
    clearAll(); //clear input fields
} //end next

//move to next day lower
function prev(){
    if (drone_no === 0) {
        drone_no=4
    }
    else {
        drone_no = drone_no-1
    }
    var item = $('#droneNum');
    item.text(daysList[drone_no]);
    clearAll(); //clear input fields
} //end prev

//get id for the day and set drone number and update
function getID(id){
        if (id===0){
            drone_no=0;
        }
        else if (id===1){
            drone_no=1;
        }
        else if (id===2){
            drone_no=2;
        }
        else if (id===3){
            drone_no=3;
        }
        else if (id===4){
            drone_no=4;
        }
        else{
            alert("select proper day")
        }
    $.mobile.changePage("index.html#secondPage")
} //end getID

//store input data
function addInputData(itemdata, saveFail, listData) {
    var item = $('#listDataItem').clone();
    item.attr({id:itemdata.id});
    item.find('span.the_time').text(itemdata.date.toString());
    item.find('span.latitude_text').text(", "+itemdata.longitude);
    item.find('span.longitude_text').text(", "+itemdata.longitude);
    item.find('span.drone_id_text').text(", "+itemdata.drone_id);
    item.find('span.pilot_text').text(", "+itemdata.pilot);
    item.find('span.key_text').text(", "+itemdata.key);
    item.find('span.category_text').text(", "+itemdata.category);
    item.find('span.contract_text').text(", "+itemdata.contract);
    if (!saveFail){
        listData.append(item).listview('refresh');
    }
    else {
        listData.append(item);
    }
} //end addInputData

//http_get method
function http_get(suffix) {
    $.ajax(
        {
            url:suffix,
            headers:{},
            dataType:'json',
            success:function(result){
                alert("Search Complete");
                if(result.length===0){
                    alert("No data found");
                }
                for( var i = 0; i < result.length; i++ ) {
                    console.log(result[i]);
                    addInputData(result[i],true,$('#cloudDBLog'));
                }

            },
            error:function(err){
                alert('Network error - Unable to contact server in http_get.'+err)
            }
        }
    )
} //end http_get

//send data to the mongo
function sendDataToMongo(obj) {
    console.log("In send json");
    console.log(obj);
    const urlsuffix=ipAddressLocal+"/postData"
    $.ajax({
        url:urlsuffix,
        type:'POST',
        contentType:'application/json; charset=utf-8',
        dataType:'json',
        data:obj,
        success:function(result){
            console.log("Send successful")
        },
        failure:function(){
            alert("Send failed...");
        }
    });
    console.log("Exit send JSON Data ");
} //end sendDataToMongo


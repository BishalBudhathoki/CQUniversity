//imports
const express = require('express');
const app = express();
const cors=require('cors');
const bodyParser=require('body-parser');
const fileManipulation = require('fs');
const MongoClient = require('mongodb').MongoClient;
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
var config = require('./config.js');
var dbCollection;
const uri = config.mongodb.uri;
const mongoClient = new MongoClient(uri, { useNewUrlParser: true,  useUnifiedTopology: true});

//server created or listening at port 3000
app.listen( 3000, () => {
	console.log("Server started on port 3000");
});

//Connection to the Mongo database
mongoClient.connect(err => {
	dbCollection = mongoClient.db(config.mongodb.database_name).collection(config.mongodb.collection_name);
    console.log("Database Connected!");
});

//CRUD Method (Get) / Routing
// open homepage when localhost:3000 is entered
app.get('/', function(req,res) {
	res.send("Homepage");
});

// open cloud data when localhost:3000/getCloudData or Get Button is entered
//gets all data
app.get('/getDBData', function(req, res) {
	dbCollection.find().toArray( function(err,docs) {
		if(err) {
		  console.log("Error " + err);
		} else {
		   res.send(docs);
		}
	});
});

// open/search data when localhost:3000/getCloudData/id where id = day number is entered
//gets day specific data
app.get('/getDBData/:id', function (req,res){
	console.log(req.params.id);
	mongoClient.db(config.mongodb.database_name).collection(config.mongodb.collection_name).find({day:req.params.id}).toArray( function(err,docs) {
		if(err) {
			console.log("Error " + err);
		} else {
			res.send(docs);
		}
	});
});

// save data when Send Button is entered
app.post('/postData', function(req,res) {
	console.log("Data posted in Mongo Database cloud")
	var data= req.body;
	res.send(req.body);
	//creating JSON log file
	createLogFile(JSON.stringify(data));
	createMultipleListings(mongoClient,data); //multiple entries save in the cloud
});

//method to store multiple entries data or an entry in the database
async function createMultipleListings(client, entriesList){
	const result =  await client.db(config.mongodb.database_name).collection(config.mongodb.collection_name).insertMany(entriesList);
	console.log(`${result.insertedCount} new listing(s) created with the id(s) as below:`);
	console.log(result.insertedIds);
}

//method to create a directory and a .dat format file inside that directory
function createLogFile(data){
	//creating directory name logs and a logs.dat file
	const path=require('path');
	// directory to create and check for its existence
	const dir = './logs';

// check if directory exists in the specified location or not
	if (fileManipulation.existsSync(dir)) {
		console.log('Directory is present');
		fileManipulation.appendFile (path.join(__dirname,'./logs','logs.dat'),data,err=>{
			if(err) throw err;
			console.log('Directory/file Created');
		});
	} else {
		//if directory not found create directory
		console.log('Directory not found.');
		fileManipulation.mkdirSync(dir);
	}
}
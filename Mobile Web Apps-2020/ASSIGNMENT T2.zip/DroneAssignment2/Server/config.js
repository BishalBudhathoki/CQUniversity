/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20269
 * Assignment 2, Term 2,2020
 */

exports.mongodb   = {
    username: '123456',
    password: '123456asdfghjkl;',
    database_name:'Drone',
    collection_name:'data',
    uri:'mongodb+srv://123456:123456asdfghjkl@cluster0.xdro8.mongodb.net/Drone?retryWrites=true&w=majority',
    port:3000
}

exports.max_stream_size = 100
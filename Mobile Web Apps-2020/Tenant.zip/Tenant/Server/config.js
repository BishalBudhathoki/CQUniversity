exports.mongohq   = {
    username: 'Bishal',
    password: 'Bishal123456',
    database_name:'TENANTS',
    collection_name:'Tenant_Collection',
    invoice_collection:'Invoices_Info',
    uri:'mongodb+srv://Bishal:Bishal123456@cluster0.r9vfv.mongodb.net/drone?retryWrites=true&w=majority',
}

exports.max_stream_size = 100
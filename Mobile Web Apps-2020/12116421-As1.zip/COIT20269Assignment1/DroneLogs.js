document.ontouchmove = function(e){ e.preventDefault(); }
 //Global variables declaration
let latitude;
let longitude;
let currentTime;
let dayId;
let nextDayId;
let previousDayId;
let storage = [];

//when the page is refreshed
$(window).load(function() {

    var refreshDayId=localStorage.getItem("varDay");
    console.log("function loaded "+refreshDayId);
    reply_click(refreshDayId);
    showLogDetails();
});

//Functionalities on buttons
$(function() {
    $('#buttonHome').tap(function () {
        homeButtonClicked();
    });

    $('#buttonNext').tap(function () {
       functionNext();
    });
    $('#buttonPrevious').tap(function () {
        functionPrevious();
    });
    
    $('#cleanForm').tap(function () {
        cleanForms();
    });

    $('#buttonSaveLog').tap(function () {

        saveLogs();
    });

    $('#backBtn').tap(function () {

    });

    $('#yesCleanLogs').tap(function () {
        alert("Clean log yes button")
        localStorage.clear();
        storage.length=0;
        reply_click(dayId);
    });
    getLocation();
});


function reply_click(clicked_id) {

    dayId=clicked_id;
    nextDayId=parseInt(dayId);
    previousDayId=parseInt(dayId);
    document.getElementById("dayNumber").innerHTML = "Day"+dayId;
    cleanForms();
    localStorage.setItem("varDay",dayId);
}

function homeButtonClicked(){

}

//clean forms input
function cleanForms(){
    $('#serial').val('');
    $('#pilot').val('');
    $('#key').val('');
    $('#contract').val('');
}

//for GPS coordinates
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { //do nothing
    }
}

//display positions of location
function showPosition(position) {
    latitude= position.coords.latitude;
    longitude= position.coords.longitude;
}

//next button function
function functionNext() {
    if (nextDayId >= 1 && nextDayId < 5) {
        nextDayId = parseInt(nextDayId) + 1;
        cleanForms();
        reply_click(nextDayId);
    }
    else
    {
        alert("Max day = 5 reached");
    }
}


function functionPrevious(){
    if (previousDayId > 1 && previousDayId <= 5) {
        previousDayId = parseInt(previousDayId) - 1;
        nextDayId = parseInt(nextDayId) - 1;
        cleanForms();
        reply_click(previousDayId);
    }
    else
    {
        alert("Minimum day = 1 reached");
    }
}
//save logs details of form in local storage
function saveLogs(){
    //getting value from form
    const inSerial=document.getElementById("serial");
    const inPilotName=document.getElementById("pilot");
    const inKey=document.getElementById("key");
    const inContract=document.getElementById("contract");
    const inCategory=document.getElementById("selectCategory");

    //validation in the text input section
    var numberSerial = /^[1000-9999]+$/;
    var alphabets =/^[a-zA-Z]+$/;
    var number=/^[0-9]+$/;
    var alphabetsNumber=/^[0-9a-zA-Z]+$/;
    var a = false;
    var b = false;
    var c = false;
    var d = false;

    if (inSerial.value.length===4 && inSerial.value.match(numberSerial))
    {
        a=true;
    }
    else
    {
        alert('Drone id must be 4 numbers');
        inSerial.focus();
         a=false;
    }
    if(inPilotName.value.match(alphabets))
    {
        b=true;
    }
    else
    {
        alert('Drone pilot must be a name string');
        inPilotName.focus();
         b=false;
    }
    if(inKey.value.match(alphabetsNumber))
    {
        c=true;
    }
    else
    {
        alert('Enter valid key value');
        inKey.focus();
         c=false;
    }
    if(inContract.value.match(number))
    {
        d=true;
    }
    else
    {
        alert('Contract must not be empty and should have number input');
        inContract.focus();
         d=false;
    }

    //storing value in variable
    const serialData=inSerial.value;
    const pilotName=inPilotName.value;
    const keyValue=inKey.value;
    const contractValue=inContract.value;
    const categoryValue=inCategory.value;
    currentTime = new Date();
    if(a===true && b===true &&c===true &&d===true ) {
        item = {
            "Day": dayId.toString(),
            'Date Time': currentTime,
            'latitude': latitude,
            'longitude': longitude,
            'Serial': serialData,
            'Pilot Name': pilotName,
            'Key': keyValue,
            'Contract': contractValue,
            'Category': categoryValue
        }

        //using JSON to store list data
    storage = JSON.parse(localStorage.getItem('data')) || [];
    storage.push(item);
    const stringData = JSON.stringify(storage);
    localStorage.setItem('data', stringData);
    alert("Data saved successfully")
    }
    else{
    alert("Data not saved")
    }
}

//to display log details
function showLogDetails(){
    $("#sortedList").empty();
    let dayValueForShow=localStorage.getItem("varDay");
    document.getElementById("droneLogDay").innerHTML = "Day" + dayId;
    const listData=document.getElementById("dataList");
    const result = JSON.parse(localStorage.getItem('data'));
            result.forEach(item => {
                let filteredData = '';
                //filter data according to the day Id
                const arraySave = Object.keys(item).filter(key => item['Day'] === dayValueForShow.toString())
                console.log(dayId, arraySave)
                arraySave.forEach(key => {
                    if(key!=='Day') {
                        filteredData += `${item[key]}, ` ;
                    }
                })
                //display data in html page
                const paragraph = document.createElement("P");
                paragraph.innerHTML = filteredData;
                sortedList.appendChild(paragraph);
            })
    cleanForms();
}



package student.presenter;

//StudentPresent class

import student.model.IQuery;
import student.model.QueryException;
import student.model.IConnect;
import student.model.ConnectionException;
import student.model.Marks;

import student.view.FXMLController;
import student.view.IView;

import java.util.List;

// The queries that are available for the address book
import static student.model.StudentModel.Query.*;

/**
 * StudentPresenter provides a presenter implementation of the MVP pattern for
 * the aGrade management application. As such, the class provides methods that manage
 * the connection to the Grade Management model (via the IConnect interface), query
 * the model (via the IQuery interface) and update the view (via the IView
 * interface). In this implementation, the presenter only interacts with the
 * view for display updating, and not for retrieval of user input. Furthermore,
 * user input is validated in the presenter and not in the view.
 *
 * @author Bishal Budhathaoki
 */
public class StudentPresenter {

    public static class ViewModel {
        List<Marks> model;
        Marks current;
        int index;
        int n;

        ViewModel() {
        }

        void set( List<Marks> m )  {
            model = m;
            index = 0;
            n = model.size();
            current = model.get(index);
        }

        IndexedStudent previous() {
            if (--index < 0 )
                index = n-1;
            return new IndexedStudent( model.get(index), index+1, n );
        }

        IndexedStudent next() {
            if (++index > n-1 )
                index = 0;
            return new IndexedStudent( model.get(index), index+1, n );
        }

        IndexedStudent current() {
            return new IndexedStudent( model.get(index), index+1, n );
        }
    }

    // The context for model and view interaction
    IView<IndexedStudent> view;
    IQuery<student.model.StudentModel.Query, Marks> queries;
    IConnect connector;
    ViewModel viewModel;

    /**
     * Create a presenter instance. As there is a circular dependency between the
     * view and the presenter, only the presenters model dependencies are injected
     * via the constructor - the view dependency is explictly injected via the
     * bind() method.
     * @param iq IQuery
     * @param ic IConnect
     * @param iv IView
     */
    public StudentPresenter(IView<IndexedStudent> iv, IQuery<student.model.StudentModel.Query, Marks> iq, IConnect ic) {
        // initialise controller access
        view = iv;
        // initialise model access
        queries = iq;
        connector = ic;
        // initialise the browsing context
        viewModel = new ViewModel();
    }

    /**
     * For the records being browsed, make the previous record the current
     * record and display it, together with its position in the browsing
     * context. If the current record is the first record, the last record will
     * become the current record.
     */
    public void showPrevious() {
        view.displayRecord( viewModel.previous() );
    }

    /**
     * For the records being browsed, make the next record the current record
     * and display it, together with its position in the browsing
     * context. If the current record is the last record, the first record will
     * become the current record.
     */
    public void showNext() {
        view.displayRecord( viewModel.next() );
    }

    private void displayCurrentRecord(List<Marks> results) {
        if (results.isEmpty()) {
            view.displayMessage("No records found");
            view.setBrowsing(false);
            return;
        }
        view.displayRecord(viewModel.current());
        view.setBrowsing(true);
    }

    /**
     * Set the browsing context to contain all records in the grade management with
     * a specified StudentID. Display the first record or an error message if no
     * records are found.
     * @param studentID the name being searched for.
     * @throws IllegalArgumentException if lastName is an empty string.
     */
    public void selectByStudentID(String studentID) throws IllegalArgumentException {
        // No checking is performed for studentID being null, as this constitutes
        // a programming error and having the program crash (with a stack trace)
        // is reasonable in this case.
        if (studentID.equals("")) {
            throw new IllegalArgumentException("Argument must not be an empty string");
        }
        try {
            List<Marks> results = queries.select(STUDENT_ID, studentID);
            viewModel.set(results);
            displayCurrentRecord(results);
        } catch (QueryException e) {
            view.displayError(e.getMessage());
        }
    }

    /**
     * Set the browsing context to  all records in the Grade Management who's grade is not calculated
     * when inserting data in the database using SQL Query as program does not allow empty field and display
     * the record.
     */
    public void gradeAll() throws QueryException {
        List<Marks> results = queries.select(GRADE_ALL);
        viewModel.set(results);
        displayCurrentRecord(results);
    }

    /**
     * Set the browsing context to  all records in the Grade Management who's total is in the range given by
     * @param min for minimum
     * @param max for maximum in the range and display
     * the record.
     */
    public void range(double min,double max) throws QueryException, IndexOutOfBoundsException {
        List<Marks> results = queries.select(RANGE,min,max);
        try {
            viewModel.set(results);
            displayCurrentRecord(results);
        } catch (IndexOutOfBoundsException e) {
            view.displayError(e.getMessage());
            System.out.println("Index out of bound, No data exist");

        }
    }

    /**
     * Set the browsing context to  all records in the Grade Management who's total is in the range given by
     * @param gradeOpt for grade option and display the record.
     */
    public void gradeOptionMethod(String gradeOpt) throws QueryException {
        List<Marks> results = queries.select(GRADE_OPTION,gradeOpt);
        try {
            viewModel.set(results);
            displayCurrentRecord(results);
        } catch (IndexOutOfBoundsException e) {
            view.displayError(e.getMessage());
            System.out.println("Index out of bound, No data exist");

        }
    }

    /**
     * Set the browsing context to  all records in the Grade Management who's total is in next near grade set by
     * @param tol for tolerance
     * and display the record.
     */
    public void tolerance(double tol) throws QueryException {
        List<Marks> results = queries.select(TOLERANCE, tol);
        viewModel.set(results);
        displayCurrentRecord(results);
    }
    /**
     * Set the browsing context to  all records in the grade management and display
     * the first record.
     */
    public void selectAll() {
        try {
            List<Marks> results = queries.select(ALL);
            System.out.println(results);
            viewModel.set(results);
            displayCurrentRecord(results);
        } catch (QueryException e) {
            view.displayError(e.getMessage());
        }
    }

    /**
     * Insert a new entry into the grade management.
     * @param assign1 assignment1 marks
     * @param assign2 assignment2 marks
     * @param exam exam marks
     * @param total total marks
     * @param grade grade
     * @throws IllegalArgumentException if any of the parameters are empty strings
     */
    public void insert(String stdID, double assign1, double assign2, double exam, double total, String grade) throws IllegalArgumentException {

        try {
            // The id field  will be created by the model
            Marks p = new Marks(stdID, assign1, assign2, exam, total, grade);

            int result = queries.command(INSERT, p);
            if (result == 1) {
                view.displayMessage("Person added");
            } else {
                view.displayMessage("Person not added");
            }
            view.setBrowsing(false);
        } catch (Exception e) {
            view.displayError(e.getMessage());
            view.displayMessage("Data exist in database");
        }
    }

    /**
     * Update an existing entry into the grade management.
     * @param assign1 assignment1 marks
     * @param assign2 assignment2 marks
     * @param exam exam marks
     * @param total total marks
     * @param grade grade
     * @throws IllegalArgumentException if any of the parameters are empty strings
     */
    public void update(String stdID, double assign1, double assign2, double exam, double total, String grade) throws IllegalArgumentException {

        try {
            // The id field  will be created by the model
            Marks p = new Marks(stdID, assign1, assign2, exam, total, grade);
            System.out.println(p.getAssignment1());
            int result = queries.command(UPDATE, p);
            if (result == 1) {
                view.displayMessage("Person updated");
            } else {
                view.displayMessage("Person not updated");
            }
            view.setBrowsing(true);
        } catch (Exception e) {
            view.displayError(e.getMessage());
        }
    }

    /**
     *  Close the grade management.
     */
    public void close() {
        try {
            connector.disconnect();
        } catch (ConnectionException e) {
            view.displayError(e.getMessage());
        }
    }

}

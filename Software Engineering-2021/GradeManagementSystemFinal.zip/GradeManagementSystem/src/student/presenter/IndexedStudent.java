package student.presenter;

import student.model.Marks;

/**
 * IndexedPerson provides a wrapper for a Marks record that provides
 * information relating to its position in the browsing context maintained by
 * MarksPresenter.
 *
 * @author Bishal Budhathoki
 */
public class IndexedStudent {

    private final Marks p;
    private final int i;
    private final int n;

    /**
     * Create a wrapper for a Marks object
     *
     * @param p the object to be wrapped
     * @param i the position of the object in the browsing context
     * @param n the number of objects in the browsing context
     */
    public IndexedStudent(Marks p, int i, int n) {
        this.p = p;
        this.i = i;
        this.n = n;
    }

    /**
     * @return the marks object being wrapped
     */
    public Marks getMarks() {
        return p;
    }

    /**
     * @return the position of the wrapped marks object in the browsing context
     */
    public int getIndex() {
        return i;
    }

    /**
     * @return the number of objects in the browsing context
     */
    public int getSize() {
        return n;
    }

}

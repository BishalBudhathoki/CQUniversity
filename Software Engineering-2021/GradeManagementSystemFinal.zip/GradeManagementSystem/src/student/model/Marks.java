package student.model;

/**
 * A data container for grade management records. No setters are provided, as
 * attributes are read-only. Getters for all attributes are provided.
 *
 * @author Bishal Budhathoki
 */
//class marks
public class Marks {
    //variables used
    private final String studentID;
    private final double assignment1;
    private final double assignment2;
    private final double examMarks;
    private final double totalMarks;
    private final String grade;

    /**
     * Create a data transfer object for an address book record.
     *
     * @param assessment1 assignment1 marks
     * @param id studentID
     * @param assessment2 assignment2 marks
     * @param examMarks exam marks
     * @param totalMarks total marks
     * @param grade grade from the total marks
     */
    //parameterised constructor
    public Marks(String id, double assessment1, double assessment2,
                 double examMarks, double totalMarks, String grade) {
        this.studentID = id;
        this.assignment1 = assessment1;
        this.assignment2 = assessment2;
        this.examMarks = examMarks;
        this.totalMarks = totalMarks;
        this.grade = grade;

    } //end constructor Marks

    // No setters are provided - use the constructor.

    //getter methods

    /**
     * @return student record identifier
     */
    public String getStudentID() {
        return studentID;
    }

    /**
     * @return assignment 1 marks
     */
    public double getAssignment1() {
        return assignment1;
    }

    /**
     * @return assignment 2 marks
     */
    public double getAssignment2() {
        return assignment2;
    }

    /**
     * @return exam marks
     */
    public double getExamMarks() {
        return examMarks;
    }

    /**
     * @return total marks
     */
    public double getTotalMarks() {
        return totalMarks;
    }

    /**
     * @return grade marks
     */
    public String getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "Marks{" +
                "studentID='" + studentID + '\'' +
                ", assignment1=" + assignment1 +
                ", assignment2=" + assignment2 +
                ", examMarks=" + examMarks +
                ", totalMarks=" + totalMarks +
                ", grade='" + grade + '\'' +
                '}';
    }
} //end Marks class

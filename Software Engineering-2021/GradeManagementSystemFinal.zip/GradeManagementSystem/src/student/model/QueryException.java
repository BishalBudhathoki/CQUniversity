package student.model;

/**
 * @author Bishal Budhathoki
 */
//handles exceptions in query and throws the exception cause
public class QueryException extends Exception {
    public QueryException(String message,Throwable cause) {
        super(message,cause);
    }
} // end queryException


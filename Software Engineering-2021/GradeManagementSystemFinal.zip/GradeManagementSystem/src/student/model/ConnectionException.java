package student.model;

public class ConnectionException extends RuntimeException {
// if no connection made and throws Run time exception
    public ConnectionException( String msg, Throwable cause ) {
        super(msg,cause);
    }
} //end ConnectionException

package student.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.EnumMap;


/**
 * The StudentModel class is responsible for the management of student grade
 * management.Connection functionality is accessed via the IConnect interface; query
 * functionality via the IQuery interface.
 *
 * @author Bishal Budhathoki
 */

//studentModel Class implementing other interfaces
public class StudentModel implements IConnect, IQuery<StudentModel.Query, Marks> {

    /**
     * The Query enum specifies the queries that are supported by this manager
     */
    public enum Query {
        INSERT, ALL, STUDENT_ID,UPDATE, RANGE, TOLERANCE, GRADE_ALL, GRADE_OPTION
    };

    /*
     * We use enummaps to map queries (enum values) to SQL commands and prepared
     * statements in a typesafe manner. Hashmaps could be used to the same effect,
     * but they would be less eficient, not that it matters. You could use arrays
     * indexed by enum.ordinal() or by int constants, but you then lose type safety
     * among other things.
     */

    // Database details for the grade management system
    private static final String URL = "jdbc:derby://localhost:1527//AB;create=true";
    private static final String USERNAME = "ab";
    private static final String PASSWORD = "ab";

    //EnumMap for SQL commands and statements to handle
    private EnumMap<Query, String> sqlCommands
            = new EnumMap<>(StudentModel.Query.class);
    private EnumMap<Query, PreparedStatement> statements
            = new EnumMap<>(StudentModel.Query.class);

    // The connection to the grade management system
    private Connection connection = null;

    /**
     * Create an instance of the student grade manager. Clients have no access to
     * the implementation details of the grade management. Also, clients can create
     * multiple instances of the manager, which is probably a bad idea.
     */

    //No parameter Constructor studentModel
    public StudentModel() {
        // Specify the queries that are supported and handled further
        //select all data from database
        sqlCommands.put(Query.ALL,
                "SELECT * FROM Marks");
        //select all data from database given the studentID
        sqlCommands.put(Query.STUDENT_ID,
                "SELECT * FROM Marks WHERE StudentId = ?");
        //insert data in to the table Marks given the values
        sqlCommands.put(Query.INSERT,
                "INSERT INTO Marks (StudentID, Assignment1,Assignment2, Exam,Total,Grade) VALUES (?, ?, ?, ?,?,?)");
        sqlCommands.put(Query.UPDATE,
                "UPDATE Marks SET Assignment1=?, Assignment2=?,Exam=?,Total=?,Grade=? WHERE StudentID=?");
        sqlCommands.put(Query.RANGE,
                "SELECT * FROM MARKS WHERE total>=? AND total<=?");
        sqlCommands.put(Query.TOLERANCE,
                "SELECT * FROM MARKS WHERE ((50-total)>0 AND (50-total)<=? )OR((65-total)>0 AND (65-total)<=? )OR((75-total)>0 AND (75-total)<=? )OR((85-total)>0 AND (85-total)<=? )");
        sqlCommands.put(Query.GRADE_ALL,
                "SELECT * FROM MARKS WHERE grade='?'");
        sqlCommands.put(Query.GRADE_OPTION,
                "SELECT * FROM MARKS WHERE grade=? ORDER BY Total ASC");
    }// end constructor

    // IConnct implementation

    /**
     * Connect to the address book
     * @throws ConnectionException
     */
    //handles connection to the database
    @Override
    public void connect() throws ConnectionException {
        // Connection to the grade management system database
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (SQLException e) { //exception handling
            throw new ConnectionException("Unable to open data source or connect to database", e);
        }
    } //end connect method

    /**
     * Perform any initialization that is needed before queries can be
     * performed.
     *
     * @throws ConnectionException
     */
    //handles initialisation in the database
    @Override
    public void initialise() throws ConnectionException {
        // Creates prepared statements for each query
        try {
            for (Query q : Query.values()) {
                statements.put(q, connection.prepareStatement(sqlCommands.get(q)));
            }
        } catch (SQLException e) { //exception handling
            throw new ConnectionException("Unable to initialise data source", e);
        }
    }

    /**
     * Disconnect from the grade management
     *
     * @throws ConnectionException
     */
    //disconnect with the database
    @Override
    public void disconnect() throws ConnectionException {

        try (Connection c = connection) {
            for (Query q : Query.values()) {
                statements.get(q).close(); //close every queries
            }
        } catch (SQLException e) { //exception handling
            throw new ConnectionException("Unable to close data source", e);
        }
    } // disconnect with the database

    // IQuery implementation

    /**
     * Perform a selection on the grade management.
     * @param q the selection as specified in the Query enum
     * @param p parameters for the query specified as a varags of type Object
     * @return a List of Student Marks objects that match query specification
     * @throws QueryException
     */

    @Override
    public List<Marks> select(Query q, Object... p) throws QueryException {
        switch (q) { //switch queries for select command
            case ALL:
                return getAllStudent();
            case STUDENT_ID:
                return getStudentByID((String) p[0]);
            case RANGE:
                return rangeDetails((Double)p[0],(Double) p[1]);
            case TOLERANCE:
                return returnTolerance((Double) p[0]);
            case GRADE_ALL:
                return gradeAll();
            case GRADE_OPTION:
                return gradeOption((String) p[0]);
        }
        // Should never happen
        return null;
    } // end select

    /**
     * Perform a command (insert, update ... ) on the grade management
     * @param query the command as specified in the Query enum
     * @param marks a Mark object containing the data for the command
     * @return the number of records in the grade management impacted on by the command
     * @throws QueryException
     */
    @Override
    public int command(Query query, Marks marks) throws QueryException {
        switch (query) { //switch command for INSERT command
            case INSERT:
                return addStudent(marks);
            case UPDATE:
                return updateStudent(marks);
        }
        return -1;
    } //end command

    // Helper methods

    /*
     * Select all of the entries in the grade management
     */
    private List<Marks> getAllStudent() throws QueryException{
        // get prepared statement
        PreparedStatement ps = statements.get(Query.ALL);
        // executeQuery returns ResultSet containing matching entries
        // try with resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                Marks p = creatStudent( resultSet);
                results.add(p);
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Select all of the entries in the grade management who's grade is to be calculated
     */
    private List<Marks> gradeAll() throws QueryException{
        // get prepared statement

        PreparedStatement ps = statements.get(Query.GRADE_ALL);
        // executeQuery returns ResultSet containing matching entries; try with
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(creatStudent(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Select all of the entries in the grade management who's total marks is near next grade
     * determined by tolerance value and default value is 2
     */
    private List<Marks> returnTolerance(double tol) throws QueryException{
        // get prepared statement
        System.out.println("Tolerance value "+tol);
        PreparedStatement ps = statements.get(Query.TOLERANCE);
        try {
            // Insert last name into prepared statement
            ps.setDouble(1, tol);
            ps.setDouble(2, tol);
            ps.setDouble(3, tol);
            ps.setDouble(4, tol);

        }
        catch (SQLException e) {
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(creatStudent(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Select all of the entries in the grade management who's total marks is in the range provided
     */
    private List<Marks> rangeDetails(double min, double max) throws QueryException, IndexOutOfBoundsException{
        // get prepared statement
        System.out.println("Range value " +min +" - " +max);
        PreparedStatement ps = statements.get(Query.RANGE);
        try {
            // Insert last name into prepared statement
            ps.setDouble(1, min);
            ps.setDouble(2, max);

        } catch (SQLException e) {
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(creatStudent(resultSet));
            }
            return results;
        } catch (SQLException | IndexOutOfBoundsException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Select all of the entries in the grade management whose grade is similar to provided
     * and increase in Total Marks order
     */
    private List<Marks> gradeOption(String grade) throws QueryException, IndexOutOfBoundsException{
        // get prepared statement
        System.out.println("Grade value " +grade);
        PreparedStatement ps = statements.get(Query.GRADE_OPTION);
        try {
            // Insert last name into prepared statement
            ps.setString(1, grade);

        } catch (SQLException e) {
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(creatStudent(resultSet));
            }
            return results;
        } catch (SQLException | IndexOutOfBoundsException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }
    /*
     * Select all of the entries in the grade management given student ID
     * this is like a search for a student
     */
    private List<Marks> getStudentByID(String studentID) throws QueryException{
        // Look up prepared statement
        PreparedStatement ps = statements.get(Query.STUDENT_ID);
        try {
            // Insert last name into prepared statement
            ps.setString(1, studentID);
        } catch (SQLException e) {
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // executeQuery returns ResultSet containing matching entries; try with
        // resources automatically closes result set (and handles exceptions correctly)
        try (ResultSet resultSet = ps.executeQuery()) {
            List<Marks> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(creatStudent(resultSet));
            }
            return results;
        } catch (SQLException e) {
            throw (new QueryException("Unable to execute selection query", e));
        }
    }

    /*
     * Create an entry in the grade management given all details
     */
    private Marks creatStudent(ResultSet rs) throws QueryException {
        Marks p = null;
        try {
            p = new Marks(
                    rs.getString("studentID"),
                    rs.getDouble("assignment1"),
                    rs.getDouble("assignment2"),
                    rs.getDouble("exam"),
                    rs.getDouble("total"),
                    rs.getString("grade")
            );
        } catch (SQLException e) {
            throw (new QueryException("Unable to process the result of selection query",e));
        }
        return p;
    }

    /*
     * Add a record to the Grade management. Record fields are extracted from the method
     * parameter, which is a Marks object. The id field is not
     * ignored - it will be not be autogenerated by the Grade management.
     */
    // add student in the database
    private int addStudent(Marks m) throws QueryException {
        System.out.println("Add student");
        // prepared statement to obtain INSERT Query
        // Look up prepared statement
        PreparedStatement preparedStatement = statements.get(Query.INSERT);
        // insert student attributes into prepared statement
        try {
            preparedStatement.setString(1, m.getStudentID());
            preparedStatement.setDouble(2, m.getAssignment1());
            preparedStatement.setDouble(3, m.getAssignment2());
            preparedStatement.setDouble(4, m.getExamMarks());
            preparedStatement.setDouble(5, m.getTotalMarks());
            preparedStatement.setString(6, m.getGrade());
        } catch (SQLException e) { //exception handling
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // insert all new student entries;
        try {
            return preparedStatement.executeUpdate(); //returns numbers of rows updated
        } catch (SQLException e) { //exception handling
            throw (new QueryException("Insert command not executed", e));
        }
    } //end addStudent

    /*
     * Select a student in the grade management given student ID
     * and update the changed details. Here every detail is updated even the unchanged for
     * an entry
     */
    // add student in the database
    private int updateStudent(Marks m) throws QueryException {
        System.out.println("Update student");
        // prepared statement to obtain INSERT Query
        PreparedStatement preparedStatement = statements.get(Query.UPDATE);
        // insert student attributes into prepared statement
        try {

            preparedStatement.setDouble(1, m.getAssignment1());
            preparedStatement.setDouble(2, m.getAssignment2());
            preparedStatement.setDouble(3, m.getExamMarks());
            preparedStatement.setDouble(4, m.getTotalMarks());
            preparedStatement.setString(5, m.getGrade());
            preparedStatement.setString(6, m.getStudentID());
        } catch (SQLException e) { //exception handling
            throw (new QueryException("Unable to parametrise selection query", e));
        }
        // insert all new student entries;
        try {
            return preparedStatement.executeUpdate(); //returns numbers of rows updated
        } catch (SQLException e) { //exception handling
            throw (new QueryException("Insert command not executed", e));
        }
    } //end addStudent
} //end studentModel

package student;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import student.presenter.IndexedStudent;
import student.presenter.StudentPresenter;
import student.view.FXMLController;
import student.model.StudentModel;
import student.model.ConnectionException;
import student.view.IView;

/**
 * Grade Management is the application class following MVP of the example
 * presented in Chapter 29 of Deitel & Deitel (2012), "Java How to Program Ninth
 * Edition", Prentice Hall that calulates grade, manage records and display with more functionality.
 *
 * @author Bishal Budhathoki
 */
public class Student extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("view/GUI.fxml"));
        Parent root = loader.load();
        FXMLController controller = loader.getController();

        // Create the model. Exit the application if connection be made to the
        // grade management is not success.
        StudentModel studentModel = new StudentModel();
        try {
            studentModel.connect(); //connecting to the database
            studentModel.initialise();
        } catch (ConnectionException e) { //error handling
            System.err.println(e.getMessage());
            e.getCause().printStackTrace();
            System.exit(1); //close application
        }

        // Create the presenter. The controller was created (via a n--argument
        // constructor) by the loader. Injection of the presenter is therefore
        // achieved using an explicit binding method (bind()).
        StudentPresenter pp = new StudentPresenter(controller, studentModel, studentModel );
        controller.bind( pp );
        Scene scene = new Scene(root);
        stage.setTitle("Grade Management System" );
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

package student.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import student.model.Marks;
import student.model.QueryException;
import student.presenter.IndexedStudent;
import student.presenter.StudentPresenter;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;


//Controller file to handle UI Manipulation/input
public class FXMLController implements Initializable, IView<IndexedStudent> {

    public Button previousButton;
    public Button nextButton;
    public Button browse, find;
    public Button updateBtn;
    public Button saveBtn;
    public ComboBox<String> gradeOption;

    //variables and widgets used

    @FXML
    private TextField studentIDField;

    @FXML
    private TextField assignment1Field;

    @FXML
    private TextField assignment2Field;

    @FXML
    private TextField totalMarksField;

    @FXML
    private TextField gradeField;

    @FXML
    public TextArea displayArea;

    @FXML
    private TextField currentIndex;

    @FXML
    private TextField finalIndex;
    @FXML
    public TextField examField;
    public TextField toleranceValue;
    public ComboBox<String> rangeMinMax;

    public String studentID, assignment1, assignment2, exam, total, grade;
    private String ass1MarkTable,ass2MarkTable,examMarkTable,totalMarkTable;

    double assignmnt1, assignmnt2, exm, ttl;
    double minMaxRange, maximum;
    double toleranceValue1;

    //objects used
    StudentPresenter presenter;
    Marks marksTable;
    ObservableList<Marks> observableList = FXCollections.observableArrayList();
    Alert alert = new Alert(Alert.AlertType.NONE);

    //initialise method and is executed when controller is called
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //initialising combobox for range
        rangeMinMax.getItems().addAll( "50 - 64", "65 - 74", "75 - 84", "85 - 100");
        gradeOption.getItems().addAll("HD", "D", "C", "P", "F", "SE", "SA", "AF");
    }

    @FXML
    void browse(ActionEvent event) throws NullPointerException{
        try {
            presenter.selectAll();
        } catch (NullPointerException ne) {
            System.out.println("No data to load, null pointer: " + ne);
        }
    }

    @FXML
    void find(ActionEvent event) throws IllegalArgumentException{
        try {
            System.out.println("Find: "+ studentIDField.getText());
            presenter.selectByStudentID( studentIDField.getText() );
        } catch (IllegalArgumentException ie) {
            System.out.println("Student ID field is empty: " +ie);
        }

    }
    @FXML
    void next(ActionEvent event) throws NullPointerException{
        try {
            System.out.println("Next button selected");
            presenter.showNext();
        } catch (NullPointerException ne) {
            System.out.println("No data to go next, null pointer: " + ne);
        }
    }

    @FXML
    void previous(ActionEvent event) throws NullPointerException{
        try {
            System.out.println("Previous button selected");
            presenter.showPrevious();
        } catch (NullPointerException ne) {
            System.out.println("No data to go previous, null pointer: " + ne);
        }

    }

    public void bind( StudentPresenter pp ) {
        presenter = pp;
    }

    //for calculating grade when calculate grade button is selected
    @FXML
    void gradeCalculation(ActionEvent event) {
        System.out.println("Grade Calculation");
        //obtaining data from the input field and initialising
        studentID = studentIDField.getText();
        assignment1 = assignment1Field.getText();
        assignment2 = assignment2Field.getText();
        exam = examField.getText();
        //Validation before executing the grade calculation
        // create an alert if any field is empty
        if (studentIDField.getText().isEmpty() || assignment1Field.getText().isEmpty()
                || assignment2Field.getText().isEmpty() || examField.getText().isEmpty())
        {
            // set alert type as warning
            alert.setAlertType(Alert.AlertType.WARNING);
            // set content text to display in the warning alert
            alert.setContentText("Please validate the input fields");
            // displays the dialog box
            alert.show();
        }
        //when input fields are not empty
        else {

            try {
                //converting string to double as input are accepted as string
                // and we want it as a numbers in double format
                assignmnt1 = Double.parseDouble(assignment1);
                assignmnt2 = Double.parseDouble(assignment2);
                exm = Double.parseDouble(exam);
                ttl = assignmnt1 + assignmnt2 + exm;
                //assignment 1 marks cannot be above 20
                if (assignmnt1 > 20) {
                    // set alert type as warning
                    alert.setAlertType(Alert.AlertType.WARNING);
                    // set content text to display in the warning alert
                    alert.setContentText("Assignment 1 marks cannot be greater than 20." +
                            " \n Please correct the details");
                    // displays the dialog box
                    alert.show();
                    assignment1Field.clear();
                    totalMarksField.clear();
                    gradeField.clear();
                }
                //assignment 2 marks cannot be above 30
                if (assignmnt2 > 30) {
                    // set alert type as warning
                    alert.setAlertType(Alert.AlertType.WARNING);
                    // set content text to display in the warning alert
                    alert.setContentText("Assignment 2 marks cannot be greater than 30." +
                            " \n Please correct the details");
                    // displays the dialog box
                    alert.show();
                    assignment2Field.clear();
                    totalMarksField.clear();
                    gradeField.clear();
                }
                //exam marks cannot be above 50
                if (exm> 50) {
                    // set alert type as warning
                    alert.setAlertType(Alert.AlertType.WARNING);
                    // set content text to display in the warning alert
                    alert.setContentText("Exam marks cannot be greater than 50." +
                            " \n Please correct the details");
                    // displays the dialog box
                    alert.show();
                    examField.clear();
                    totalMarksField.clear();
                    gradeField.clear();
                }
                //total marks cannot be above 100
                if (ttl > 100) {
                    // set alert type as warning
                    alert.setAlertType(Alert.AlertType.WARNING);
                    // set content text to display in the warning alert
                    alert.setContentText("Total cannot be greater than 100. \n Please correct the details");
                    // displays the dialog box
                    alert.show();
                    //clearing fields
                    assignment1Field.clear();
                    assignment2Field.clear();
                    examField.clear();
                    totalMarksField.clear();
                    gradeField.clear();

                } else {
                    total = String.valueOf(ttl);
                    //calculate grade method returns grade of a student
                    grade = calculateGrade(ttl);
                    //setting the textField with total marks and grade
                    totalMarksField.setText(total);
                    gradeField.setText(grade);
                }
            } catch (NumberFormatException err) { //exception handling
                // set alert type as warning
                alert.setAlertType(Alert.AlertType.WARNING);
                // set content text to display in the warning alert
                alert.setContentText("Please provide numbers only on marks.");
                // displays the dialog box
                alert.show();
            }
        }// end else
    } //end gradeCalculation

    //grade calculation method
    public String calculateGrade(double totalMarks) {
        updateBtn.setDisable(false);
        saveBtn.setDisable(false);
        double ttlMarks = totalMarks; //passing total marks to a variable
        String tempGrade;
        //if else loop to calculate grade according to the total marks in a range
        if (ttlMarks >= 85) {
            tempGrade = "HD";
        } else if (ttlMarks >= 75 && ttlMarks <= 84) {
            tempGrade = "D";
        } else if (ttlMarks >= 65 && ttlMarks <= 74) {
            tempGrade = "C";
        } else if (ttlMarks >= 50 && ttlMarks <= 64) {
            tempGrade = "P";
        } else if (ttlMarks >= 45 && ttlMarks < 50) {

            if (Double.parseDouble(examField.getText()) < 20) { //if in above range
               // but exam marks is less than 20 (actually less than 50%)
               tempGrade = "SE";
            } else if (Double.parseDouble(assignment1Field.getText()) == 0
                    && Double.parseDouble(assignment2Field.getText()) == 0) {
               //check if both assignment marks is zero
               tempGrade = "AF";
            } else if (Double.parseDouble(assignment1Field.getText()) < 5
                    || Double.parseDouble(assignment2Field.getText()) < 10) {
                //check if one of the assignment has less han 5 or
                // another has less than 10 marks
                tempGrade = "SA";
            } else {
                //if not in above ranges, grade it as fail
                tempGrade = "F";
            }

        } else { //else grade is fail
            tempGrade = "F";
        }
        return tempGrade; //return grade
    } //end grade

    // IPersonView interface implementation
    // IView interface implementation
    @FXML
    void saveDataInDatabase(ActionEvent event) throws NullPointerException {
        try {
            System.out.println("Insert Data");
            presenter.insert(
                    studentID,
                    assignmnt1,
                    assignmnt2,
                    Double.parseDouble(exam),
                    Double.parseDouble(total),
                    grade

            );
        } catch (NullPointerException ne) {
            System.out.println(ne);
        }
    }// end savDataInDatabase

    // update marks in database
    @FXML
    void updateMarksInDatabase(ActionEvent event) throws SQLException, QueryException {
        double updateAss1Marks, updateAss2Marks, updateExamMarks, updateTotalMarks; //variables used

        studentID = studentIDField.getText();
        assignment1 = assignment1Field.getText();
        assignment2 = assignment2Field.getText();
        exam = examField.getText();
        updateAss1Marks = Double.parseDouble(assignment1);
        updateAss2Marks = Double.parseDouble(assignment2);
        updateExamMarks = Double.parseDouble(exam);
        updateTotalMarks = updateAss1Marks + updateAss2Marks + updateExamMarks;
        total = String.valueOf(updateTotalMarks);
        grade = calculateGrade(updateTotalMarks);
        System.out.println("Update Data");
        presenter.update(
                studentID,
                updateAss1Marks,
                updateAss2Marks,
                Double.parseDouble(exam),
                updateAss1Marks + updateAss2Marks + updateExamMarks,
                grade
        );
    }

    double min, max; //variable for range to store minimum and maximum value in a range
    //this provide data of student  that falls in a certain range users wanted
    @FXML
    void rangeFilter(ActionEvent event) throws NullPointerException {
        try {

            String value = rangeMinMax.getValue();
            System.out.println("Range: " +value);

            if (value.matches("50 - 64")) {
                min = 50;
                max = 64;
                presenter.range(min, max);
            } else if (value.matches("65 - 74")) {
                min = 65;
                max = 74;
                presenter.range(min, max);
            } else if (value.matches("75 - 84")) {
                min = 75;
                max = 84;
                presenter.range(min, max);
            } else if (value.matches("85 - 100")) {
                min = 85;
                max = 100;
                presenter.range(min, max);
            } else  {
                System.out.println("Select Range");
            }
        } catch (NullPointerException | QueryException ne ) {
            System.out.println(ne);
        }
    } //end range filter

    String gradeOpt;
    public void gradeFilter(ActionEvent event) throws NullPointerException{
        try {
            String value = gradeOption.getValue();
            System.out.println("Grade Filter: " +value);

            if (value.matches("HD")) {
                gradeOpt = "HD";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("D")) {
                gradeOpt = "D";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("C")) {
                gradeOpt = "C";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("P")) {
                gradeOpt = "P";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("F")) {
                gradeOpt = "F";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("AF")) {
                gradeOpt = "AF";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("SE")) {
                gradeOpt = "SE";
                presenter.gradeOptionMethod(gradeOpt);
            } else if (value.matches("SA")) {
                gradeOpt = "SA";
                presenter.gradeOptionMethod(gradeOpt);
            }
            else  {
                System.out.println("Select Grade");
            }
        } catch (NullPointerException | QueryException ne ) {
            System.out.println(ne);
        }
    }

    public void getTolerance(ActionEvent event) throws QueryException, IndexOutOfBoundsException {
        try {
            toleranceValue1 = Integer.parseInt(toleranceValue.getText());
            if (toleranceValue1 >= 0) {
                System.out.println(toleranceValue1 + "Tolerance value is entered");
            }
        } catch (NumberFormatException numberFormatException) { //exception handling
            toleranceValue1 = 2; //if other tha number entered or less than 0 entered
        }
        try {
            presenter.tolerance(toleranceValue1);
        }
        catch (IndexOutOfBoundsException ie){
            System.out.println("Tolerance is set 0 or less than 0: " + ie);
        }
    }

    public void gradeAll(ActionEvent event) throws QueryException, IndexOutOfBoundsException {
        updateBtn.setDisable(true);
        saveBtn.setDisable(true);
        System.out.println("Grade All");
        try {
            presenter.gradeAll();
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("No data to grade: " +ex);
        }
    }

    //display records in the required field
    @Override
    public void displayRecord( IndexedStudent ip ) {
        Marks p = ip.getMarks();
        studentIDField.setText(  p.getStudentID() );
        assignment1Field.setText ( Double.toString(p.getAssignment1() ));
        assignment2Field.setText( Double.toString(p.getAssignment2() ));
        examField.setText( Double.toString(p.getExamMarks() ));
        totalMarksField.setText( Double.toString(p.getTotalMarks() ));
        gradeField.setText(p.getGrade());
        finalIndex.setText( Integer.toString( ip.getSize() ) );
        currentIndex.setText(Integer.toString( ip.getIndex() ) );
    }

    @Override
    public void setBrowsing( boolean flag ) {
        nextButton.setDisable( !flag );
        previousButton.setDisable( !flag );
    }

    @Override
    public void displayMessage(String s) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(s);
        alert.show();
    }

    @Override
    public void displayError(String s) {
        System.err.println(s);
    }

}

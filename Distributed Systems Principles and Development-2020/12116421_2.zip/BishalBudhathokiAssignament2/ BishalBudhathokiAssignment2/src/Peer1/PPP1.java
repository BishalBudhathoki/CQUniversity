package Peer1;

// required packages import
import java.util.logging.Logger;
import java.net.*;
import java.awt.Font;
import java.util.logging.Level;
import java.io.*;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

// Peer1 Class
public class PPP1 extends javax.swing.JFrame {

    private static Connection connection;
    //private boolean QuickRun = true;
    private boolean setButtonAction = false;

    // constructor with no argument
    public PPP1() {
        componentInitialisation();
    } //end constructor

    // main method
    public static void main(String[] args) {
        // local variable declaration section
        System.setProperty("java.net.preferIPv4Stack", "true");

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PPP1().setVisible(true));
    } //end Main Method

    // this function is called when set button is pressed
    public void setButtonAction() {
        setButtonAction = true; // sets the set button pressed value true

        //passing user input to variables
        String groupIP = tGroupIP.getText();
        String groupPort = tGroupPort.getText();
        String peerID = tPeerID.getText();
        String receptionPort = tReceptionPort.getText();

        // input validation
        if (!(groupIP.equals("228.5.6.7") || groupPort.equals("8888") || peerID.equals("PPP1")
                || receptionPort.equals("6779"))) {
            printAlert("Invalid GroupIP, GroupPort, "
                    + "PeerID, and ReceptionPort ");
        } else {
            setButton.setEnabled(false); // disables the set button
            try {
                //connection with the multicast peer group
                InetAddress groupIPAddress = InetAddress.getByName(groupIP);
                int portValue = Integer.parseInt(groupPort);
                MulticastSocket multicastSocket = new MulticastSocket(portValue);
                multicastSocket.joinGroup(groupIPAddress);

                //start the receive service
                new ReceiveHandler(multicastSocket, peerID, receptionPort, groupIPAddress);
                //start the cast service
                connection = new Connection(multicastSocket, groupIPAddress, portValue, peerID, receptionPort);
                try {
                    //start file receive service using UDP
                    new ReceptionService(receptionPort);

                } catch (Exception ex) { //exception handling
                    Logger.getLogger(PPP1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    // start sender UDP
                    new RequestHandler(receptionPort);
                } catch (Exception ex) { //exception handling
                    Logger.getLogger(PPP1.class.getName()).log(Level.SEVERE, null, ex);
                }
                // when no error
                printAlert("Connected");

            }
            catch (SocketException e) {
                System.out.println("Socket: " + e.getMessage());
            } catch (IOException e) {
                System.out.println("IO: " + e.getMessage());
            }
        }
    } //end sendButtonAction

    //component initialisation method
    private void componentInitialisation() {
        javax.swing.JLabel lFileName = new javax.swing.JLabel();
        javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
        tFileName = new javax.swing.JTextField();
        javax.swing.JLabel lGroupIP = new javax.swing.JLabel();
        javax.swing.JLabel lGroupPort = new javax.swing.JLabel();
        tGroupIP = new javax.swing.JTextField();
        tGroupPort = new javax.swing.JTextField();
        javax.swing.JLabel lPeerID = new javax.swing.JLabel();
        javax.swing.JButton searchButton = new javax.swing.JButton();
        javax.swing.JLabel lSearchResult = new javax.swing.JLabel();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane();
        displayArea = new javax.swing.JTextArea();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel lReceptionPort = new javax.swing.JLabel();
        tPeerID = new javax.swing.JTextField();
        tReceptionPort = new javax.swing.JTextField();
        setButton = new javax.swing.JButton();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        //set file name label
        lFileName.setText("File Name");
        // set searchButton name to search
        searchButton.setText("Search");
        searchButton.addActionListener(evt -> searchButtonAction());
        //set search result label
        lSearchResult.setText("Search Result");
        displayArea.setColumns(18);
        displayArea.setRows(5);
        Font font = new Font("Courier", Font.BOLD, 14);
        displayArea.setFont(font);
        jScrollPane.setViewportView(displayArea);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lFileName)
                                .addGap(10, 10, 10)
                                .addComponent(tFileName, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(searchButton)
                                .addGap(10, 10, 10))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane)
                                .addContainerGap())
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(224, 224, 224)
                                .addComponent(lSearchResult)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lFileName)
                                        .addComponent(tFileName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(searchButton))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lSearchResult)
                                .addGap(10, 10, 10)
                                .addComponent(jScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                                .addContainerGap())
        );
        //set group IP label
        lGroupIP.setText("GroupIP");
        //set group port label
        lGroupPort.setText("GroupPort");
        //set peer ID label
        lPeerID.setText("PeerID");
        //set reception port label
        lReceptionPort.setText("Reception Port");
        //set set button label
        setButton.setText("Set");
        setButton.addActionListener(evt -> setButtonAction());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lGroupIP)
                                        .addComponent(lGroupPort))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tGroupPort, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tGroupIP, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lReceptionPort, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lPeerID, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(tReceptionPort, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(10, 10, 10)
                                                .addComponent(setButton))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(tPeerID, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(10, 10, 10))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap(20, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lGroupIP)
                                        .addComponent(tGroupIP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lPeerID)
                                        .addComponent(tPeerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(tGroupPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lGroupPort)
                                        .addComponent(lReceptionPort)
                                        .addComponent(tReceptionPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(setButton)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(10, 10, 10)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
        );
        pack();
    } //end component initialisation

    // when Search button is pressed
    public void searchButtonAction() {
        if (!setButtonAction) // if set button is not pressed
        {
            printAlert(" Set Button Not Pressed"); // message to press set button
        }
        else {
            String fileNameToCast = tFileName.getText(); // question is read.
            if (fileNameToCast.equals("")) {
                printAlert("Please enter file name to receive"); // Displays message when no file name is entered
            } else {
                connection.castMessage(fileNameToCast); // sends file to all connected peers
            }
        }
    } //end searchButtonAction



    //can print message in search result text box
    public static void printAlert(String s) {
        displayArea.setText(" " + s + "\n");
    }


    // variable declarations
    public static javax.swing.JTextArea displayArea;
    private javax.swing.JButton setButton;
    private javax.swing.JTextField tGroupIP;
    private javax.swing.JTextField tGroupPort;
    private javax.swing.JTextField tPeerID;
    private javax.swing.JTextField tFileName;
    private javax.swing.JTextField tReceptionPort;
}

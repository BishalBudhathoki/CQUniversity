package Peer1;

// required packages import
import java.net.*;
import java.io.*;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

// class CastService
public class Connection extends Thread {
    //declaration and initialisation of variables
    private MulticastSocket multicastSocket = null;
    private String ID;
    private int receptionPort;
    private InetAddress address = null;
    private int GroupPort = 8888;

    // constructor
    public Connection(MulticastSocket socket, InetAddress address, int groupPort,
                      String id, String receptionPort) {
        // assigning values
        this.multicastSocket = socket;
        this.address = address;
        this.GroupPort = groupPort;
        this.ID = id;
        this.receptionPort = Integer.parseInt(receptionPort);
        this.start();
    } //end CastService

    // this method cast file name to other peers connected
    public void castMessage(String string) {
        String fileName; //variable to store string value
        try {
            fileName = string;
            if (fileName.compareTo(new String("end")) == 0) {
                multicastSocket.close(); //close multicast socket
                System.exit(0); //exit GUI
            } else {
                //multicasting messages for the other peer
                // create string with receptionPort, GroupPort, peer id and question
                fileName = receptionPort + " " + ID + " " + fileName;
                byte[] msg = fileName.getBytes(); // string to byte
                DatagramPacket messageOut = new DatagramPacket(msg, msg.length, address, GroupPort);
                multicastSocket.send(messageOut); // sends the query
            }
            // handling exceptions
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        }
    } //end CastMessage
} //end Class

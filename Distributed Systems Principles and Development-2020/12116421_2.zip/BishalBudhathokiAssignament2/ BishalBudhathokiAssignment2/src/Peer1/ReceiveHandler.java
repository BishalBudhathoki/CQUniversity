package Peer1;

// required packages import
import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

// receive file search request
public class ReceiveHandler extends Thread {
    // variable declaration
    private MulticastSocket multicastSocket = null;
    private String ID = null;
    private int sendPort;
    private InetAddress sendIP;

    // constructor
    public ReceiveHandler(MulticastSocket multicastSocket, String ID, String receptionPort,
                          InetAddress inetAddress) {

        this.multicastSocket = multicastSocket;
        this.ID = ID;
        //call run method to start the thread
        this.start();
    } //end constructor

    // overriding the run method
    @Override
    public void run() {
        // while listing to port is true
        while (true) {
            try {
                //receive multicast messages
                byte[] buffer = new byte[50];
                DatagramPacket datagramPacketIn = new DatagramPacket(buffer, buffer.length);
                multicastSocket.receive(datagramPacketIn); //receive datagram packet
                String fileComplete = new String(datagramPacketIn.getData(), 0, datagramPacketIn.getLength());
                String[] fc = fileComplete.split(" "); // split the message;
                if (!ID.equals(fc[1])) {
                    String fileName = fc[2];
                    sendIP = datagramPacketIn.getAddress(); // gets sender ip
                    sendPort = Integer.parseInt(fc[0]); // gets sender port
                    //send file in packets if found
                    RequestHandler.sendDataPacket(fileName, sendIP, sendPort);
                }
                // exception handling
            } catch (SocketException e) {
                System.out.println("Socket: " + e.getMessage());
            } catch (UnknownHostException e) {
                System.out.println("Socket:" + e.getMessage());
            } catch (EOFException e) {
                System.out.println("EOF:" + e.getMessage());
            } catch (IOException e) {
                System.out.println("IO: " + e.getMessage());
            } catch (Exception ex) {
                Logger.getLogger(ReceiveHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
} //end receiveService

package Peer2;

// required packages import

import java.io.*;
import java.net.*;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

// this class download file and reads required data from/of file
public class ReceptionService extends Thread {
    // variable declaration
    private int receivePort;
    private String fileName;

    // constructor
    public ReceptionService(String receivePort) throws Exception {
        this.receivePort = Integer.parseInt(receivePort);
        new DatagramSocket(this.receivePort);
        //call run method to start the thread
        this.start();
    }

    // overriding the run method
    @Override
    public void run() {
        try {
            ServerSocket socket1 = new ServerSocket(receivePort);
            while (true) {
                Socket socket = socket1.accept();
                System.out.println("");
                DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
                fileName = dataInputStream.readUTF();

                //file size read
                int size = dataInputStream.readInt();

                System.out.print(fileName + size + "\n");
                //Construct a byte array to receive the class file
                byte[] buffer = new byte[size];
                int bytesRead = dataInputStream.read(buffer, 0, buffer.length);
                System.out.print(buffer.length + "  " + bytesRead + "\n");
                //download and save the file
                FileOutputStream fileOutputStream = new FileOutputStream(FileGetterAndSetter.getClassPath("DownloadedFile" + fileName));
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                bufferedOutputStream.write(buffer, 0, bytesRead);
                bufferedOutputStream.close();
                System.out.printf("Receive Completed");
                String success = "The file of  " + fileName + " was found," +"\n" + "downloaded and saved as DownloadedFile" + fileName;
                PPP2.displayArea.append(success);
            }
            // exception handling
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (UnknownHostException e) {
            System.out.println("Socket:" + e.getMessage());
        } catch (EOFException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("File not found.");
            PPP2.displayArea.append("The request file: " + fileName + " cannot be found on the peer overlay!\n");
            System.out.println("IO: " + e.getMessage());
        }
    } //end run method
} //end reception service

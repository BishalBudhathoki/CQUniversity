package Peer2;

// required packages import
import java.io.*;
import java.net.*;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

// this class sends file if found in peer when requested
class RequestHandler {

    // constructor
    public RequestHandler(String port) throws Exception {
        // variable declaration
        int peerPort = Integer.parseInt(port);
        new DatagramSocket();
    }// end constructor

    // this method sends file to the requested Peer
    public static void sendDataPacket(String fileName, InetAddress sendIP, int sendPort) throws Exception {
        try {
            System.out.print("Sending\n");
            String peerhostName = sendIP.getHostName();
            Socket socket = new Socket(peerhostName, sendPort);
            OutputStream outputStream = socket.getOutputStream();
            File file = FileGetterAndSetter.getClassFile(fileName);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
            DataInputStream dataInputStream = new DataInputStream(bufferedInputStream);
            byte[] newByteArray = new byte[(int) file.length()];
            dataInputStream.readFully(newByteArray, 0, newByteArray.length);
            //data output stream sends data tot he required peer
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            //write file name
            dataOutputStream.writeUTF(fileName);
            //write file length
            dataOutputStream.writeInt(newByteArray.length);
            //write file
            dataOutputStream.write(newByteArray, 0, newByteArray.length);
            dataOutputStream.flush();
            dataInputStream.close();
            dataOutputStream.close();
            socket.close();
            System.out.print("Sent Complete");
        }
        catch (IOException e) {
            System.out.println("file not found");
            PPP2.displayArea.append("The request file: " + fileName + " cannot be found on the peer overlay!\n");
        }
    }// end send data packet
}//end reply service

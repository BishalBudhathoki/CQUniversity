package Peer2;

import java.io.File;
import java.nio.file.Paths;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 2, Term 2,2020
 */

//FileGetter class
public class FileGetterAndSetter {
    private static String filePlace =Paths.get("").toAbsolutePath().toString();
    //obtain file from sharing peer
    public static File getClassFile(String fileName) {
        String filePlace = FileGetterAndSetter.filePlace;
        File parentDirectory = new File(filePlace);
        File srcDirectory = new File(parentDirectory, "src");
        File peerTwoDirectory = new File(srcDirectory, "Peer2");
        File sharingDirectory = new File(peerTwoDirectory, "ShareAndDownload");
        return new File(sharingDirectory,fileName);
    }

    //obtain file path from the server.
    public static String getClassPath(String fileName) {
        String filePlace = FileGetterAndSetter.filePlace;
        File parentDir = new File(filePlace);
        File srcDirectory = new File(parentDir, "src");
        File peerTwoDirectory = new File(srcDirectory, "Peer2");
        File sharingFileDirectory = new File(peerTwoDirectory, "ShareAndDownload");

        return (sharingFileDirectory+ "\\" +fileName);
    }
}
package Server;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class FileGetter {

    //This class will get the file from the server.
    public static File getClassFile(String className) {
        //seting the path directory to obtain file from server
        String codeLocation = Paths.get("").toAbsolutePath().toString();           
        File parentDir = new File(codeLocation);            
        File buildDir = new File(parentDir, "build");       
        File classesDir = new File(buildDir, "classes");        
        File contractDir = new File(classesDir, "Contract");              

        return new File(contractDir, className + ".class");
    }
}

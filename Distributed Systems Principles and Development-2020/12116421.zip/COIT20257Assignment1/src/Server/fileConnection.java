/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import Contract.CSMessage;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class fileConnection extends Thread {

    private final Socket fileSocket;
    private final CSMessage message = new CSMessage();

    public fileConnection(Socket fileSocket) {
        this.fileSocket = fileSocket;
    }

    @Override
    public void run() {
        try {
            DataInputStream dataInputStream = new DataInputStream(fileSocket.getInputStream());

            while (true) {
                // Wait for task requests.
                String className = dataInputStream.readUTF();
                //get the class file length
                int size = dataInputStream.readInt();
                //byte array to receive the class file
                byte[] buffer = new byte[size];
                int readByteArray = dataInputStream.read(buffer, 0, buffer.length);
                //file output stream to save the class file in required directory
                FileOutputStream fileOutputStream = new FileOutputStream(FileGetter.getClassFile(className));
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                bufferedOutputStream.write(buffer,0,readByteArray);
                bufferedOutputStream.close();
                System.out.println("The class file of "+className+" has been downloaded.");                                          
                                   
            }           
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } 
    }

}

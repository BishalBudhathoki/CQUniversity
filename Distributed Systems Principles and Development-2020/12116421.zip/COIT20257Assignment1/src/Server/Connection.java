package Server;

import Contract.CSMessage;
import Contract.Task;
import java.io.*;
import java.net.Socket;

/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */

//Server to client connection
public class Connection extends Thread {

    private final Socket objSocket;
    private final CSMessage message = new CSMessage();

    public Connection(Socket objSocket) { //connection constructor
        this.objSocket = objSocket;
    }

    @Override
    public void run() {
        try {
            OutputStream serverOutputStream = objSocket.getOutputStream(); // output stream - object
            ObjectOutputStream serverObjectOutputStream = new ObjectOutputStream(serverOutputStream);

            InputStream serverInputStream = objSocket.getInputStream(); // input stream - object
            ObjectInputStream serverObjectInputStream = new ObjectInputStream(serverInputStream);
                                    
            System.out.println("Server.Connection.run()");

            while (true) {

                // Wait for task requests.
                Task task = (Task) serverObjectInputStream.readObject();

                System.out.println(task.getClass().getName()+ " classname in connection");
                switch(task.getClass().getSimpleName()) {
                    case("calculatePi"):
                    case("calculateGCD"):
                    case("calculatePrime"):
                        task.executeTask();
                        System.out.println("-------"+task.getResult()+"-------");
                        //return the task object to the client
                        serverObjectOutputStream.writeObject(task);
                        serverObjectOutputStream.flush();
                        break;
                    default: //on default break
                        break;
                    }
                }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } 
    }

}

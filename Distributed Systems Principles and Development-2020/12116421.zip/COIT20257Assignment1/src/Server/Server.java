package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class Server extends Thread{

    private static final int objectPort = 6789;
    private static final int filePort = 6790;

    public Server() {
        //server constructor
    }

    //set and start the server socket to listen to clients.
    public void startListening() throws ClassNotFoundException, IOException {
        ServerSocket objectServerSocket = new ServerSocket(objectPort);
        ServerSocket fileServerSocket = new ServerSocket(filePort);

        System.out.println("----------------------------------------");
        System.out.println("The server is listening on " + objectPort
                + " for object transfer..");
        System.out.println("The server is listening on " + filePort
                + " for file transfer..");
        System.out.println("----------------------------------------");

        // Accepting the connections.
        while (true) { //multi-threading
            Socket objSocket = objectServerSocket.accept();
            Socket fileSocket = fileServerSocket.accept();
            //make a connection using multi threaded server Connection
            new Connection(objSocket).start(); //start individual thread
            new fileConnection(fileSocket).start();
        }
    }

    //the main method to execute the server
    public static void main(String[] args) throws NoClassDefFoundError, IOException {
        Server server = new Server();
        
        try {                        
            server.startListening();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Client.Contract.calculateGCD;
import Client.Contract.calculatePi;
import Client.Contract.calculatePrime;
import Contract.Task;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.util.Pair;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private TextField serverNameField;
    @FXML
    private TextField objectPortField;
    @FXML
    private TextField filePortField;
    @FXML
    private Button setButton;
    @FXML
    private ComboBox taskCombo;
    @FXML
    private Button uploadButton;
    @FXML
    private Button calculateButton;
    @FXML
    private TextArea resultArea;

    //Required strings
    private String serverName;
    private int objectPort;
    private int filePort;
    private Socket objectSocket, fileSocket;
    private ObjectInputStream OIS;
    private ObjectOutputStream OOS;
    private List<String> taskList = new ArrayList<String>();
    private final String output = "";

    @Override
    public void initialize(URL url, ResourceBundle rb
    ) {
        //listing task in combo box
        taskCombo.getItems().clear();
        taskCombo.getItems().addAll(
                "Calculate Pi",
                "Calculate GCD",
                "Calculate Prime");
    }

    @FXML
    private void setButtonOnClick(ActionEvent event) throws Exception{

        String serverNameFieldText = serverNameField.getText();
        String objectPortFieldText = objectPortField.getText();
        String filePortFieldText = filePortField.getText();
        try {
            if (serverNameFieldText.isEmpty() || !serverNameFieldText.equals("localhost")) {
                System.out.println("Please enter the server name: ");
                resultArea.appendText("Server name must be localhost\n");
            }
            if (objectPortFieldText.isEmpty()) {
                resultArea.appendText("Server object port must be 6789\n");
            }
            if (filePortFieldText.isEmpty()) {
                resultArea.appendText("Server file port must be 6790");
            }
        } catch (Exception ignored) {
            resultArea.appendText("Port is empty\n");
        }
        try {
            this.serverName = serverNameFieldText;
            if(serverNameFieldText.equals("localhost") && objectPortFieldText.equals("6789") && filePortFieldText.equals("6790")) {
                uploadButton.setDisable(false);
                calculateButton.setDisable(false);
                taskCombo.setDisable(false);
            }
            objectPort = Integer.parseInt(objectPortFieldText);
            filePort = Integer.parseInt(filePortFieldText);

            //Connecting thread
            new Thread(() -> {
                try {
                    objectSocket = new Socket(serverName, objectPort); //socket for object
                    fileSocket = new Socket(serverName, filePort); //socket for file

                    InputStream iso = objectSocket.getInputStream(); // input stream for object
                    OIS = new ObjectInputStream(iso);

                    OutputStream oso = objectSocket.getOutputStream(); // output stream for object
                    OOS = new ObjectOutputStream(oso);

                } catch (IllegalArgumentException | IOException e) {
                    resultArea.appendText("Unable to connect to " + serverName + "\n" + e.getMessage());
                }
            }).start();
        }catch(NumberFormatException e) {
            resultArea.appendText("\n Ports are wrong or empty\n");
        }
        resultArea.appendText("Set button Selected\n");
    }

    @FXML
    //When upload button is selected
    private void uploadOnClick(ActionEvent event) {
        String comboBoxValue;
        comboBoxValue = (String) taskCombo.getValue();
        String className;
        try {
            //if selected task from the option is: obtain class name
            if (comboBoxValue.equals("Calculate Pi")) {
                className = "calculatePi";
            } else if (comboBoxValue.equals("Calculate GCD")) {
                className = "calculateGCD";
            } else {
                className = "calculatePrime";
            }

            Client connection = new Client(OIS, OOS, fileSocket, className);
            connection.start();

            if (!taskList.contains(comboBoxValue)) {
                taskList.add(comboBoxValue);
            }

            connection.setCallback((String message) -> {
                resultArea.appendText(message);
            });
        } catch (NullPointerException nullPointerException) {
            resultArea.appendText("Select task to perform\n");
        }
    }

    @FXML
    //when calculate button is selected
    private void calculateOnClick(ActionEvent event) {
        String comboBoxValue = (String) taskCombo.getValue();

        if (taskList.contains(comboBoxValue)) {
            if (comboBoxValue.equals("Calculate GCD")) {
                showAlertGCD(); //display pop-up like box to take 2 user input
            } else {
                showAlert(); //display pop-up like box to take 1 user input
            }
        } else {
            resultArea.appendText("\nResult: Please upload the compute-task "
                    + comboBoxValue + " before calling the server.\n");
        }

    }

    public void showAlertGCD() {
        System.out.println("calculate GCD is selected");

        // Custom dialog is created as no option is available to take 2 user input.
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("GCD");

        // Button type is selected here
        ButtonType acceptValue = new ButtonType("OK", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(acceptValue, ButtonType.CANCEL);
        GridPane gridPane = new GridPane();
        gridPane.setHgap(15);
        gridPane.setVgap(15);
        //to take integer
        TextField integerOne = new TextField();
        integerOne.setPromptText("First Integer");
        TextField integerTwo = new TextField();
        integerTwo.setPromptText("Second Integer");

        gridPane.add(new Label("Integer 1:"), 0, 0);
        gridPane.add(integerOne, 1, 0);
        gridPane.add(new Label("Integer 2:"), 2, 0);
        gridPane.add(integerTwo, 3, 0);

        dialog.getDialogPane().setContent(gridPane);
        // on selecting ok button
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == acceptValue) {
                return new Pair<>(integerOne.getText(), integerTwo.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();
        result.ifPresent(new Consumer<Pair<String, String>>() {
            String comboBoxValue = (String) taskCombo.getValue();


            @Override
            //when pair value is obtained
            public void accept(Pair<String, String> pair) {
                System.out.println("Integer 1=" + pair.getKey() + ", Integer 2=" + pair.getValue());
                comboBoxValue = (String) taskCombo.getValue();
                System.out.println(comboBoxValue + " ------------");
                Task taskObject;
                // a and b store value of pair separately
                try {
                    int a = Integer.parseInt(pair.getKey());
                    int b = Integer.parseInt(pair.getValue());
                    System.out.println("A = " + a + " B = " + b);
                    String inputValue = null;

                    if (comboBoxValue.equals("Calculate Pi")) {
                        assert false;
                        taskObject = new calculatePi(Integer.parseInt(inputValue));
                    } else if (comboBoxValue.equals("Calculate GCD")) {
                        taskObject = new calculateGCD(Integer.parseInt(pair.getKey()), Integer.parseInt(pair.getValue()));
                    } else {
                        assert false;
                        taskObject = new calculatePrime(Integer.parseInt(inputValue));
                    }

                    Client connection = new Client(OIS, OOS, fileSocket, taskObject);
                    connection.start();
                    connection.setCallback((String message) -> {
                        resultArea.appendText(message);
                    });
                } catch(NumberFormatException e) {
                    resultArea.appendText("\n The input should be an Integer.");
                }
            }
        });
    }

    public void showAlert() {

        // create a text input dialog
        TextInputDialog textInputDialog = new TextInputDialog("User Input");

        // setHeaderText
        textInputDialog.setHeaderText("Please enter an Integer value");

        final Button ok = (Button) textInputDialog.getDialogPane().lookupButton(ButtonType.OK);
        ok.addEventFilter(ActionEvent.ACTION, event -> {
            String comboBoxValue = (String) taskCombo.getValue();
            comboBoxValue = (String) taskCombo.getValue();
            Task taskObject;
            String inputValue = textInputDialog.getEditor().getText();
            //value selected from combo box
            try {
                if (comboBoxValue.equals("Calculate Pi")) {
                    taskObject = new calculatePi(Integer.parseInt(inputValue));
                } else if (comboBoxValue.equals("Calculate GCD")) {
                    taskObject = new calculateGCD(10, 20);
                } else {
                    taskObject = new calculatePrime(Integer.parseInt(inputValue));
                }

                Client connection = new Client(OIS, OOS, fileSocket, taskObject);
                connection.start(); //now start the connection

                connection.setCallback((String message) -> {
                    resultArea.appendText(message);
                });
            }
            catch(NumberFormatException e) {
                resultArea.appendText("\n The input should be an Integer.");
            }

        });

        final Button cancel = (Button) textInputDialog.getDialogPane().lookupButton(ButtonType.CANCEL);
        cancel.addEventFilter(ActionEvent.ACTION, event
                -> resultArea.appendText("Cancel Selected\n"));

        // display the text input dialog
        textInputDialog.show();
    }

}

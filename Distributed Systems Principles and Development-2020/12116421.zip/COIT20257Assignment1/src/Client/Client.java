package Client;

import Contract.Task;
import java.io.*;
import java.net.Socket;
import java.nio.file.Paths;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */

//Connection from Client to Server
public class Client extends Thread {

    public interface ConnectionClient {
        void onNewMessage(String message);
    }

    private final Socket socket;
    private Task taskObject;
    private String obtainClass;
    private final ObjectInputStream objectInputStream;
    private final ObjectOutputStream objectOutputStream;

    private ConnectionClient conn;

    public Client(ObjectInputStream inputStream, ObjectOutputStream outputStream, Socket socket,
            String obtainClass) {
        this.objectInputStream = inputStream;
        this.objectOutputStream = outputStream;
        this.socket = socket;
        this.obtainClass = obtainClass;
    }

    public Client(ObjectInputStream objStreamInput, ObjectOutputStream objectStreamOutput, Socket socket,
            Task taskObject) {
        this.objectInputStream = objStreamInput;
        this.objectOutputStream = objectStreamOutput;
        this.socket = socket;
        this.taskObject = taskObject;
    }

    public void setCallback(ConnectionClient callback) {
        this.conn = callback;
    }

    @Override
    public void run() {
        try {
            if (this.obtainClass != null) { //if obtain class is not null
                OutputStream out = socket.getOutputStream();
                File ClassFile = getClassFile(obtainClass); //Read the class file
                BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(ClassFile));
                DataInputStream dataInputStream = new DataInputStream(bufferedInputStream);
                //Read the class file into a byte array
                byte[] arrayByte = new byte[(int) ClassFile.length()];
                dataInputStream.readFully(arrayByte, 0, arrayByte.length);
                //Use a data output stream to send the class file to server
                DataOutputStream dataOutputStream = new DataOutputStream(out);
                //Send the class file name using writeUTF
                dataOutputStream.writeUTF(obtainClass);
                //Send the class file length
                dataOutputStream.writeInt(arrayByte.length);
                //Send the class file
                dataOutputStream.write(arrayByte, 0, arrayByte.length);
                dataOutputStream.flush(); //flush the connection
                Message("\nUploading " + obtainClass + ".class is done. \n ");
            }
            else { //if class is null, get class name
                String className = taskObject.getClass().getSimpleName();

                switch (className) {
                    case ("calculatePi"):
                    case ("calculateGCD"):
                    case ("calculatePrime"):
                        objectOutputStream.writeObject(taskObject);
                        objectOutputStream.flush();
                        Task newTask = (Task) objectInputStream.readObject();
                        Message("Result: " + newTask.getResult());
                        Message("\n------------------------------------------------");
                        break;
                    default: { //do nothing on default
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("Client.Client.run()");
            e.printStackTrace();
        }
    }

    //A convenience method to send a message back to the calling class.
    private void Message(String message) {
        if (conn != null) {
            conn.onNewMessage(message);
        }
    }
    // to obtain class file from specific directory and .class format
    public static File getClassFile(String className) {
        String codeLocation = Paths.get("").toAbsolutePath().toString();
        File parentDir = new File(codeLocation);
        File buildDir = new File(parentDir, "build");
        File classesDir = new File(buildDir, "classes");
        File clientDir = new File(classesDir, "Client");
        File contractDir = new File(clientDir, "Contract");

        return new File(contractDir, className + ".class");
    }

}

package Client.Contract;

import Contract.Task;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class calculatePrime implements Task, Serializable {
    //initialisation
    private final int highestLimit; //highest limit value to obtain Prime number
    private String output;

    public calculatePrime(int limit) {
        this.highestLimit = limit;
    }

    @Override
    public String toString() {
        return "Calculating Prime from 1 to " + highestLimit;
    }

    @Override
    public void executeTask() {
        List<Integer> nums = new ArrayList<>();
        for (int i = 1; i <= highestLimit; i++) {
            if (isPrime(i)) {
                nums.add(i);
            }
        }

        StringBuilder buffer = new StringBuilder();
        int size = nums.size();
        for (int i = 0; i < size; i++) {
            int num = nums.get(i);
            buffer.append(num);
            if (i != size - 1) {
                buffer.append(",");
            }
        }

        output = "The number of primes is: " + size + ", and they are: " + buffer.toString();
    }

    private static boolean isPrime(long num) {
        if (num < 2) { // if less than 2 not prime
            return false;
        }
        for (long i = 2; i * i <= num; i++) { //check for greater than 2 prime value
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Object getResult() {
        return output;
    }

}

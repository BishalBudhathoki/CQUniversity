package Client.Contract;

import Contract.Task;
import java.io.Serializable;
import java.math.BigDecimal;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class calculatePi implements Task, Serializable {
    //initialisation
    private final int decimalLimit; //decimals limit to print
    private String output;

    public calculatePi(int decimalLimit) {
        System.out.println(decimalLimit +" This is the initial limit");
        
        this.decimalLimit = decimalLimit;
    }

    @Override
    public String toString() {
        return "Calculating Pi to " + decimalLimit + " decimal digits";
    }

    @Override
    public void executeTask() {
        System.out.println(decimalLimit +"This is the new limit");
        output = calculatePi(decimalLimit);
    }

    @Override
    public Object getResult() {
        return output;
    }

    private String calculatePi(int digits) { //Calculating PI value
        System.err.println(digits+"-----");
        BigDecimal four = BigDecimal.valueOf(4);
        int scale = digits + 2;
        BigDecimal arctT_5 = arcTan(5, scale);
        BigDecimal arcT_239 = arcTan(239, scale);
        BigDecimal pi = arctT_5.multiply(four).subtract(arcT_239).multiply(four);
        return String.format("%s", String.valueOf(pi.setScale(digits, BigDecimal.ROUND_HALF_UP)));
    }

    private static BigDecimal arcTan(int invX, int scale) {
        BigDecimal calculatedPi, tempNum, tempTerm;
        BigDecimal invX1 = BigDecimal.valueOf(invX);
        BigDecimal invX2 = BigDecimal.valueOf(invX * invX);
        tempNum = BigDecimal.ONE.divide(invX1, scale, BigDecimal.ROUND_HALF_EVEN);
        calculatedPi = tempNum;
        int i = 1;
        do {
            tempNum = tempNum.divide(invX2, scale, BigDecimal.ROUND_HALF_EVEN);
            int denom = 2 * i + 1;
            tempTerm = tempNum.divide(BigDecimal.valueOf(denom), scale, BigDecimal.ROUND_HALF_EVEN);
            if ((i % 2) != 0) {
                calculatedPi = calculatedPi.subtract(tempTerm);
            } else {
                calculatedPi = calculatedPi.add(tempTerm);
            }
            i++;
        } while (tempTerm.compareTo(BigDecimal.ZERO) != 0);
        return calculatedPi; //return Calculate Pi value with decimals in consideration
    }
}

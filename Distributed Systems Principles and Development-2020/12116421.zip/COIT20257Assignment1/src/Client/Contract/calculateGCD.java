package Client.Contract;

import Contract.Task;
import java.io.Serializable;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class calculateGCD implements Task, Serializable {
    //initialisation
    private final int firstLimit; //GCD first value
    private final int secondLimit; //GCD second value
    private String output;

    public calculateGCD(int firstLimit, int secondLimit) {
        this.firstLimit = firstLimit;
        this.secondLimit = secondLimit;
    }

    @Override
    public String toString() {
        return "Calculating GCD of " + firstLimit + " and " + secondLimit;
    }

    @Override
    public void executeTask() {
        output = "The Greatest Common Divisor of " + firstLimit + " and  "
                + secondLimit + " is "
                + gcd(firstLimit, secondLimit);
    }

    private static int gcd(int firstLimit, int secondLimit) { //calculate GCD between 2 numbers
        int calculatedResult;
        if (firstLimit == 0) {
            calculatedResult = secondLimit;
        } else {
            while (secondLimit != 0) {
                if (firstLimit > secondLimit) {
                    firstLimit = firstLimit - secondLimit;

                } else {
                    secondLimit = secondLimit - firstLimit;
                }
            }
            calculatedResult = firstLimit;
        }
        return calculatedResult; //return GCD
    }

    @Override
    public Object getResult() {
        return output;
    }

}

package Contract;

import Client.Contract.*;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public interface Task {
 void executeTask();
 Object getResult();
}
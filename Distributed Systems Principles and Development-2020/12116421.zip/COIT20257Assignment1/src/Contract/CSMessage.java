package Contract;

import java.io.Serializable;
/**
 * Student Name: Bishal Budhathoki
 * Student ID: 12116421
 * Subject: COIT20257
 * Assignment 1, Term 2,2020
 */
public class CSMessage implements Task, Serializable {
//The variable that holds the error information

    private String finalResult;

    public CSMessage() {
    }
//Return the error message

    public Object getResult() {
        return finalResult;
    }
//Set the error message

    public void setMessage(String msg) {
        finalResult = msg;
    }

    public void executeTask() {
    }
}

// You must open this file in TextPad to see correct indentation

// Assignment 2 Solution: Taxpayer.java
// Taxpayer Class as described in assignment

public class Taxpayer
{
	//constants to store max taxable income for each group, tax base ammounts for each group, etc.
	private static final double PERCENT1 = 0;
	private static final double PERCENT2 = 0.19;
	private static final double PERCENT3 = 0.325;
	private static final double PERCENT4 = 0.37;
	private static final double PERCENT5 = 0.45;
	private static final int GROUP1  = 18200;
	private static final int GROUP2  = 37000;
	private static final int GROUP3  = 87000;
	private static final int GROUP4 = 180000;
	private static final int BASE1 = 0;
	private static final int BASE2 = 0;
	private static final int BASE3 = 3572;
	private static final int BASE4 = 19822;
	private static final int BASE5 = 54097;

	//Fields/vars to store taxpayer name, age, taxable income, tax, tax group
	private String taxpayerName;
	private int    taxpayerAge;
 	private double taxableIncome;
 	private double tax;
 	private int    taxGroup;

 	//constructor
  	public Taxpayer(String name, int age, double income, double tax1, int group)
  	{
		taxpayerName = name;
	  	taxpayerAge  = age;
	  	taxableIncome= income;
	  	tax=tax1;
	  	taxGroup=group;
	}

	//setName method sets the taxpayer's name
 	public void setName(String name)
	{
		taxpayerName=name;
 	}

	//getName returns the taxpayer's name
	public String getName()
  	{
		return taxpayerName;
 	}

	//setAge method sets the taxpayer's age
 	public void setAge(int age)
	{
		taxpayerAge=age;
 	}

	//getAge method returns the taxpayer's age
	public int getAge()
  	{
		return taxpayerAge;
 	}

	//setIncome method sets the income
 	public void setIncome(double income)
	{
		taxableIncome=income;
 	}

	//getIncome method gets the income
	public double getIncome()
	{
		return taxableIncome;
 	}

	//getTax method returns the tax
	public double getTax()
  	{
		return tax;
 	}

	//setTax method sets the tax
 	public void setTax(double tax1)
	{
		tax=tax1;
 	}

	//getGroup method returns tax group
	public int getGroup()
  	{
		return taxGroup;
 	}

	//setGroup method sets the group
 	public void setGroup(int group)
	{
		taxGroup=group;
 	}

	//Method calculateTax calculates tax based in Table 1 in Assignment 2 and stores it in tax
	public void calculateTax()
	{
		//Calculates income tax by comparing the taxable income with lower and upper bounds
		if (taxableIncome < GROUP1 )
		{
			tax = 0;
			taxGroup=1;
		}
		else if (taxableIncome < GROUP2 )
		{
			tax = (taxableIncome - GROUP1) * PERCENT2 + BASE2;
			taxGroup=2;
		}
		else if (taxableIncome < GROUP3 )
		{
			tax = (taxableIncome - GROUP2) * PERCENT3 + BASE3;
			taxGroup=3;
		}
		else if (taxableIncome < GROUP4 )
		{
			tax = (taxableIncome - GROUP3) * PERCENT4 + BASE4;
			taxGroup=4;
		}
		else
		{
			tax = (taxableIncome - GROUP4) * PERCENT5 + BASE5;
			taxGroup=5;
		}
	}// End method calculateTax

	// method to display all taxpayers
	public void displayTaxpayers()
	{
	    System.out.printf("%-20s %-20d %s%-20.2f%s%-20.2f%-20d", taxpayerName, taxpayerAge, "$", taxableIncome, "$", tax, taxGroup);
	  	System.out.println();
	} // end of method displayTaxpayers

} //end of class Flight

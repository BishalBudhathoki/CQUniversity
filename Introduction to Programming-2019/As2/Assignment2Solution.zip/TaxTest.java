
//You must open this file in TextPad to see correct indentation

//Assignment 2 Solution: TaxTest.java
//This java application allows the user to read, validate, store, display, sort and search
//data (name, age, taxable income, tax, tax group) for N taxpayers.

import java.util.Scanner;

public class TaxTest
{
	static final int N = 3;

	// main method
	public static void main(String[] args)
    {
		int count, menuOption;
		boolean readOption=false;

		// array of Taxpayer objects
		Taxpayer[] myTaxpayer = new Taxpayer[N];

		Scanner input = new Scanner(System.in);
		do
		{
			// display a menu as shown in the assignment
		   	System.out.printf("\nWelcome to Tax System\n");
		   	System.out.printf("\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
	  			                "1. Read, validate and store data for N taxpayers",
			                    "2. Calculate and store tax and tax group for all taxpayers",
			                    "3. Display all taxpayers",
			                    "4. Display the name and age of all taxpayers from tax group 1",
			                    "5. Search a taxpayer by age",
			                    "6. Sort and display taxpayers",
			                    "7. Exit from the application");
			System.out.printf("Enter menu options 1-7: ");
	 		menuOption = input.nextInt();

			switch(menuOption)
			        {
			            case 1: readTaxpayerData(myTaxpayer);
			               		readOption = true;
			                    break;

			            case 2: if (readOption)
		            			{
									for (count=0; count <N; count++) myTaxpayer[count].calculateTax();
		            				System.out.printf("\nThe tax and group number for each taxpayer have been calculated and stored in an array of objects.\n\n");
								}
			            		else
			           				errorMessage();
			                    break;

	                	case 3: if (readOption)
	                			{
									System.out.printf("%-20s %-20s %-20s %-20s %-20s\n", "Taxpayer Name", "Age", "Taxable Income", "Tax", "Tax Group");
									for (count=0; count <N; count++) myTaxpayer[count].displayTaxpayers();
								}
		                		else
	                				errorMessage();
		                        break;

		               case 4:  if (readOption)
									displayGroupOneTaxpayers(myTaxpayer);
								else
								  	errorMessage();
		                        break;

					   case 5:  if (readOption)
		                			searchTaxpayer(myTaxpayer);
		                		else
		                			errorMessage();
		                        break;

		               case 6:  if (readOption)
		                			sortTaxpayers(myTaxpayer);
		                		else
		                			errorMessage();
		                        break;

		               case 7:  System.out.printf("\n\n%s\n\n","Thank you for using my application, S1267222");
		                        System.exit(1);

			           default: System.out.println("\n Options 1-7 must be entered\n");
		                        break;
		            }
        } while (menuOption !=8);
	} // end main

	// method to read name, age, taxable income, tax, tax group for N taxpayerss and store them in an array of taxpayer objects
	public static void readTaxpayerData(Taxpayer [] taxPayers)
	{
		final int MIN_TAXABLE_INCOME = 1; 		// minimum taxable income
		final int MAX_TAXABLE_INCOME = 999000;	// maximum taxable income
		final int MIN_AGE = 18; 				// minimum age
		final int MAX_AGE = 64;					// maximum age
		final int MAX_LINES = 25;				// maximum blank lines

		String 	name;
		int 	age;
		double 	income;
		double 	tax=0;
		int 	group=0;

		Scanner input = new Scanner (System.in);

		// the following loop reads name, age, taxable income, tax, tax group, validates them and stores them in an array of taxpayer objects
		for (int count=0; count<N; count++)
		{
		   System.out.printf ("%s%d: ","Please enter the name for taxpayer ",count+1);
		   name = input.nextLine();
		   System.out.printf ("%s%d: ","Please enter the age for taxpayer ",count+1);
		   age = input.nextInt();

		   // validates age
		   while (age > MAX_AGE || age < MIN_AGE)
		   {
		      System.out.printf("\nAge must be between %d and %d, enter correct age :", MIN_AGE, MAX_AGE);
		      age = input.nextInt();
		   }

		   System.out.printf ("%s%d: ","Please enter the taxable income for taxpayer ",count+1);
		   income = input.nextDouble();

		   // validates taxable income
		   while (income > MAX_TAXABLE_INCOME || income < MIN_TAXABLE_INCOME )
		   {
		   	  System.out.printf("\nTaxable income must be between %d and %d, enter correct income:", MIN_TAXABLE_INCOME, MAX_TAXABLE_INCOME);
			  income = input.nextDouble();
		   }

		   // creates object intitialised with the data and stores the object in the array
		   taxPayers[count] = new Taxpayer(name, age, income, tax, group);

		   input.nextLine();
		} // end of for loop
		System.out.printf("\nThe taxpayer name, age and taxable income have been read and stored in an array of objects.\n\n");
	}// end of readData


	// method to sort taxpayers by name in descending order
	public static void sortTaxpayers(Taxpayer [] taxPayers)
	{
	  int 		i=0, minIndex, age, group;
	  double 	tax, income;
	  String 	minName;

	  while(i < N-1)	// any other sorting algorithm could be used here
	  {
		minIndex = i;
		minName = taxPayers[i].getName();

		int j=i+1;
		while (j < N)	// this loop is to find min value
		{
		   if (minName.compareTo(taxPayers[j].getName()) < 0)
		   {
				minName = taxPayers[j].getName();
				minIndex = j;
		   }
		   j++;
		}
		// swap min value with the value of the first element
		taxPayers[minIndex].setName(taxPayers[i].getName());
		taxPayers[i].setName(minName);

		age=taxPayers[minIndex].getAge();
		taxPayers[minIndex].setAge(taxPayers[i].getAge());
		taxPayers[i].setAge(age);

		income=taxPayers[minIndex].getIncome();
		taxPayers[minIndex].setIncome(taxPayers[i].getIncome());
		taxPayers[i].setIncome(income);

		tax=taxPayers[minIndex].getTax();
		taxPayers[minIndex].setTax(taxPayers[i].getTax());
		taxPayers[i].setTax(tax);

		group=taxPayers[minIndex].getGroup();
		taxPayers[minIndex].setGroup(taxPayers[i].getGroup());
		taxPayers[i].setGroup(group);
		i++;
	  }
	  // display sorted taxpayers
	  System.out.printf("%-20s %-20s %-20s %-20s %-20s\n", "Taxpayer Name", "Age", "Taxable Income", "Tax", "Tax Group");
	  for(i = 0; i < N; i++) taxPayers[i].displayTaxpayers();
	} // end of method sortTaxpayers


	// method to search and display the taxpayer which has age equal to the given age
	public static void searchTaxpayer(Taxpayer [] taxPayers)
	{
	  int searchKey, found=0;

	  // read taxpayer's age to search
	  Scanner input = new Scanner(System.in);
	  System.out.printf("Enter the age to search: ");
	  searchKey = input.nextInt();

	  // search array for the age
	  for(int i=0; i<N; i++)
	  {
		  if ( taxPayers[i].getAge()== searchKey)
		  {
				found++;
				if (found == 1 )
				{
					System.out.printf("\nTaxpayer found\n");
					System.out.printf("%-20s %-20s %-20s %-20s %-20s\n", "Taxpayer Name", "Age", "Taxable Income", "Tax", "Tax Group");
				}
				taxPayers[i].displayTaxpayers();
		 }
	  }
	  if (found==0)System.out.printf("\nTaxpayer is not found\n");
	} //end of method searchTaxpayer

	// method to display an eror message
	public static void errorMessage()
	{
		System.out.printf("\n\n**Error: Option 1 has not been selected. \nGo to menu Option 1 and read Taxpayer data**\n\n");
	} // end of method errorMessage

	// method to display all taxpayers from group 1
	public static void displayGroupOneTaxpayers(Taxpayer [] taxPayers)
	{
		int	found =0;

		// search array for taxpayer with group 1
		for(int i=0; i<N; i++)
		{
			if ( taxPayers[i].getGroup()== 1)
			{
				found++;
				if (found == 1 )
				{
					System.out.printf("\nTaxpayer with Group 1 found\n");
					System.out.printf("%-20s %-20s %-20s %-20s %-20s\n", "Taxpayer Name", "Age", "Taxable Income", "Tax", "Tax Group");
				}
				taxPayers[i].displayTaxpayers();
			}
		}
		if (found==0)System.out.printf("\nTaxpayer with Group 1 is not found\n");
	} // end of method displayGroupOneTaxpayers
} // end TaxTest

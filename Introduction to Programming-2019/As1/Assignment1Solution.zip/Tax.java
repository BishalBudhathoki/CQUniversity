//Tax.java
//You must open this file in TextPad to see correct indentation
//Class Tax contains appropriate declarations, constructor and methods according to Assignment 1 requirements

public class Tax
{
	//Constants for tax breaks and groups as shown in Table 1
	private static final double PERCENT1 = 0;
	private static final double PERCENT2 = 0.19;
	private static final double PERCENT3 = 0.325;
	private static final double PERCENT4 = 0.37;
	private static final double PERCENT5 = 0.45;
	private static final int GROUP1  = 18200;
	private static final int GROUP2  = 37000;
	private static final int GROUP3  = 87000;
	private static final int GROUP4 = 180000;
	private static final int BASE1 = 0;
	private static final int BASE2 = 0;
	private static final int BASE3 = 3572;
	private static final int BASE4 = 19822;
	private static final int BASE5 = 54097;

	//Fields to number of employees in each group
	//Better option is to have private fields and set and get methods
	public int group1Emp;
	public int group2Emp;
	public int group3Emp;
	public int group4Emp;
	public int group5Emp;

	//Tax constructor
	public Tax()
	{
		group1Emp=0;
		group2Emp=0;
		group3Emp=0;
		group4Emp=0;
		group5Emp=0;
	}

	//Method calculateTax calculates tax based on Table 1 in Assignment 1 and returns it
	public double calculateTax(double income)
	{
		double tax;

		//Calculates income tax by comparing the taxable income with lower and upper bounds
		if (income < GROUP1 )
		{
			tax = 0;
			group1Emp++;
		}
		else if (income < GROUP2 )
		{
			tax = (income - GROUP1) * PERCENT2 + BASE2;
			group2Emp++;
		}
		else if (income < GROUP3 )
		{
			tax = (income - GROUP2) * PERCENT3 + BASE3;
			group3Emp++;
		}
		else if (income < GROUP4 )
		{
			tax = (income - GROUP3) * PERCENT4 + BASE4;
			group4Emp++;
		}
		else
		{
			tax = (income - GROUP4) * PERCENT5 + BASE5;
			group5Emp++;
		}
		return tax;
	}//End method calculateTax

	//Method highestTaxGroup determines group with highest number of employees
	public int highestTaxGroup(int group1, int group2, int group3, int group4, int group5)
	{
		int highestGroup = 0;
		int groupEmployee = 0;

		if (group1 >= groupEmployee)
		{
			groupEmployee = group1;
			highestGroup = 1;
		}
		if (group2 >= groupEmployee)
		{
			groupEmployee = group2;
			highestGroup = 2;
		}
		if (group3 >= groupEmployee)
		{
			groupEmployee = group3;
			highestGroup = 3;
		}
		if (group4 >= groupEmployee)
		{
			groupEmployee = group4;
			highestGroup = 4;
		}
		if (group5 >= groupEmployee)
		{
			groupEmployee = group5;
			highestGroup = 5;
		}
		return highestGroup;
	}//End method highestTaxGroup
}//End class Tax

//TaxTest.java file
//You must open this file in TextPad to see correct indentation
//This application is for an employee income tax calculator for N employees. N should be declared as a constant and it should
//be equal to the largest digit of your student ID number (e.g. if your ID number is S456222 then N
//should be equal to 6 and you can declare it as final int N=6).

import java.util.Scanner;

public class TaxTest
{
	//Method main displays welcome message, creates tax object,calls methods and displays report with income tax details and exit message
	public static void main (String[] args)
	{
		final int N = 6;
		double taxableIncome=0;
		double incomeTax=0;
		double lowestTax=0;
		double highestTax=0;
		double totalTax=0;

		//Displays welcome message
		System.out.printf("\n*****Welcome to Income Tax Calculator *****\n");

		//Creates myTax object and calls appropriate methods
		Tax myTax = new Tax();

		for (int i=0; i<N; i++)
		{
			//Creates scanner object for user input
			Scanner input = new Scanner (System.in);

			//Reads tax area from the keyboard
			System.out.printf("\nEnter the taxable income for employee %d: ", i+1);
			taxableIncome=input.nextDouble();

			//Gets the taxable income and calculates the tax by calling calculateTax method
			incomeTax = myTax.calculateTax(taxableIncome);
			System.out.printf("The income tax for employee %d is $%4.2f\n", i+1, incomeTax);

			//Calculates the lowest tax
			if (i==0) lowestTax = incomeTax;
			if (incomeTax < lowestTax)
				lowestTax = incomeTax;

			//Calculates the highest tax
			if (i==0) highestTax = incomeTax;
			if (incomeTax > highestTax)
				highestTax = incomeTax;
		}

		//Get the highest tax group
		int highestTaxGroup = myTax.highestTaxGroup(myTax.group1Emp, myTax.group2Emp, myTax.group3Emp, myTax.group4Emp, myTax.group5Emp);

		//Displays the income tax details as required in Assignment 1
		System.out.printf("\n\n------------Report------------\n");
		System.out.printf("Highest tax: $%4.2f\n", highestTax);
		System.out.printf("Lowest tax: $%4.2f\n", lowestTax);
		System.out.printf("Number of employees in Group 1: %d\n", myTax.group1Emp);
		System.out.printf("Number of employees in Group 5: %d\n", myTax.group5Emp);
		System.out.printf("Tax group with highest number of employees: %d\n", highestTaxGroup);

		//Displays exit message
		System.out.printf("\n\nThank you for using the Income Tax Calculator, S456222\n\n");
	}//End method main
}//End TaxTest
